# Post Job Cleanup Action

This composite action cleans up old repository clones from the GitHub Actions runner's `_work` directory to prevent disk space exhaustion.

## Problem

GitHub Actions runners can eventually run out of disk space as they cache each repository that is checked out during workflow runs. Over time, this can lead to:
- Failed workflows due to insufficient disk space
- Slower performance as the runner manages more files
- Wasted disk space from old, unused repository clones

## Solution

This action automatically cleans up repository clones that are older than a specified number of days (default: 14 days). It safely preserves critical directories that start with an underscore (like `_tool`, `_actions`, `_temp`, etc.) which are used by the GitHub Actions runner infrastructure.

## Standalone Workflow

The recommended usage is via the dedicated **Runner Cleanup workflow** (`.github/workflows/runner-cleanup.yml`) which runs automatically on a schedule:

- **Scheduled**: Runs daily at 2am CDT (07:00 UTC) on all runners
- **Manual**: Can be triggered via workflow_dispatch with custom parameters

### Manual Trigger

Go to Actions → Runner Cleanup → Run workflow:
- **days-old**: Number of days (default: 14)
- **dry-run**: Test mode without deleting (default: false)
- **runner_type**: Which runners to clean (test or prod)

## Usage in Other Workflows

You can also add this action as the last step in your workflow jobs to clean up after the job completes:

```yaml
jobs:
  your-job:
    runs-on: [self-hosted]
    steps:
      # Your regular workflow steps
      - name: Checkout
        uses: actions/checkout@v4
      
      # ... other steps ...
      
      # Add cleanup as the last step
      - name: Cleanup old repository clones
        if: always()  # Run even if previous steps fail
        uses: ./.github/actions/post-job-cleanup
```

### Basic Usage in Workflows

```yaml
- name: Cleanup old repository clones
  if: always()
  uses: ./.github/actions/post-job-cleanup
```

### Custom Configuration in Workflows

```yaml
- name: Cleanup old repository clones
  if: always()
  uses: ./.github/actions/post-job-cleanup
  with:
    work-directory: '../../_work'  # Path to _work directory
    days-old: '14'                  # Remove directories older than 14 days
    dry-run: 'false'                # Set to 'true' to see what would be deleted
```

### Dry Run Mode

To see what would be deleted without actually deleting anything:

```yaml
- name: Cleanup old repository clones (Dry Run)
  if: always()
  uses: ./.github/actions/post-job-cleanup
  with:
    dry-run: 'true'
```

## Inputs

| Input | Description | Required | Default |
|-------|-------------|----------|---------|
| `work-directory` | Path to the _work directory to clean up | No | `../../_work` |
| `days-old` | Remove directories older than this many days | No | `14` |
| `dry-run` | Run in dry-run mode (show what would be deleted) | No | `false` |

## Behavior

### What Gets Cleaned Up

- Repository clones in the `_work` directory older than the specified number of days
- Only directories at the first level of `_work` (not nested directories)

### What Gets Preserved

- **All directories starting with underscore (`_`)**: This includes critical infrastructure directories like:
  - `_tool` - Tool cache directory
  - `_actions` - Actions cache directory
  - `_temp` - Temporary files directory
  - Any other underscore-prefixed directories
- **Directories newer than the specified age**: By default, directories less than 14 days old

### Safety Features

- **Non-destructive if directory not found**: If the `_work` directory doesn't exist or isn't accessible, the action logs a warning and continues without error
- **Detailed logging**: Reports before/after statistics, what was deleted, and any failures
- **Dry-run mode**: Test the cleanup without actually deleting anything
- **Failure tracking**: Reports successful and failed deletion attempts

## Output Example

```
Starting post-job cleanup of: /home/runner/work/_work
Removing directories older than 14 days
Dry-run mode: false
Before cleanup: 15 directories, total size: 2.3G

Skipping (starts with _): _tool
Skipping (starts with _): _actions
Skipping (starts with _): _temp
Found old directory: old-repo-1 (age: 21 days, size: 150M)
Deleting: /home/runner/work/_work/old-repo-1
✓ Deleted: old-repo-1
Found old directory: old-repo-2 (age: 18 days, size: 200M)
Deleting: /home/runner/work/_work/old-repo-2
✓ Deleted: old-repo-2

=== Cleanup Summary ===
Before: 15 directories, size: 2.3G
After: 13 directories, size: 1.9G
Directories deleted: 2
Failed deletions: 0
=======================
```

## Best Practices

1. **Use `if: always()`**: Ensure cleanup runs even if previous steps fail
2. **Place as last step**: Run cleanup after all other workflow steps
3. **Test with dry-run first**: Use `dry-run: 'true'` to verify behavior before enabling
4. **Adjust retention period**: Set `days-old` based on your workflow frequency and disk capacity
5. **Self-hosted runners**: This action is particularly important for self-hosted runners where disk space is limited

## Technical Details

### Directory Age Calculation

The action determines directory age using the modification time (`mtime`) of the directory itself:
- **Linux**: Uses `stat -c %Y` to get modification timestamp
- **macOS**: Uses `stat -f %m` to get modification timestamp

The age is calculated in days from the current time.

### Path Resolution

The action resolves the `_work` directory path relative to the action's location:
- Default path `../../_work` assumes the action is in `.github/actions/post-job-cleanup`
- This resolves to the runner's main `_work` directory

### Error Handling

- Directory access errors are logged but don't fail the action
- Failed deletions are counted and reported but don't stop the cleanup process
- Missing `_work` directory logs a warning and exits gracefully

## Troubleshooting

### Action reports "Work directory not found"

The `_work` directory path may be different on your runner. Try:
1. Run with dry-run mode to see the resolved path
2. Adjust the `work-directory` input to match your runner's structure
3. Check that the action has permissions to access the directory

### No directories are being deleted

Possible reasons:
- All directories are newer than the `days-old` threshold
- All directories start with underscore and are being skipped
- Run with dry-run mode to see what would be deleted

### Permission errors during deletion

Ensure the runner user has write permissions on the `_work` directory and its contents.

## Contributing

When modifying this action:
1. Test with `dry-run: 'true'` first
2. Verify behavior on both Linux and macOS if applicable
3. Update this README with any new features or changed behavior

## License

This action is part of the gh-migration repository and follows the same license.
