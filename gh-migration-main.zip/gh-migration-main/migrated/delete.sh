﻿#!/bin/bash

# Usage: ./delete.sh <input-file> [token]
# If token is not provided, uses GITHUB_TOKEN environment variable

# Create logs directory
mkdir -p logs

INPUT_FILE="$1"
TOKEN="$2"

if [[ -z "$INPUT_FILE" ]]; then
  echo "Usage: $0 <input-file> [token]"
  exit 1
fi

# Use provided token or fall back to GITHUB_TOKEN env var
if [[ -z "$TOKEN" ]]; then
  if [[ -z "$GITHUB_TOKEN" ]]; then
    echo "Error: No token provided. Either pass it as the second argument or set the GITHUB_TOKEN environment variable."
    exit 1
  else
    TOKEN="$GITHUB_TOKEN"
  fi
fi

# Track successes and failures - clear previous logs
> logs/delete_successes.txt
> logs/delete_failures.txt

while IFS= read -r LINE || [ -n "$LINE" ]; do
  [ -z "$LINE" ] && continue
  TGT_REPO=$(echo "$LINE" | awk '{print $2}')
  TGT_ORG=$(echo "$LINE" | awk '{print $4}')
  if [[ -n "$TGT_ORG" && -n "$TGT_REPO" ]]; then
    echo "Deleting repo: $TGT_ORG/$TGT_REPO"
    RESPONSE=$(curl -s -X DELETE \
      -H "Authorization: token $TOKEN" \
      -H "Accept: application/vnd.github+json" \
      "https://api.github.com/repos/$TGT_ORG/$TGT_REPO")
    
    # Save the full response to a log file
    echo "$RESPONSE" > "logs/delete_${TGT_REPO}.log"
    
    # Check if the deletion was successful (empty response means success)
    if [[ -z "$RESPONSE" || "$RESPONSE" != *"message"* ]]; then
      echo "Successfully deleted $TGT_ORG/$TGT_REPO"
      echo "$LINE" >> logs/delete_successes.txt
    else
      echo "Failed to delete $TGT_ORG/$TGT_REPO"
      echo "$LINE" >> logs/delete_failures.txt
    fi
  fi
done < "$INPUT_FILE"

# Print results
# Check if the delete_failures.txt file exists (-f) and is not empty (-s)
if [ -f logs/delete_failures.txt ] && [ -s logs/delete_failures.txt ]; then
  echo ""
  echo "Delete failures:"
  sort -u logs/delete_failures.txt -o logs/delete_failures.txt
  cat logs/delete_failures.txt
else
  echo ""
  echo "No delete failures detected."
fi

if [ -f logs/delete_successes.txt ] && [ -s logs/delete_successes.txt ]; then
  echo ""
  echo "Delete successes:"
  sort -u logs/delete_successes.txt -o logs/delete_successes.txt
  cat logs/delete_successes.txt
else
  echo ""
  echo "No successful deletions detected."
  echo ""
fi
