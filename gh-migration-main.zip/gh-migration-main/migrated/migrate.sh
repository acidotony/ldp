﻿#!/bin/bash

# Usage: ./migrate.sh [repo_file] [source_token] [dest_token]
# This script migrates repositories from a source to a destination organization
# If tokens are not provided, uses SRC_PAT and DEST_PAT environment variables

set +e  # Disable exit-on-error so all migrations are attempted

# Create logs directory
mkdir -p logs

# Set these variables before running, or export them in your shell
REPO_FILE="wave-test.txt"         # Path to your repo list file
MAX_CONCURRENT=10                 # Max concurrent migrations
SOURCE_GHES_API_URL="https://ghe.example.com/api/v3"            # Optional: source GHES API URL
DESTINATION_API_URL=""            # Optional: destination API URL

if [ ! -f "$REPO_FILE" ]; then
  echo "Repository file $REPO_FILE not found!"
  exit 0
fi

if [[ -z "$SRC_PAT" ]]; then
  echo "Please set the SRC_PAT environment variable."
  exit 1
fi

if [[ -z "$DEST_PAT" ]]; then
  echo "Please set the DEST_PAT environment variable."
  exit 1
fi

export GH_PAT="$SRC_PAT"

# Clear previous migration logs
> logs/migration_successes.txt
> logs/migration_failures.txt
> logs/archive_successes.txt
> logs/archive_failures.txt

REPO_NAMES=()
PIDS=()
REPO_LINES=()
i=0
running=0
export no_proxy=localhost,127.0.0.1,exampletest.net,example.net,exampleint.net,example.com,amazon.com,amazonaws.com,.s3.amazonaws.com,ghe.test.example.com,ghe.example.com

while IFS= read -r LINE || [ -n "$LINE" ]; do
  [ -z "$LINE" ] && continue
  # Parse line: SourceRepo TargetRepo SourceOrg TargetOrg
  SRC_REPO=$(echo "$LINE" | awk '{print $1}')
  TGT_REPO=$(echo "$LINE" | awk '{print $2}')
  SRC_ORG=$(echo "$LINE" | awk '{print $3}')
  TGT_ORG=$(echo "$LINE" | awk '{print $4}')
  echo ""
  echo "Starting migration: $SRC_REPO -> $TGT_REPO ($SRC_ORG -> $TGT_ORG)"
  CMD="gh gei migrate-repo \
    --github-source-org \"$SRC_ORG\" \
    --github-target-org \"$TGT_ORG\" \
    --source-repo \"$SRC_REPO\" \
    --target-repo \"$TGT_REPO\" \
    --github-source-pat \"$SRC_PAT\" \
    --github-target-pat \"$DEST_PAT\""

  if [ -n "$SOURCE_GHES_API_URL" ]; then
    CMD="$CMD --ghes-api-url \"$SOURCE_GHES_API_URL\""
  fi
  if [ -n "$DESTINATION_API_URL" ]; then
    CMD="$CMD --target-api-url \"$DESTINATION_API_URL\""
  fi

  echo "Running command: $CMD"
  eval $CMD > "logs/migrate_${SRC_REPO}_to_${TGT_REPO}.log" 2>&1 &
  PIDS[$i]=$!
  REPO_LINES[$i]="$LINE"
  i=$((i+1))
  running=$((running+1))
  if [ "$running" -ge "$MAX_CONCURRENT" ]; then
    wait ${PIDS[$((i-MAX_CONCURRENT))]}
    status=$?
    if [ $status -ne 0 ]; then
      echo "Migration failed for: ${REPO_LINES[$((i-MAX_CONCURRENT))]} (PID ${PIDS[$((i-MAX_CONCURRENT))]})"
      echo "${REPO_LINES[$((i-MAX_CONCURRENT))]}" >> logs/migration_failures.txt
      echo ""
    else
      echo "Migration succeeded for: ${REPO_LINES[$((i-MAX_CONCURRENT))]} (PID ${PIDS[$((i-MAX_CONCURRENT))]})"
      echo "${REPO_LINES[$((i-MAX_CONCURRENT))]}" >> logs/migration_successes.txt
      echo ""
    fi
    running=$((running-1))
  fi
done < "$REPO_FILE"

for idx in "${!PIDS[@]}"; do
  wait ${PIDS[$idx]}
  status=$?
  if [ $status -ne 0 ]; then
    echo "Migration failed for: ${REPO_LINES[$idx]} (PID ${PIDS[$idx]})"
    echo "${REPO_LINES[$idx]}" >> logs/migration_failures.txt
    echo ""
  else
      echo "Migration succeeded for: ${REPO_LINES[$idx]} (PID ${PIDS[$idx]})"
      echo "${REPO_LINES[$idx]}" >> logs/migration_successes.txt
      echo ""
  fi
done

echo ""
echo "Migration operations completed."

# Move octoshift logs to logs directory
echo "Moving octoshift logs to logs directory..."
mv *.octoshift.log logs/ 2>/dev/null || true
mv *.octoshift.verbose.log logs/ 2>/dev/null || true

# create unique lists of migration failures and successes
# Only sort if the files exist
if [ -f logs/migration_failures.txt ]; then
  sort -u logs/migration_failures.txt -o logs/migration_failures.txt
fi
if [ -f logs/migration_successes.txt ]; then
  sort -u logs/migration_successes.txt -o logs/migration_successes.txt
fi
if [ -f logs/migration_successes.txt ]; then
  echo ""
  echo "Archiving successfully migrated repositories in source GHE..."
  ARCHIVE_PIDS=()
  ARCHIVE_REPO_LINES=()
  a=0
  archive_running=0
  
  while IFS= read -r LINE || [ -n "$LINE" ]; do
    [ -z "$LINE" ] && continue
    SRC_REPO=$(echo "$LINE" | awk '{print $1}')
    SRC_ORG=$(echo "$LINE" | awk '{print $3}')
    echo "Starting archive: $SRC_REPO in $SRC_ORG"
    
    # Create a temporary script for this archive
    SCRIPT_FILE="logs/archive_${SRC_REPO}.sh"
    
    # Copy template and replace placeholders
    cp archive_template.sh "$SCRIPT_FILE"
    sed -i "" "s|REPO_ORG|$SRC_ORG|g" "$SCRIPT_FILE"
    sed -i "" "s|REPO_NAME|$SRC_REPO|g" "$SCRIPT_FILE"
    
    # Set API URL
    if [ -n "$SOURCE_GHES_API_URL" ]; then
      sed -i "" "s|API_URL=\"API_URL_PLACEHOLDER\"|API_URL=\"$SOURCE_GHES_API_URL\"|g" "$SCRIPT_FILE"
    else
      sed -i "" "s|API_URL=\"API_URL_PLACEHOLDER\"|API_URL=\"https://api.github.com\"|g" "$SCRIPT_FILE"
    fi
    
    # Make the script executable and run it in background
    chmod +x "$SCRIPT_FILE"
    ./$SCRIPT_FILE > "logs/archive_${SRC_REPO}.log" 2>&1 &
    ARCHIVE_PIDS[$a]=$!
    ARCHIVE_REPO_LINES[$a]="$LINE"
    a=$((a+1))
    archive_running=$((archive_running+1))
    
    # Manage concurrency
    if [ "$archive_running" -ge "$MAX_CONCURRENT" ]; then
      wait ${ARCHIVE_PIDS[$((a-MAX_CONCURRENT))]}
      status=$?
      if [ $status -eq 0 ]; then
        echo "Archive succeeded for: ${ARCHIVE_REPO_LINES[$((a-MAX_CONCURRENT))]} (PID ${ARCHIVE_PIDS[$((a-MAX_CONCURRENT))]})"
        echo "${ARCHIVE_REPO_LINES[$((a-MAX_CONCURRENT))]}" >> logs/archive_successes.txt
      else
        echo "Archive failed for: ${ARCHIVE_REPO_LINES[$((a-MAX_CONCURRENT))]} (PID ${ARCHIVE_PIDS[$((a-MAX_CONCURRENT))]})"
        echo "${ARCHIVE_REPO_LINES[$((a-MAX_CONCURRENT))]}" >> logs/archive_failures.txt
      fi
      archive_running=$((archive_running-1))
    fi
  done < logs/migration_successes.txt
  
  # Wait for remaining archive processes
  for idx in "${!ARCHIVE_PIDS[@]}"; do
    wait ${ARCHIVE_PIDS[$idx]}
    status=$?
    if [ $status -eq 0 ]; then
      echo "Archive succeeded for: ${ARCHIVE_REPO_LINES[$idx]} (PID ${ARCHIVE_PIDS[$idx]})"
      echo "${ARCHIVE_REPO_LINES[$idx]}" >> logs/archive_successes.txt
      echo ""
    else
      echo "Archive failed for: ${ARCHIVE_REPO_LINES[$idx]} (PID ${ARCHIVE_PIDS[$idx]})"
      echo "${ARCHIVE_REPO_LINES[$idx]}" >> logs/archive_failures.txt
      echo ""
    fi
  done
  
  # Print archive summary
  echo ""
  echo "Archive operations completed."
  echo "Detailed logs available in logs/archive_*.log files."
  
  # Print archive results
  if [ -f logs/archive_failures.txt ] && [ -s logs/archive_failures.txt ]; then
    echo "Archive failures:"
    # Sort the file
    sort -u logs/archive_failures.txt -o logs/archive_failures.txt
    cat logs/archive_failures.txt
  else
    echo "No archive failures detected."
  fi
  
  if [ -f logs/archive_successes.txt ] && [ -s logs/archive_successes.txt ]; then
    echo "Archive successes:"
    # Sort the file
    sort -u logs/archive_successes.txt -o logs/archive_successes.txt
    cat logs/archive_successes.txt
  else
    echo "No successful archives detected."
  fi
fi

# Set only successfully migrated repos to internal visibility
echo ""
echo "Setting successfully migrated repos to internal visibility..."
if [ -f logs/migration_successes.txt ]; then
  while IFS= read -r LINE || [ -n "$LINE" ]; do
    [ -z "$LINE" ] && continue
    TGT_REPO=$(echo "$LINE" | awk '{print $2}')
    TGT_ORG=$(echo "$LINE" | awk '{print $4}')
    echo "Setting $TGT_ORG/$TGT_REPO to internal visibility..."
    curl -s -X PATCH \
      -H "Authorization: Bearer ${DEST_PAT}" \
      -H "Content-Type: application/json" \
      -d '{"visibility": "internal"}' \
      "https://api.github.com/repos/$TGT_ORG/$TGT_REPO" > "logs/visibility_${TGT_REPO}.log"
    
    # Capture the exit code immediately
    status=$?
    # Check if the visibility update was successful
    if [ $status -eq 0 ]; then
      echo "Successfully set $TGT_ORG/$TGT_REPO to internal visibility."
      echo ""
    else
      echo "Failed to set $TGT_ORG/$TGT_REPO to internal visibility."
      echo ""
    fi
  done < logs/migration_successes.txt
else
  echo "No successful migrations to update."
  echo ""
fi
