﻿#!/bin/bash
set -x

# This will be replaced with the actual API URL if provided
API_URL="API_URL_PLACEHOLDER"

CMD="curl -s -L -X PATCH \\
  -H \"Accept: application/vnd.github+json\" \\
  -H \"Authorization: Bearer $SRC_PAT\" \\
  -H \"X-GitHub-Api-Version: 2022-11-28\" \\
  -H \"Content-Type: application/json\" \\
  -d '{\"archived\": true}' \\
  \"$API_URL/repos/REPO_ORG/REPO_NAME\""

RESULT=$(eval "$CMD" 2>&1)
echo "$RESULT" > "logs/archive_result_REPO_NAME.json"

if echo "$RESULT" | grep -q "\"archived\": true"; then
  echo "Successfully archived repository."
  exit 0
else
  echo "Failed to archive repository."
  exit 1
fi
