﻿#!/bin/bash

# Usage: ./rollback.sh [repo_file] [source_token] [dest_token]
# This script rolls back repository migrations by deleting them from the destination and unarchiving them in the source
# If tokens are not provided, uses SRC_PAT and DEST_PAT environment variables

set +e  # Disable exit-on-error so all operations are attempted

# Create logs directory
mkdir -p logs

# Set these variables before running, or export them in your shell
REPO_FILE="wave-test.txt"         # Path to your repo list file
MAX_CONCURRENT=10                 # Max concurrent operations
SOURCE_GHES_API_URL="https://ghe.example.com/api/v3"            # Optional: source GHES API URL
DESTINATION_API_URL=""            # Optional: destination API URL

if [ ! -f "$REPO_FILE" ]; then
  echo "Repository file $REPO_FILE not found!"
  exit 0
fi

if [[ -z "$SRC_PAT" ]]; then
  echo "Please set the SRC_PAT environment variable."
  exit 1
fi

if [[ -z "$DEST_PAT" ]]; then
  echo "Please set the DEST_PAT environment variable."
  exit 1
fi

# Step 1: Delete repositories in destination organization
echo "Deleting repositories from destination organization..."

# Use delete.sh script with the destination token
./delete.sh "$REPO_FILE" "$DEST_PAT"

# Clear rollback log files first
> logs/rollback_deletions.txt
> logs/rollback_deletion_failures.txt

# Move the output files from delete.sh to the rollback naming convention
if [ -f "logs/delete_successes.txt" ]; then
  cat logs/delete_successes.txt >> logs/rollback_deletions.txt
  rm logs/delete_successes.txt
fi

if [ -f "logs/delete_failures.txt" ]; then
  cat logs/delete_failures.txt >> logs/rollback_deletion_failures.txt
  rm logs/delete_failures.txt
fi

# Print all rollback logs
if ls logs/rollback_*.log 1> /dev/null 2>&1; then
  echo "Printing all rollback log files:"
  for f in logs/rollback_*.log; do
    echo "--- $f ---"
    cat "$f"
    echo ""
  done
fi

# Print failures and successes
if [ -f logs/rollback_deletion_failures.txt ] && [ -s logs/rollback_deletion_failures.txt ]; then
  echo "Rollback failures:"
  sort -u logs/rollback_deletion_failures.txt -o logs/rollback_deletion_failures.txt
  cat logs/rollback_deletion_failures.txt
  export has_failures=true
  echo ""
else
  echo "No rollback failures detected."
  export has_failures=false
  echo ""
fi

if [ -f logs/rollback_deletions.txt ] && [ -s logs/rollback_deletions.txt ]; then
  echo "Rollback successes:"
  sort -u logs/rollback_deletions.txt -o logs/rollback_deletions.txt
  cat logs/rollback_deletions.txt
  export has_successes=true
  echo ""
else
  export has_successes=false
  echo "No successful rollbacks detected."
  echo ""
fi

# Step 2: Unarchive repositories in source GHE
# We'll unarchive all repositories, regardless of whether they were successfully deleted or not
# Create a combined list of repositories to unarchive
cat "$REPO_FILE" > logs/repos_to_unarchive.txt

if [ -f logs/repos_to_unarchive.txt ]; then
  echo "Unarchiving repositories in source organization..."
  
  # Use unarchive.sh script with the source token and API URL
  ./unarchive.sh logs/repos_to_unarchive.txt "$SRC_PAT" "$SOURCE_GHES_API_URL"
  
  # Clear rollback unarchive log files first
  > logs/rollback_unarchives.txt
  > logs/rollback_unarchive_failures.txt
  
  # Move the output files to the rollback naming convention
  if [ -f "logs/unarchive_successes.txt" ]; then
    cat logs/unarchive_successes.txt >> logs/rollback_unarchives.txt
    rm logs/unarchive_successes.txt
  fi
  
  if [ -f "logs/unarchive_failures.txt" ]; then
    cat logs/unarchive_failures.txt >> logs/rollback_unarchive_failures.txt
    rm logs/unarchive_failures.txt
  fi
  
  # The unarchive.sh script already prints the results, so we don't need to print them again
  # We just need to set the status variables for the GitHub Actions workflow
  if [ -f logs/rollback_unarchive_failures.txt ] && [ -s logs/rollback_unarchive_failures.txt ]; then
    export has_unarchive_failures=true
  else
    export has_unarchive_failures=false
  fi
  
  if [ -f logs/rollback_unarchives.txt ] && [ -s logs/rollback_unarchives.txt ]; then
    export has_unarchive_successes=true
  else
    export has_unarchive_successes=false
  fi
fi

echo "Rollback completed!"
