﻿#!/bin/bash

# Usage: ./unarchive.sh <input-file> [token] [api_url]
# This script unarchives repositories in the source organization
# If token is not provided, uses GITHUB_TOKEN environment variable
# If api_url is not provided, uses SOURCE_GHES_API_URL environment variable or defaults to https://api.github.com

# Create logs directory
mkdir -p logs

INPUT_FILE="$1"
TOKEN="$2"

if [[ -z "$INPUT_FILE" ]]; then
  echo "Usage: $0 <input-file> [token] [api_url]"
  exit 1
fi

API_URL="$3"

# Use provided token or fall back to GITHUB_TOKEN env var
if [[ -z "$TOKEN" ]]; then
  if [[ -z "$GITHUB_TOKEN" ]]; then
    echo "Error: No token provided. Either pass it as the second argument or set the GITHUB_TOKEN environment variable."
    exit 1
  else
    TOKEN="$GITHUB_TOKEN"
  fi
fi

# Use provided API URL or fall back to SOURCE_GHES_API_URL env var or default
if [[ -z "$API_URL" ]]; then
  if [[ -n "$SOURCE_GHES_API_URL" ]]; then
    API_URL="$SOURCE_GHES_API_URL"
  else
    API_URL="https://api.github.com"
  fi
fi

# Track successes and failures - clear previous logs
> logs/unarchive_successes.txt
> logs/unarchive_failures.txt

while IFS= read -r LINE || [ -n "$LINE" ]; do
  [ -z "$LINE" ] && continue
  SRC_REPO=$(echo "$LINE" | awk '{print $1}')
  SRC_ORG=$(echo "$LINE" | awk '{print $3}')
  
  if [[ -n "$SRC_ORG" && -n "$SRC_REPO" ]]; then
    echo "Unarchiving repo: $SRC_ORG/$SRC_REPO"
    RESPONSE=$(curl -s -X PATCH \
      -H "Authorization: token $TOKEN" \
      -H "Accept: application/vnd.github+json" \
      -H "X-GitHub-Api-Version: 2022-11-28" \
      -H "Content-Type: application/json" \
      -d '{"archived": false}' \
      "$API_URL/repos/$SRC_ORG/$SRC_REPO")
    
    # Save the full response to a log file
    echo "$RESPONSE" > "logs/unarchive_${SRC_REPO}.log"
    
    # Check if the unarchive was successful
    if [[ "$RESPONSE" == *'"archived": false'* ]]; then
      echo "Successfully unarchived $SRC_ORG/$SRC_REPO"
      echo "$LINE" >> logs/unarchive_successes.txt
    else
      echo "Failed to unarchive $SRC_ORG/$SRC_REPO"
      echo "$LINE" >> logs/unarchive_failures.txt
    fi
  fi
done < "$INPUT_FILE"

# Print results
if [ -f logs/unarchive_failures.txt ] && [ -s logs/unarchive_failures.txt ]; then
  echo ""
  echo "Unarchive failures:"
  sort -u logs/unarchive_failures.txt -o logs/unarchive_failures.txt
  cat logs/unarchive_failures.txt
else
  echo ""
  echo "No unarchive failures detected."
fi

if [ -f logs/unarchive_successes.txt ] && [ -s logs/unarchive_successes.txt ]; then
  echo ""
  echo "Unarchive successes:"
  sort -u logs/unarchive_successes.txt -o logs/unarchive_successes.txt
  cat logs/unarchive_successes.txt
else
  echo ""
  echo "No successful unarchives detected."
fi
