﻿#!/bin/bash

# check-repos-for-secrets.sh - Check GitHub repositories for open secret scanning alerts
# 
# This script takes a list of repositories in the format used by migration scripts:
# <source-repo> <target-repo> <source-org> <target-org>
# It extracts unique organizations, checks each for open secret scanning alerts,
# and then filters the results to only include repositories that are in the input file.

# Set default values
INPUT_FILE="$1"
HOSTNAME="${2:-api.github.com}"  # Default to GitHub.com if no hostname provided
VERBOSE="${3:-false}"  # Default to non-verbose mode
PARALLEL="${4:-true}"  # Default to parallel mode
MAX_PARALLEL=${MAX_PARALLEL:-10}  # Default to 10 parallel processes

# Check if GitHub CLI is installed
if ! command -v gh &> /dev/null; then
  echo "Error: GitHub CLI (gh) is not installed or not in PATH"
  echo "Please install it from: https://cli.github.com/"
  exit 1
fi

# Check if GitHub CLI is authenticated
if ! gh auth status &> /dev/null; then
  echo "Error: GitHub CLI is not authenticated"
  echo "Please run: gh auth login"
  exit 1
fi

# Check if input file is provided
if [[ -z "$INPUT_FILE" ]]; then
  echo "Usage: $0 <repos-file> [hostname] [verbose] [parallel]"
  echo "  repos-file: File containing repositories in format: <source-repo> <target-repo> <source-org> <target-org>"
  echo "  hostname: GitHub API hostname (default: api.github.com)"
  echo "  verbose: Set to 'true' for verbose output (default: false)"
  echo "  parallel: Set to 'true' to run checks in parallel (default: true)"
  echo "  MAX_PARALLEL: Environment variable to set max parallel processes (default: 10)"
  echo ""
  echo "Example: $0 repos.txt"
  echo "Example: $0 repos.txt github.example.com false true"
  echo "Example: MAX_PARALLEL=20 $0 repos.txt"
  exit 1
fi

if [[ ! -f "$INPUT_FILE" ]]; then
  echo "Error: File $INPUT_FILE not found"
  exit 1
fi

# Extract unique source organizations from the input file
echo "Extracting unique source organizations from $INPUT_FILE..."
ORGS_FILE=$(mktemp)
awk '{print $3}' "$INPUT_FILE" | sort -u > "$ORGS_FILE"
ORG_COUNT=$(wc -l < "$ORGS_FILE")
echo "Found $ORG_COUNT unique source organizations"

# Create a list of source repositories to check
echo "Extracting source repositories from $INPUT_FILE..."
REPOS_FILE=$(mktemp)
awk '{print $1 " " $3}' "$INPUT_FILE" | sort -u > "$REPOS_FILE"
REPO_COUNT=$(wc -l < "$REPOS_FILE")
echo "Found $REPO_COUNT unique source repositories"

# Define output files
OUTPUT_FILE="orgs_with_open_alerts.csv"
ALERTS_ONLY_FILE="orgs_with_open_alerts_only.csv"
DETAILED_FILE="repos_with_open_alerts_detailed.csv"
MIGRATION_ALERTS_FILE="migration_repos_with_alerts.csv"
ERROR_FILE="orgs_with_errors.csv"
echo "Organization,Has Open Alerts,Open Alert Count" > "$OUTPUT_FILE"
echo "Organization,Open Alert Count" > "$ALERTS_ONLY_FILE"
echo "Organization,Repository,Open Alert Count,Secret Types" > "$DETAILED_FILE"
echo "Source Repo,Target Repo,Source Org,Target Org,Open Alert Count,Secret Types" > "$MIGRATION_ALERTS_FILE"
echo "Organization,Error Message" > "$ERROR_FILE"

# Create a temporary directory for parallel processing
TMP_DIR=$(mktemp -d)
trap 'rm -rf "$TMP_DIR" "$ORGS_FILE" "$REPOS_FILE"' EXIT

# Function to show active jobs count
show_active_jobs() {
  local active=$(jobs -r | wc -l | tr -d ' ')
  echo -n "[$active/$MAX_PARALLEL active jobs] "
}

# Function to check an organization for secret scanning alerts
check_org() {
  local org_name="$1"
  local tmp_file="$TMP_DIR/${org_name// /_}.result"
  
  # Generate a random job ID to demonstrate different processes
  local job_id=$RANDOM
  
  # Show job ID when checking an organization
  echo "  [Job:$job_id] Checking organization: $org_name..."
  
  # Use the GitHub CLI to get secret scanning alerts for the organization
  local response=""
  if [[ "$HOSTNAME" == "api.github.com" ]]; then
    # For GitHub.com, no hostname parameter is needed
    response=$(gh api \
      -H "Accept: application/vnd.github+json" \
      -H "X-GitHub-Api-Version: 2022-11-28" \
      "/orgs/$org_name/secret-scanning/alerts?state=open" 2>&1)
  else
    # For GitHub Enterprise, use the hostname parameter
    response=$(gh api \
      -H "Accept: application/vnd.github+json" \
      -H "X-GitHub-Api-Version: 2022-11-28" \
      --hostname "$HOSTNAME" \
      "/orgs/$org_name/secret-scanning/alerts?state=open" 2>&1)
  fi
  
  # Check if the response is valid
  if [[ "$response" == *"Not Found"* || "$response" == *"Resource not accessible"* || "$response" == *"404"* ]]; then
    # Extract error message
    local error_msg="Access denied or organization not found"
    if [[ "$response" == *"message"* ]]; then
      error_msg=$(echo "$response" | grep -o '"message":.*",' | sed 's/"message"://; s/,$//' | tr -d '"')
    fi
    
    if [[ "$VERBOSE" == "true" ]]; then
      echo "    [Job:$job_id] Error: $response"
    fi
    
    # Add to errors file
    echo "$org_name,\"$error_msg\"" >> "$tmp_file.errors"
    echo "    [Job:$job_id] Error for organization $org_name: $error_msg"
    
    # Don't count this as a processed organization
    return
  fi
  
  # Count the alerts
  local alert_count=0
  if [[ "$response" != "[]" && "$response" != "{}" ]]; then
    # Count the number of items in the array
    alert_count=$(echo "$response" | grep -o '"number":' | wc -l | tr -d ' ')
  fi
  
  # Always show response in verbose mode
  if [[ "$VERBOSE" == "true" ]]; then
    echo "    [Job:$job_id] Response: $response"
    echo "    [Job:$job_id] Alert count: $alert_count"
  fi
  
  # Check if we have alerts
  if [[ "$alert_count" -gt 0 ]]; then
    # For parallel processing, write to temp files to avoid race conditions
    echo "$org_name,Yes,$alert_count" >> "$tmp_file.all"
    echo "$org_name,$alert_count" >> "$tmp_file.alerts"
    echo "    [Job:$job_id] Found $alert_count alerts in organization: $org_name"
    
    # Extract repository information from each alert with a simpler approach
    if echo "$response" | jq -e 'length > 0' > /dev/null; then
      # Process each repository separately to avoid complex jq expressions
      # Get unique repositories and their names
      repos=$(echo "$response" | jq -r '.[] | .repository.full_name + "," + .repository.name' | sort | uniq)
      
      while IFS=',' read -r full_repo repo_name; do
        # Count alerts for this repo
        repo_count=$(echo "$response" | jq -r --arg repo "$full_repo" '[.[] | select(.repository.full_name == $repo)] | length')
        
        # Get unique secret types for this repo
        secret_types=$(echo "$response" | jq -r --arg repo "$full_repo" '[.[] | select(.repository.full_name == $repo) | .secret_type] | unique | "[" + join(", ") + "]"')
        
        # Write to detailed file with proper CSV formatting
        echo "$org_name,$repo_name,$repo_count,\"$secret_types\"" >> "$tmp_file.detailed"
        
        # Extract organization from full_repo (format: org/repo)
        repo_org=$(echo "$full_repo" | cut -d'/' -f1)
        
        # Check if this repository is in our migration list
        while IFS=' ' read -r src_repo src_org; do
          if [[ "$repo_name" == "$src_repo" && "$repo_org" == "$src_org" ]]; then
            # Find the full line in the original input file for this repo
            while IFS=' ' read -r orig_src_repo orig_tgt_repo orig_src_org orig_tgt_org; do
              if [[ "$orig_src_repo" == "$src_repo" && "$orig_src_org" == "$src_org" ]]; then
                # Write to migration alerts file
                echo "$orig_src_repo,$orig_tgt_repo,$orig_src_org,$orig_tgt_org,$repo_count,\"$secret_types\"" >> "$tmp_file.migration_alerts"
                break
              fi
            done < "$INPUT_FILE"
            break
          fi
        done < "$REPOS_FILE"
      done <<< "$repos"
    fi
  else
    # Only write to the full output file
    echo "$org_name,No,0" >> "$tmp_file.all"
  fi
}

# Process organizations from the extracted unique orgs file
echo "Processing $ORG_COUNT organizations..."

if [[ "$PARALLEL" == "true" ]]; then
  echo "Running with parallelism: MAX_PARALLEL=$MAX_PARALLEL"
  echo "Starting parallel processing at $(date)"
  
  # Process organizations in parallel
  count=0
  while IFS= read -r org || [[ -n "$org" ]]; do
    # Skip empty lines and comments
    [[ -z "$org" || "$org" == \#* ]] && continue
    
    # Check if we've reached the maximum number of parallel processes
    current_jobs=$(jobs -r | wc -l | tr -d ' ')
    while [[ $current_jobs -ge $MAX_PARALLEL ]]; do
      show_active_jobs  # Show active jobs count
      sleep 0.5
      current_jobs=$(jobs -r | wc -l | tr -d ' ')
    done
    
    # Run check_org in the background
    check_org "$org" &
    
    # Increment counter
    ((count++))
    
    # Show progress every 5 organizations
    if [[ $((count % 5)) -eq 0 ]]; then
      current_jobs=$(jobs -r | wc -l | tr -d ' ')
      echo -e "\nProcessed $count / $ORG_COUNT organizations (Active jobs: $current_jobs)..."
    fi
  done < "$ORGS_FILE"
  
  # Wait for all background jobs to finish
  echo -e "\nWaiting for all checks to complete..."
  wait
  echo "All checks completed at $(date)!"
else
  # Process organizations sequentially
  count=0
  while IFS= read -r org || [[ -n "$org" ]]; do
    # Skip empty lines and comments
    [[ -z "$org" || "$org" == \#* ]] && continue
    
    # Run check_org
    check_org "$org"
    
    # Increment counter
    ((count++))
    
    # Show progress every 5 organizations
    if [[ $((count % 5)) -eq 0 ]]; then
      echo "Processed $count / $ORG_COUNT organizations..."
    fi
  done < "$ORGS_FILE"
  
  echo "All checks completed at $(date)!"
fi

# Combine all temporary files into the output files
echo "Combining results..."
cat "$TMP_DIR"/*.all 2>/dev/null >> "$OUTPUT_FILE" || true
cat "$TMP_DIR"/*.alerts 2>/dev/null >> "$ALERTS_ONLY_FILE" || true
cat "$TMP_DIR"/*.detailed 2>/dev/null >> "$DETAILED_FILE" || true
cat "$TMP_DIR"/*.migration_alerts 2>/dev/null >> "$MIGRATION_ALERTS_FILE" || true
cat "$TMP_DIR"/*.errors 2>/dev/null >> "$ERROR_FILE" || true

# Sort the output files
echo "Sorting results..."

# Create temporary files for sorting
TMP_OUTPUT="$TMP_DIR/sorted_output.csv"
TMP_ALERTS="$TMP_DIR/sorted_alerts.csv"
TMP_DETAILED="$TMP_DIR/sorted_detailed.csv"
TMP_MIGRATION="$TMP_DIR/sorted_migration.csv"
TMP_ERRORS="$TMP_DIR/sorted_errors.csv"

# Get headers
head -1 "$OUTPUT_FILE" > "$TMP_OUTPUT"
head -1 "$ALERTS_ONLY_FILE" > "$TMP_ALERTS"
head -1 "$DETAILED_FILE" > "$TMP_DETAILED"
head -1 "$MIGRATION_ALERTS_FILE" > "$TMP_MIGRATION"
head -1 "$ERROR_FILE" > "$TMP_ERRORS"

# Sort the data (skip header)
tail -n +2 "$OUTPUT_FILE" | sort >> "$TMP_OUTPUT"
tail -n +2 "$ALERTS_ONLY_FILE" | sort >> "$TMP_ALERTS"
tail -n +2 "$DETAILED_FILE" | sort >> "$TMP_DETAILED"
tail -n +2 "$MIGRATION_ALERTS_FILE" | sort >> "$TMP_MIGRATION"
tail -n +2 "$ERROR_FILE" | sort >> "$TMP_ERRORS"

# Replace original files with sorted ones
mv "$TMP_OUTPUT" "$OUTPUT_FILE"
mv "$TMP_ALERTS" "$ALERTS_ONLY_FILE"
mv "$TMP_DETAILED" "$DETAILED_FILE"
mv "$TMP_MIGRATION" "$MIGRATION_ALERTS_FILE"
mv "$TMP_ERRORS" "$ERROR_FILE"

# Count organizations with alerts and errors
orgs_with_alerts=$(grep ",Yes," "$OUTPUT_FILE" | wc -l | tr -d ' ')
total_alerts=$(awk -F, 'NR>1 {sum+=$3} END {print sum}' "$OUTPUT_FILE")
orgs_with_errors=$(tail -n +2 "$ERROR_FILE" | wc -l | tr -d ' ')

# Calculate successful organizations (total minus errors)
successful_orgs=$((count - orgs_with_errors))

echo "Summary:"
echo "--------"
echo "Total organizations attempted: $count"
echo "Organizations successfully processed: $successful_orgs"
echo "Organizations with errors (no access/not found): $orgs_with_errors"
echo "Organizations with open secret alerts: $orgs_with_alerts"
echo "Total number of open alerts found: $total_alerts"

# Count repositories with alerts
repos_with_alerts=$(tail -n +2 "$DETAILED_FILE" | wc -l | tr -d ' ')
migration_repos_with_alerts=$(tail -n +2 "$MIGRATION_ALERTS_FILE" | wc -l | tr -d ' ')
echo "Repositories with open alerts: $repos_with_alerts"
echo "Migration repositories with open alerts: $migration_repos_with_alerts"

echo "Full organization results saved to $OUTPUT_FILE"
echo "Organizations with open alerts saved to $ALERTS_ONLY_FILE"
echo "Detailed repository open alerts saved to $DETAILED_FILE"
echo "Migration repositories with open alerts saved to $MIGRATION_ALERTS_FILE"
echo "Organizations with errors saved to $ERROR_FILE"

# Exit with error code if any migration repositories have alerts
if [[ "$migration_repos_with_alerts" -gt 0 ]]; then
  echo "ERROR: $migration_repos_with_alerts repositories in the migration list have open secret scanning alerts!"
  exit 1
else
  echo "SUCCESS: No repositories in the migration list have open secret scanning alerts."
  exit 0
fi
