#!/bin/bash

# Generate Jenkins Wave File
# Usage: ./generate-jenkins-wave.sh --repo_wave_file <path> --output_file <path> [--no_comments]

set -e

# Default values
REPO_WAVE_FILE="jenkins-scripts/migrations/repo-wave"
OUTPUT_FILE="jenkins-scripts/migrations/jenkins-wave"
NO_COMMENTS=false

# Parse arguments
while [[ "$#" -gt 0 ]]; do
  case "$1" in
    --repo_wave_file)
      REPO_WAVE_FILE="$2"
      shift 2
      ;;
    --output_file)
      OUTPUT_FILE="$2"
      shift 2
      ;;
    --no_comments)
      NO_COMMENTS=true
      shift 1
      ;;
    *)
      echo "Unknown argument: $1"
      exit 1
      ;;
  esac
done

if [[ ! -f "$REPO_WAVE_FILE" ]]; then
  echo "Repo-wave file not found: $REPO_WAVE_FILE. Generating from scan results..."
  mkdir -p $(dirname "$REPO_WAVE_FILE")
  > "$REPO_WAVE_FILE"
  for csv_file in jenkins-scripts/output/j-*.csv; do
    [[ ! -f "$csv_file" ]] && continue
    tail -n +2 "$csv_file" | while IFS=, read -r JobFullName JobUrl GitHubURL Organization RepositoryName; do
      Organization=$(echo "$Organization" | sed 's/^"//;s/"$//')
      RepositoryName=$(echo "$RepositoryName" | sed 's/^"//;s/"$//')
      # Solo si ambos existen
      if [[ -n "$Organization" && -n "$RepositoryName" ]]; then
        # Formato: <source-repo> <target-repo> <source-org> <target-org>
        echo -e "$RepositoryName\t$RepositoryName\t$Organization\t$Organization" >> "$REPO_WAVE_FILE"
      fi
    done
  done
  # Eliminar duplicados
  sort "$REPO_WAVE_FILE" | uniq > "$REPO_WAVE_FILE.tmp" && mv "$REPO_WAVE_FILE.tmp" "$REPO_WAVE_FILE"
  echo "Repo-wave file generated: $REPO_WAVE_FILE"
fi

# Create output directory if needed
OUTPUT_DIR=$(dirname "$OUTPUT_FILE")
mkdir -p "$OUTPUT_DIR"

# Initialize output file
> "$OUTPUT_FILE"

# Add headers if comments are enabled
if [[ "$NO_COMMENTS" != "true" ]]; then
  echo "# Jenkins Wave File - Generated $(date '+%Y-%m-%d %H:%M:%S')" >> "$OUTPUT_FILE"
  echo "# Format: <jenkins_job_url> <target-org> <target-repo>" >> "$OUTPUT_FILE"
  echo "# Processing repositories from: $REPO_WAVE_FILE" >> "$OUTPUT_FILE"
  echo "" >> "$OUTPUT_FILE"
fi

# Read repo mappings into associative arrays
declare -A TARGET_ORG
declare -A TARGET_REPO

while IFS= read -r line || [[ -n "$line" ]]; do
  [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue
  read -r SRC_REPO TARGET_REPO_VAL SRC_ORG TARGET_ORG_VAL <<< "$line"
  if [[ -z "$SRC_REPO" || -z "$TARGET_REPO_VAL" || -z "$SRC_ORG" || -z "$TARGET_ORG_VAL" ]]; then
    echo "Skipping invalid line: $line"
    continue
  fi
  KEY="$SRC_ORG/$SRC_REPO"
  TARGET_ORG["$KEY"]="$TARGET_ORG_VAL"
  TARGET_REPO["$KEY"]="$TARGET_REPO_VAL"
done < "$REPO_WAVE_FILE"

# Process Jenkins CSV files
TOTAL_MATCHES=0
TEMP_MATCHES=$(mktemp)

for csv_file in jenkins-scripts/output/j-*.csv; do
  [[ ! -f "$csv_file" ]] && continue
  tail -n +2 "$csv_file" | while IFS=, read -r JobFullName JobUrl GitHubURL Organization RepositoryName; do
    Organization=$(echo "$Organization" | sed 's/^"//;s/"$//')
    RepositoryName=$(echo "$RepositoryName" | sed 's/^"//;s/"$//')
    JobUrl=$(echo "$JobUrl" | sed 's/^"//;s/"$//')
    [[ -z "$Organization" || -z "$RepositoryName" ]] && continue
    KEY="$Organization/$RepositoryName"
    if [[ -n "${TARGET_ORG[$KEY]}" ]]; then
      echo "$JobUrl ${TARGET_ORG[$KEY]} ${TARGET_REPO[$KEY]}" >> "$TEMP_MATCHES"
      ((TOTAL_MATCHES++))
    fi
  done
done

if [[ -f "$TEMP_MATCHES" && -s "$TEMP_MATCHES" ]]; then
  sort "$TEMP_MATCHES" >> "$OUTPUT_FILE"
fi

rm -f "$TEMP_MATCHES"

echo "SUCCESS: Jenkins Wave File created with $TOTAL_MATCHES entries"
echo "Output file: $OUTPUT_FILE"

# Group jobs by Jenkins server and add headers
if [[ -f "$TEMP_MATCHES" && -s "$TEMP_MATCHES" ]]; then
  echo "Grouping jobs by Jenkins server..."
  while IFS= read -r line; do
    if [[ "$line" =~ https?://([^/]+) ]]; then
      SERVER="${BASH_REMATCH[1]}"
      echo "$SERVER $line"
    else
      echo "unknown $line"
    fi
  done < "$TEMP_MATCHES" | sort | while IFS= read -r grouped_line; do
    SERVER=$(echo "$grouped_line" | cut -d' ' -f1)
    JOB_LINE=$(echo "$grouped_line" | cut -d' ' -f2-)

    # Add server header if comments are enabled
    if [[ "$NO_COMMENTS" != "true" ]]; then
      if [[ "$SERVER" != "$LAST_SERVER" ]]; then
        [[ -n "$LAST_SERVER" ]] && echo "" >> "$OUTPUT_FILE"
        SERVER_COUNT=$(grep -F "$SERVER " "$TEMP_MATCHES" | wc -l)
        echo "# Jenkins Server: $SERVER ($SERVER_COUNT jobs)" >> "$OUTPUT_FILE"
        LAST_SERVER="$SERVER"
      fi
    fi

    echo "$JOB_LINE" >> "$OUTPUT_FILE"
  done
fi

# Summary by Jenkins server
echo "Summary by Jenkins Server:" >> "$OUTPUT_FILE"
if [[ -f "$TEMP_MATCHES" && -s "$TEMP_MATCHES" ]]; then
  awk '{print $1}' "$TEMP_MATCHES" | sort | uniq -c | while read -r count server; do
    echo "  $server: $count jobs" >> "$OUTPUT_FILE"
  done
fi
