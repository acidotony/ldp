#!/usr/bin/env bash
set -euo pipefail

#############################################
# Configuración ingresada por variables env
#############################################

JENKINS_URL="${JENKINS_URL%/}/"
JENKINS_USER="${JENKINS_USER:?Missing}"
JENKINS_TOKEN="${JENKINS_TOKEN:?Missing}"

DOMAINS="${DOMAINS:?Missing}"         # Ej: "ghe.fyiblue.com ghe.test.fyiblue.com"
OUTPUT_CSV="${OUTPUT_CSV:-./jenkins-domain-references.csv}"
START_PATH="${START_PATH:-}"          # Ej: Benefit_Administration/Build_verification
NAME_LIKE="${NAME_LIKE:-}"            # Ej: *Build*
MAX_JOBS="${MAX_JOBS:-0}"             # 0 = No limit
EXCLUDE_DISABLED="${EXCLUDE_DISABLED:-false}"
INCLUDE_RAW="${INCLUDE_RAW:-false}"

AUTH_HEADER=$(printf "%s:%s" "$JENKINS_USER" "$JENKINS_TOKEN" | base64)

#############################################
# Función: Curl JSON API
#############################################
get_json() {
    local url="$1"
    curl -s -H "Authorization: Basic $AUTH_HEADER" \
         -H "Accept: application/json" \
         "$url"
}

#############################################
# Recorrer recursivamente carpetas y jobs
#############################################
jobs_list=()

get_children() {
    local path="$1"
    local segment=""

    if [[ -n "$path" ]]; then
        segment=$(echo "$path" | sed 's#/ #/job/#g')
        segment="job/$segment/"
    fi

    local api="${JENKINS_URL}${segment}api/json?tree=jobs[name,url,color,_class]"

    local json
    json=$(get_json "$api") || return

    echo "$json" | grep -o '{[^}]*}' | while read -r block; do
        local name url color class

        name=$(echo "$block" | grep -o '"name":"[^"]*"'   | sed 's/"name":"//;s/"//')
        url=$(echo "$block"  | grep -o '"url":"[^"]*"'    | sed 's/"url":"//;s/"//')
        color=$(echo "$block"| grep -o '"color":"[^"]*"'  | sed 's/"color":"//;s/"//')
        class=$(echo "$block"| grep -o '"_class":"[^"]*"' | sed 's/"_class":"//;s/"//')

        full="$path"
        [[ -n "$full" ]] && full="$full/$name" || full="$name"

        isFolder=false
        [[ "$class" == *Folder* ]] && isFolder=true

        disabled=false
        [[ "$color" == "disabled" ]] && disabled=true

        jobs_list+=("$full|$url|$disabled|$isFolder")

        if $isFolder; then
            get_children "$full"
        fi
    done
}

#############################################
# Iniciar recorrido
#############################################
get_children "$START_PATH"

#############################################
# Filtrar jobs
#############################################

# Filtrar NameLike
if [[ -n "$NAME_LIKE" ]]; then
    jobs_list=($(printf "%s\n" "${jobs_list[@]}" | grep -E "$(echo "$NAME_LIKE" | sed 's/\*/.*/g')"))
fi

# Excluir jobs disabled
if [[ "$EXCLUDE_DISABLED" == "true" ]]; then
    jobs_list=($(printf "%s\n" "${jobs_list[@]}" | awk -F'|' '$3=="false"'))
fi

#############################################
# Procesar jobs
#############################################

count=0
results=()

for item in "${jobs_list[@]}"; do
    IFS="|" read -r fullname url disabled isFolder <<< "$item"

    # Skip folders
    [[ "$isFolder" == "true" ]] && continue

    # MaxJobs
    if (( MAX_JOBS > 0 && count >= MAX_JOBS )); then
        break
    fi

    count=$((count+1))

    enc=$(echo "$fullname" | sed 's:/:/job/:g')
    config_url="${JENKINS_URL}job/$enc/config.xml"

    config=$(curl -s -H "Authorization: Basic $AUTH_HEADER" "$config_url" || true)

    for domain in $DOMAINS; do
        match=$(echo "$config" | grep -i "$domain" || true)
        [[ -z "$match" ]] && continue

        github=""
        if echo "$match" | grep -qE "https?://"; then
            github=$(echo "$match" | grep -o "https://[^\"<>[:space:]]*${domain}[^\"<>[:space:]]*")
        elif echo "$match" | grep -q "git@"; then
            github=$(echo "$match" | grep -o "git@[^\"<>[:space:]]*${domain}[^\"<>[:space:]]*")
        fi

        org=""
        repo=""

        if [[ "$github" =~ git@[^:]+:([^/]+)/([^/.]+) ]]; then
            org="${BASH_REMATCH[1]}"
            repo="${BASH_REMATCH[2]}"
        elif [[ "$github" =~ https?://[^/]+/([^/]+)/([^/.]+) ]]; then
            org="${BASH_REMATCH[1]}"
            repo="${BASH_REMATCH[2]}"
        fi

        results+=("$fullname,$url,$github,$org,$repo")
    done
done

#############################################
# Generar CSV
#############################################

echo "JobFullName,JobUrl,GitHubURL,Organization,RepositoryName" > "$OUTPUT_CSV"
for row in "${results[@]}"; do
    echo "$row" >> "$OUTPUT_CSV"
done

echo "------------------------------"
echo "Matches: ${#results[@]}"
echo "Jobs processed: $count"
echo "CSV saved: $OUTPUT_CSV"
echo "------------------------------"