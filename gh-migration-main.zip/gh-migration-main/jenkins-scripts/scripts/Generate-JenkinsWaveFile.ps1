<#
.SYNOPSIS
Generate jenkins-wave file from repo-wave file and Jenkins scan results.

.DESCRIPTION
Reads repo-wave file (repository migration mappings) and scans all j-*.csv files
to find Jenkins jobs that reference those repositories. Outputs jenkins-wave file
with Jenkins job URLs mapped to their target organization and repository.

.PARAMETER RepoWaveFile
Path to the repo-wave input file. Default: ./repo-wave
Format: <src-repo> <target-repo> <src-org> <target-org>

.PARAMETER OutputFile
Path for the jenkins-wave output file. Default: ./jenkins-wave
Format: <jenkins_job_url> <target-org> <target-repo>

.PARAMETER NoComments
Exclude comments and headers from the output file.

.EXAMPLE
.\Generate-JenkinsWaveFile.ps1

.EXAMPLE
.\Generate-JenkinsWaveFile.ps1 -RepoWaveFile "my-repo-wave.txt" -OutputFile "my-jenkins-wave.txt"

.EXAMPLE
.\Generate-JenkinsWaveFile.ps1 -NoComments

.OUTPUTS
jenkins-wave file with Jenkins job URLs mapped to target org/repo
#>
[CmdletBinding()]
param(
    [string] $RepoWaveFile = (Join-Path $PSScriptRoot "..\migrations\repo-wave"),
    [string] $OutputFile = (Join-Path $PSScriptRoot "..\migrations\jenkins-wave"),
    [switch] $NoComments
)

try {
    # Check if repo-wave file exists
    if (-not (Test-Path $RepoWaveFile)) {
        Write-Error "repo-wave file not found: $RepoWaveFile"
        exit 1
    }
    
    # Get all j-*.csv files
    $csvFiles = Get-ChildItem -Path (Join-Path $PSScriptRoot "..\output") -Filter "j-*.csv"
    if ($csvFiles.Count -eq 0) {
        Write-Error "No j-*.csv files found in current directory."
        exit 1
    }
    
    Write-Host "Reading repo-wave file: $RepoWaveFile" -ForegroundColor Cyan
    
    # Parse repo-wave file into lookup table
    $repoMappings = @{}
    $repoWaveContent = Get-Content -Path $RepoWaveFile
    $validLineCount = 0
    
    foreach ($line in $repoWaveContent) {
        # Skip empty lines and comments
        if ([string]::IsNullOrWhiteSpace($line) -or $line.Trim().StartsWith('#')) {
            continue
        }
        
        # Parse line: <src-repo> <target-repo> <src-org> <target-org>
        $parts = $line -split '\s+', 4
        if ($parts.Count -ne 4) {
            Write-Warning "Skipping invalid line: $line"
            continue
        }
        
        $srcRepo = $parts[0]
        $targetRepo = $parts[1]
        $srcOrg = $parts[2]
        $targetOrg = $parts[3]
        
        # Create lookup key: org/repo
        $key = "$srcOrg/$srcRepo"
        $repoMappings[$key] = @{
            TargetOrg = $targetOrg
            TargetRepo = $targetRepo
            SourceOrg = $srcOrg
            SourceRepo = $srcRepo
        }
        $validLineCount++
    }
    
    Write-Host "Loaded $validLineCount repository mappings" -ForegroundColor Green
    Write-Host ""
    
    # Scan all j-*.csv files
    Write-Host "Scanning Jenkins CSV files..." -ForegroundColor Cyan
    $jenkinsJobs = @()
    $totalMatches = 0
    
    foreach ($csvFile in $csvFiles) {
        Write-Host "  Processing: $($csvFile.Name)" -ForegroundColor Gray
        
        # Import CSV
        $data = Import-Csv -Path $csvFile.FullName
        
        foreach ($row in $data) {
            # Skip rows with empty organization or repository
            if ([string]::IsNullOrWhiteSpace($row.Organization) -or 
                [string]::IsNullOrWhiteSpace($row.RepositoryName)) {
                continue
            }
            
            # Create lookup key
            $key = "$($row.Organization)/$($row.RepositoryName)"
            
            # Check if this repo is in our migration list
            if ($repoMappings.ContainsKey($key)) {
                $mapping = $repoMappings[$key]
                
                # Extract Jenkins server from JobUrl (e.g., jenkins.esp.fyiblue.com)
                $jenkinsServer = ''
                if ($row.JobUrl -match 'https?://([^/]+)') {
                    $jenkinsServer = $Matches[1]
                }
                
                $jenkinsJobs += [PSCustomObject]@{
                    JobUrl = $row.JobUrl
                    TargetOrg = $mapping.TargetOrg
                    TargetRepo = $mapping.TargetRepo
                    SourceOrg = $row.Organization
                    SourceRepo = $row.RepositoryName
                    JobName = $row.JobFullName
                    JenkinsServer = $jenkinsServer
                }
                $totalMatches++
            }
        }
    }
    
    Write-Host ""
    Write-Host "Found $totalMatches Jenkins jobs matching repositories in repo-wave" -ForegroundColor Green
    
    if ($totalMatches -eq 0) {
        Write-Warning "No matching Jenkins jobs found. jenkins-wave file will be empty."
    }
    
    # Generate jenkins-wave file
    Write-Host ""
    Write-Host "Generating jenkins-wave file: $OutputFile" -ForegroundColor Cyan
    
    $output = @()
    
    if (-not $NoComments) {
        $output += "# Jenkins Wave File - Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        $output += "# Format: <jenkins_job_url> <target-org> <target-repo>"
        $output += "# Total jobs: $totalMatches"
        $output += ""
    }
    
    # Group by Jenkins server for better organization (reduces authentication overhead)
    $groupedJobs = $jenkinsJobs | Group-Object -Property JenkinsServer | Sort-Object Name
    
    foreach ($group in $groupedJobs) {
        if (-not $NoComments) {
            $output += "# Jenkins Server: $($group.Name) ($($group.Count) jobs)"
        }
        
        foreach ($job in ($group.Group | Sort-Object SourceOrg, SourceRepo, JobName)) {
            $line = "$($job.JobUrl) $($job.TargetOrg) $($job.TargetRepo)"
            $output += $line
        }
        
        if (-not $NoComments) {
            $output += ""
        }
    }
    
    # Write output file
    $output | Out-File -FilePath $OutputFile -Encoding UTF8
    
    Write-Host "SUCCESS: jenkins-wave file created with $totalMatches entries" -ForegroundColor Green
    Write-Host ""
    
    # Summary by Jenkins server
    Write-Host "Summary by Jenkins Server:" -ForegroundColor Cyan
    $jenkinsJobs | Group-Object -Property JenkinsServer | Sort-Object Name | ForEach-Object {
        Write-Host "  $($_.Name): $($_.Count) jobs" -ForegroundColor Gray
    }
    
    Write-Host ""
    Write-Host "Output file: $OutputFile" -ForegroundColor Yellow
}
catch {
    Write-Error "Error generating jenkins-wave file: $($_.Exception.Message)"
    exit 1
}
