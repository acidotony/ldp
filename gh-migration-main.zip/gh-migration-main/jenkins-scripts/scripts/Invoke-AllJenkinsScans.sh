#!/usr/bin/env bash

set -euo pipefail

##############################################
# DEFAULT PARAMETERS
##############################################

# Default domains
DOMAINS=("ghe.fyiblue.com" "ghe.test.fyiblue.com")

MAX_JOBS=0
EXCLUDE_DISABLED=true
IGNORE_CERT=true
START_PATH=""
NAME_LIKE=""
SERVERS_TO_SCAN=()

##############################################
# PARSE ARGUMENTS
##############################################
while [[ $# -gt 0 ]]; do
    case "$1" in
        --domains)
            IFS=',' read -r -a DOMAINS <<< "$2"
            shift 2
            ;;
        --max-jobs)
            MAX_JOBS="$2"
            shift 2
            ;;
        --exclude-disabled)
            EXCLUDE_DISABLED=true
            shift 1
            ;;
        --include-disabled)
            EXCLUDE_DISABLED=false
            shift 1
            ;;
        --ignore-cert)
            IGNORE_CERT=true
            shift 1
            ;;
        --start-path)
            START_PATH="$2"
            shift 2
            ;;
        --name-like)
            NAME_LIKE="$2"
            shift 2
            ;;
        --servers)
            IFS=',' read -r -a SERVERS_TO_SCAN <<< "$2"
            shift 2
            ;;
        *)
            echo "Unknown argument: $1"
            exit 1
            ;;
    esac
done

##############################################
# FILE VALIDATION
##############################################

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
JSON_PATH="$SCRIPT_DIR/../config/envs.json"
SCAN_SCRIPT="$SCRIPT_DIR/Get-JenkinsDomainReferences.sh"

if [[ ! -f "$JSON_PATH" ]]; then
    echo "ERROR: envs.json not found at $JSON_PATH"
    exit 1
fi

if [[ ! -f "$SCAN_SCRIPT" ]]; then
    echo "ERROR: Get-JenkinsDomainReferences.sh not found in directory."
    exit 1
fi

##############################################
# LOAD SERVERS FROM JSON
##############################################

ALL_SERVERS=($(jq -r 'keys[]' "$JSON_PATH"))

if [[ ${#SERVERS_TO_SCAN[@]} -eq 0 ]]; then
    SERVERS_TO_PROCESS=("${ALL_SERVERS[@]}")
else
    SERVERS_TO_PROCESS=()

    for s in "${SERVERS_TO_SCAN[@]}"; do
        if jq -e --arg key "$s" '.[$key]' "$JSON_PATH" > /dev/null 2>&1; then
            SERVERS_TO_PROCESS+=("$s")
        else
            echo "WARNING: server '$s' not found in envs.json, skipping."
        fi
    done
fi

if [[ ${#SERVERS_TO_PROCESS[@]} -eq 0 ]]; then
    echo "ERROR: No valid servers to scan."
    exit 1
fi

##############################################
# SCAN LOOP
##############################################

echo "========================================"
echo " Starting Jenkins Domain Scan"
echo "========================================"
echo "Servers to scan: ${#SERVERS_TO_PROCESS[@]}"
echo "Domains: ${DOMAINS[*]}"
echo "Max jobs: ${MAX_JOBS:-No limit}"
echo "Exclude disabled: $EXCLUDE_DISABLED"
echo "========================================"
echo ""

SUCCESS=0
FAIL=0
RESULTS=()

TOTAL_START=$(date +%s)

for (( i=0; i<${#SERVERS_TO_PROCESS[@]}; i++ )); do
    KEY="${SERVERS_TO_PROCESS[$i]}"

    NAME=$(jq -r --arg k "$KEY" '.[$k].name' "$JSON_PATH")
    URL=$(jq -r --arg k "$KEY" '.[$k].url' "$JSON_PATH")
    USER=$(jq -r --arg k "$KEY" '.[$k].username' "$JSON_PATH")
    TOKEN=$(jq -r --arg k "$KEY" '.[$k].token' "$JSON_PATH")

    OUTPUT_FILE="$SCRIPT_DIR/../output/j-$KEY.csv"

    echo "[$((i+1))/${#SERVERS_TO_PROCESS[@]}] Processing: $NAME"
    echo "  URL: $URL"
    echo "  Output: j-$KEY.csv"

    SERVER_START=$(date +%s)

    # Run the scan script
    if "$SCAN_SCRIPT" \
        --url "$URL" \
        --user "$USER" \
        --token "$TOKEN" \
        --domains "${DOMAINS[*]}" \
        --output "$OUTPUT_FILE" \
        --max-jobs "$MAX_JOBS" \
        --exclude-disabled "$EXCLUDE_DISABLED" \
        --ignore-cert "$IGNORE_CERT" \
        --start-path "$START_PATH" \
        --name-like "$NAME_LIKE"
    then
        if [[ -f "$OUTPUT_FILE" ]]; then
            COUNT=$(( $(wc -l < "$OUTPUT_FILE") - 1 ))
            DURATION=$(( $(date +%s) - SERVER_START ))

            echo "  [SUCCESS] $COUNT matches found in ${DURATION}s"
            SUCCESS=$((SUCCESS+1))

            RESULTS+=("$NAME | success | $COUNT | ${DURATION}s | j-$KEY.csv")
        else
            echo "  [WARNING] Output file not created."
            FAIL=$((FAIL+1))
            RESULTS+=("$NAME | no_output | 0 | N/A | N/A")
        fi
    else
        echo "  [ERROR] Scan failed."
        FAIL=$((FAIL+1))
        RESULTS+=("$NAME | error | 0 | N/A | N/A")
    fi

    echo ""
done

TOTAL_END=$(date +%s)
TOTAL_MIN=$(echo "scale=2; ($TOTAL_END - $TOTAL_START) / 60" | bc)

##############################################
# SUMMARY
##############################################

echo "========================================"
echo " Scan Complete"
echo "========================================"
echo "Total servers: ${#SERVERS_TO_PROCESS[@]}"
echo "Successful: $SUCCESS"
echo "Failed: $FAIL"
echo "Total duration: ${TOTAL_MIN} minutes"
echo ""

echo "Results Summary:"
printf "%s\n" "${RESULTS[@]}"

echo ""
echo "Output files located in: $SCRIPT_DIR/../output"