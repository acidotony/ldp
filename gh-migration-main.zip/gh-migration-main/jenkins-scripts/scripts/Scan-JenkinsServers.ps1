<#
.SYNOPSIS
Scan all Jenkins servers for domain references (e.g., GitHub Enterprise URLs).

.DESCRIPTION
Reads all Jenkins server configurations from config/envs.json and scans each server's job configurations
for references to specified domains. Outputs a separate CSV file for each server with naming pattern: j-<server-key>.csv

.PARAMETER Domains
Array of domain substrings to search for (case-insensitive).
Default: 'ghe.fyiblue.com','ghe.test.fyiblue.com'

.PARAMETER MaxJobs
Process at most this many non-folder jobs per server (0 = no limit). Default: 0 (no limit)

.PARAMETER ExcludeDisabled
Skip disabled jobs. Default: enabled

.PARAMETER IgnoreCert
Ignore SSL certificate validation errors. Default: enabled

.PARAMETER StartPath
Optional folder path to limit enumeration scope. Default: '' (scan from root)

.PARAMETER NameLike
Optional wildcard pattern for job names. Default: '' (all jobs)

.PARAMETER ServersToScan
Optional array of server keys to scan. If not specified, scans all servers in envs.json.
Example: @('business', 'claims', 'cs')

.EXAMPLE
# Scan all servers with default domains
.\Scan-JenkinsServers.ps1

.EXAMPLE
# Scan specific servers only
.\Scan-JenkinsServers.ps1 -ServersToScan @('business', 'claims', 'cs')

.EXAMPLE
# Scan with custom domains and limit jobs per server
.\Scan-JenkinsServers.ps1 -Domains 'github.com','gitlab.com' -MaxJobs 100

.OUTPUTS
Creates CSV files named j-<server-key>.csv for each Jenkins server (e.g., j-business.csv, j-claims.csv)
#>
[CmdletBinding()]
param(
    [string[]] $Domains = @('ghe.fyiblue.com', 'ghe.test.fyiblue.com'),
    [int] $MaxJobs = 0,
    [switch] $ExcludeDisabled = $true,
    [switch] $IgnoreCert = $true,
    [string] $StartPath = '',
    [string] $NameLike = '',
    [string[]] $ServersToScan = @()
)

# Check if envs.json exists
$jsonPath = Join-Path $PSScriptRoot "..\config\envs.json"
if (-not (Test-Path $jsonPath)) {
    Write-Error "envs.json file not found in script directory: $PSScriptRoot"
    exit 1
}

# Internal Jenkins Domain Scanning Function
function Invoke-JenkinsDomainScan {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string] $JenkinsUrl,
        [Parameter(Mandatory)][string[]] $Domains,
        [Parameter(Mandatory)][System.Management.Automation.PSCredential] $Credential,
        [string] $OutputCsv = './jenkins-domain-references.csv',
        [string] $StartPath = '',
        [string] $NameLike = '',
        [int] $MaxJobs = 0,
        [switch] $ExcludeDisabled,
        [switch] $IgnoreCert,
        [switch] $IncludeRawConfig
    )
    
    # Initialize
    if ($IgnoreCert) {
        try {
            add-type @"
using System; using System.Net; using System.Security.Cryptography.X509Certificates;
public static class __CertOverride { public static void Apply(){ ServicePointManager.ServerCertificateValidationCallback = (s,c,ch,e)=> true; }}
"@
            [__CertOverride]::Apply()
        } catch { Write-Warning 'Failed to set certificate override.' }
    }
    
    if (-not $JenkinsUrl.EndsWith('/')) { $JenkinsUrl += '/' }
    
    # Build common auth header
    $basic = '{0}:{1}' -f $Credential.UserName, $Credential.GetNetworkCredential().Password
    $b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($basic))
    $headers = @{ Authorization = "Basic $b64"; Accept = 'application/json' }
    $searchDomains = $Domains | ForEach-Object { $_.ToLower() }
    $results = [System.Collections.Generic.List[object]]::new()
    $processed = 0
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

    # Helper functions
    function Get-JenkinsJson([string] $ApiUrl) {
        try {
            $txt = Invoke-RestMethod -Method GET -Uri $ApiUrl -Headers $headers -ErrorAction Stop -UseBasicParsing:$IgnoreCert
            return $txt
        } catch {
            Write-Warning "GET failed: $ApiUrl -> $($_.Exception.Message)"
            return $null
        }
    }

    function Get-Children([string] $BasePath) {
        $segment = if ($BasePath) { ($BasePath -split '/') -join '/job/' } else { '' }
        $api = if ($segment) { "$JenkinsUrl/job/$segment/api/json?tree=jobs[name,url,color,_class]" } else { "$JenkinsUrl/api/json?tree=jobs[name,url,color,_class]" }
        $data = Get-JenkinsJson $api
        if (-not $data) { return @() }
        $acc = @()
        foreach ($j in $data.jobs) {
            $full = if ($BasePath) { "$BasePath/$($j.name)" } else { $j.name }
            $isFolder = $j._class -like '*Folder*'
            $disabled = $j.color -eq 'disabled'
            $obj = [pscustomobject]@{ Name=$j.name; FullName=$full; Url=$j.url; Disabled=$disabled; IsFolder=$isFolder; Class=$j._class }
            $acc += $obj
            if ($isFolder) { $acc += Get-Children $full }
        }
        return $acc
    }

    function Get-ConfigXml([string] $FullName) {
        $encoded = ($FullName -split '/') -join '/job/'
        $url = "$JenkinsUrl/job/$encoded/config.xml"
        try {
            $xml = Invoke-WebRequest -Method GET -Uri $url -Headers $headers -ErrorAction Stop -UseBasicParsing
            return $xml.Content
        } catch {
            Write-Warning "Config fail: $url -> $($_.Exception.Message)"
            return $null
        }
    }

    function Search-XmlForDomains([string] $Xml,[string] $JobName,[string] $JobUrl,[bool] $IsDisabled,[string[]] $DomainsLower) {
        if (-not $Xml) { return }
        $lines = $Xml -split "`n"
        for ($i=0; $i -lt $lines.Length; $i++) {
            $line = $lines[$i]
            $low = $line.ToLower()
            foreach ($d in $DomainsLower) {
                if ($low -like "*${d}*") {
                    # Extract GitHub URL from the line (preserve exact format)
                    $gitHubUrl = ''
                    if ($line -match "https?://[^<>`"'\s]*$d[^<>`"'\s]*") {
                        $gitHubUrl = $Matches[0]
                    } elseif ($line -match "git@[^<>`"'\s]*$d[^<>`"'\s]*") {
                        $gitHubUrl = $Matches[0]
                    }
                    
                    # Extract repository name from GitHub URL
                    $repositoryName = ''
                    $organization = ''
                    if ($gitHubUrl -match 'git@[^:]+:([^/]+)/([^/\.]+)') {
                        # SSH format: git@server:org/repo or git@server:org/repo.git
                        $organization = $Matches[1]
                        $repositoryName = $Matches[2] -replace '\.git$', ''
                    } elseif ($gitHubUrl -match '://[^/]+/([^/]+)/([^/]+)') {
                        # HTTPS format: extract org and repo segments
                        $organization = $Matches[1]
                        $repositoryName = $Matches[2] -replace '\.git$', ''
                    }
                    
                    $obj = [pscustomobject]@{
                        JobFullName = $JobName
                        JobUrl = $JobUrl
                        GitHubURL = $gitHubUrl
                        Organization = $organization
                        RepositoryName = $repositoryName
                    }
                    if ($IncludeRawConfig) { $obj | Add-Member -NotePropertyName RawXml -NotePropertyValue $Xml }
                    $results.Add($obj) | Out-Null
                }
            }
        }
    }

    # Main scanning logic
    $jobs = Get-Children $StartPath
    Write-Verbose "Found $($jobs.Count) total jobs before filtering"
    
    if ($NameLike -and $NameLike.Trim() -ne '') { 
        $jobs = $jobs | Where-Object { $_.FullName -like $NameLike }
        Write-Verbose "After NameLike filter '$NameLike': $($jobs.Count) jobs"
    }
    
    if ($ExcludeDisabled) { 
        $jobs = $jobs | Where-Object { -not $_.Disabled }
        Write-Verbose "After ExcludeDisabled filter: $($jobs.Count) jobs"
    }
    
    $nonFolderJobs = $jobs | Where-Object { -not $_.IsFolder }
    Write-Verbose "Non-folder jobs to process: $($nonFolderJobs.Count)"

    foreach ($j in $jobs) {
        if ($j.IsFolder) { continue }
        if ($MaxJobs -gt 0 -and $processed -ge $MaxJobs) { break }
        $processed++
        Write-Verbose "[$processed] Processing: $($j.FullName)" 
        $xml = Get-ConfigXml $j.FullName
        Search-XmlForDomains -Xml $xml -JobName $j.FullName -JobUrl $j.Url -IsDisabled $j.Disabled -DomainsLower $searchDomains
    }

    # Export results
    $stopwatch.Stop()
    $count = $results.Count
    if ($count -eq 0) { Write-Warning 'No matches found.' }
    
    # Export CSV without quotes for Excel compatibility
    $csvContent = @()
    $csvContent += 'JobFullName,JobUrl,GitHubURL,Organization,RepositoryName'
    
    foreach ($result in $results) {
        $line = @(
            $result.JobFullName,
            $result.JobUrl,
            $result.GitHubURL,
            $result.Organization,
            $result.RepositoryName
        ) -join ','
        $csvContent += $line
    }
    
    $csvContent | Out-File -FilePath $OutputCsv -Encoding UTF8
    Write-Host "Matches: $count | Jobs processed: $processed | Elapsed: $([math]::Round($stopwatch.Elapsed.TotalSeconds,2))s" -ForegroundColor Cyan
    Write-Host "CSV: $OutputCsv"
}

try {
    # Read and parse the JSON file
    $jsonContent = Get-Content -Path $jsonPath -Raw | ConvertFrom-Json
    
    # Get all server keys
    $allServers = $jsonContent.PSObject.Properties.Name
    
    # Determine which servers to scan
    if ($ServersToScan.Count -gt 0) {
        $serversToProcess = $ServersToScan
        # Validate that all specified servers exist
        foreach ($server in $serversToProcess) {
            if ($server -notin $allServers) {
                Write-Warning "Server '$server' not found in envs.json. Skipping."
                $serversToProcess = $serversToProcess | Where-Object { $_ -ne $server }
            }
        }
    } else {
        $serversToProcess = $allServers
    }
    
    if ($serversToProcess.Count -eq 0) {
        Write-Error "No valid servers to scan."
        exit 1
    }
    
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "Starting Jenkins Domain Scan" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "Servers to scan: $($serversToProcess.Count)" -ForegroundColor Green
    Write-Host "Domains: $($Domains -join ', ')" -ForegroundColor Green
    Write-Host "Max Jobs per server: $(if ($MaxJobs -eq 0) { 'No limit' } else { $MaxJobs })" -ForegroundColor Green
    Write-Host "Exclude Disabled: $ExcludeDisabled" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    
    $totalStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $successCount = 0
    $failureCount = 0
    $results = @()
    
    foreach ($serverKey in $serversToProcess) {
        $envConfig = $jsonContent.$serverKey
        $outputFile = Join-Path $PSScriptRoot "..\output\j-$serverKey.csv"
        
        $serverIndex = [array]::IndexOf($serversToProcess, $serverKey) + 1
        Write-Host "[$serverIndex/$($serversToProcess.Count)] Processing: $($envConfig.name)" -ForegroundColor Yellow
        Write-Host "  URL: $($envConfig.url)" -ForegroundColor Gray
        Write-Host "  Output: j-$serverKey.csv" -ForegroundColor Gray
        
        try {
            # Create credential object
            $cred = New-Object System.Management.Automation.PSCredential(
                $envConfig.username, 
                (ConvertTo-SecureString $envConfig.token -AsPlainText -Force)
            )
            
            # Build parameters for the scan function
            $scanParams = @{
                JenkinsUrl = $envConfig.url
                Domains = $Domains
                Credential = $cred
                OutputCsv = $outputFile
                MaxJobs = $MaxJobs
                Verbose = $VerbosePreference
            }
            
            if ($ExcludeDisabled) { $scanParams['ExcludeDisabled'] = $true }
            if ($IgnoreCert) { $scanParams['IgnoreCert'] = $true }
            if ($StartPath) { $scanParams['StartPath'] = $StartPath }
            if ($NameLike) { $scanParams['NameLike'] = $NameLike }
            
            # Execute the internal scan function
            $serverStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
            Invoke-JenkinsDomainScan @scanParams
            $serverStopwatch.Stop()
            
            # Check if output file was created
            if (Test-Path $outputFile) {
                $lineCount = (Get-Content $outputFile).Count - 1  # Subtract header row
                $duration = [math]::Round($serverStopwatch.Elapsed.TotalSeconds,2)
                Write-Host "  [SUCCESS] $lineCount matches found in ${duration}s" -ForegroundColor Green
                $successCount++
                $outputFileName = "j-$serverKey.csv"
                $durationStr = "${duration}s"
                $results += [PSCustomObject]@{
                    Server = $envConfig.name
                    Key = $serverKey
                    Status = 'Success'
                    Matches = $lineCount
                    Duration = $durationStr
                    OutputFile = $outputFileName
                }
            } else {
                Write-Host "  [WARNING] Output file not created" -ForegroundColor Yellow
                $failureCount++
                $duration = [math]::Round($serverStopwatch.Elapsed.TotalSeconds,2)
                $durationStr = "${duration}s"
                $results += [PSCustomObject]@{
                    Server = $envConfig.name
                    Key = $serverKey
                    Status = 'No Output'
                    Matches = 0
                    Duration = $durationStr
                    OutputFile = "N/A"
                }
            }
        }
        catch {
            Write-Host "  [ERROR] $($_.Exception.Message)" -ForegroundColor Red
            $failureCount++
            $results += [PSCustomObject]@{
                Server = $envConfig.name
                Key = $serverKey
                Status = 'Error'
                Matches = 0
                Duration = 'N/A'
                OutputFile = 'N/A'
            }
        }
        
        Write-Host ""
    }
    
    $totalStopwatch.Stop()
    
    # Summary
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "Scan Complete" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "Total servers processed: $($serversToProcess.Count)" -ForegroundColor Green
    Write-Host "Successful: $successCount" -ForegroundColor Green
    Write-Host "Failed: $failureCount" -ForegroundColor $(if ($failureCount -gt 0) { 'Red' } else { 'Green' })
    Write-Host "Total duration: $([math]::Round($totalStopwatch.Elapsed.TotalMinutes,2)) minutes" -ForegroundColor Green
    Write-Host ""
    
    # Display results table
    Write-Host "Results Summary:" -ForegroundColor Cyan
    $results | Format-Table -AutoSize
    
    Write-Host "Output files are located in: $PSScriptRoot" -ForegroundColor Yellow
}
catch {
    Write-Error "Error processing scan: $($_.Exception.Message)"
    exit 1
}
