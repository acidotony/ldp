#!/usr/bin/env bash
set -euo pipefail

# ----------------------------------------
# CONFIGURACIÓN
# ----------------------------------------

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_WAVE_FILE="${REPO_WAVE_FILE:-"$SCRIPT_DIR/../migrations/repo-wave"}"
OUTPUT_FILE="${OUTPUT_FILE:-"$SCRIPT_DIR/../migrations/jenkins-wave"}"
NO_COMMENTS="${NO_COMMENTS:-false}"

CSV_DIR="$SCRIPT_DIR/../output"

# ----------------------------------------
# VALIDACIONES
# ----------------------------------------

if [[ ! -f "$REPO_WAVE_FILE" ]]; then
    echo "ERROR: repo-wave file not found: $REPO_WAVE_FILE" >&2
    exit 1
fi

CSV_FILES=("$CSV_DIR"/j-*.csv)
if [[ ! -e "${CSV_FILES[0]}" ]]; then
    echo "ERROR: No j-*.csv files found in $CSV_DIR" >&2
    exit 1
fi

echo "Reading repo-wave file: $REPO_WAVE_FILE"
declare -A REPO_MAP

# ----------------------------------------
# CARGAR MAPEOS DE repo-wave
# Formato: src-repo target-repo src-org target-org
# ----------------------------------------

VALID_COUNT=0
while IFS= read -r line; do
    [[ -z "$line" || "$line" =~ ^# ]] && continue

    src_repo=$(echo "$line" | awk '{print $1}')
    target_repo=$(echo "$line" | awk '{print $2}')
    src_org=$(echo "$line" | awk '{print $3}')
    target_org=$(echo "$line" | awk '{print $4}')

    key="$src_org/$src_repo"
    REPO_MAP["$key"]="$target_org|$target_repo"
    ((VALID_COUNT++))
done < "$REPO_WAVE_FILE"

echo "Loaded $VALID_COUNT repository mappings"
echo ""

# ----------------------------------------
# PROCESAR CSV DE JENKINS
# ----------------------------------------

echo "Scanning Jenkins CSV files..."

TMP_JOBS=$(mktemp)

TOTAL_MATCHES=0

for csvfile in "${CSV_FILES[@]}"; do
    echo "  Processing: $(basename "$csvfile")"

    # Necesitamos columnas:
    # JobUrl, Organization, RepositoryName, JobFullName

    tail -n +2 "$csvfile" | while IFS=',' read -r JobUrl Organization RepositoryName JobFullName _; do
        
        [[ -z "$Organization" || -z "$RepositoryName" ]] && continue

        key="$Organization/$RepositoryName"

        if [[ -n "${REPO_MAP[$key]:-}" ]]; then
            map="${REPO_MAP[$key]}"
            target_org=$(echo "$map" | cut -d '|' -f1)
            target_repo=$(echo "$map" | cut -d '|' -f2)

            # Extraer nombre del servidor
            jenkins_server=$(echo "$JobUrl" | sed -E 's#https?://([^/]+).*#\1#')

            echo "$JobUrl|$target_org|$target_repo|$Organization|$RepositoryName|$JobFullName|$jenkins_server" \
                >> "$TMP_JOBS"

            ((TOTAL_MATCHES++))
        fi
    done
done

echo ""
echo "Found $TOTAL_MATCHES Jenkins jobs matching repositories in repo-wave"
echo ""

# ----------------------------------------
# GENERAR JENKINS-WAVE
# ----------------------------------------

echo "Generating jenkins-wave file: $OUTPUT_FILE"
{
    if [[ "$NO_COMMENTS" == "false" ]]; then
        echo "# Jenkins Wave File - Generated $(date '+%Y-%m-%d %H:%M:%S')"
        echo "# Format: <jenkins_job_url> <target-org> <target-repo>"
        echo "# Total jobs: $TOTAL_MATCHES"
        echo ""
    fi

    # Agrupar por servidor Jenkins
    sort -t '|' -k7 "$TMP_JOBS" | awk -F '|' '
        BEGIN { last_server = "" }
        {
            server=$7
            if (server != last_server) {
                if (last_server != "" && no_comments == "false") print ""
                if (no_comments == "false") printf("# Jenkins Server: %s\n", server)
                last_server = server
            }
            printf("%s %s %s\n", $1, $2, $3)
        }
    ' no_comments="$NO_COMMENTS"

} > "$OUTPUT_FILE"

echo "SUCCESS: jenkins-wave file created with $TOTAL_MATCHES entries"
echo ""
echo "Summary by Jenkins Server:"
cut -d '|' -f7 "$TMP_JOBS" | sort | uniq -c | while read -r count server; do
    printf "  %s: %s jobs\n" "$server" "$count"
done

echo ""
echo "Output file: $OUTPUT_FILE"

rm -f "$TMP_JOBS"