#!/usr/bin/env bash
set -euo pipefail

OUTPUT_FORMAT="${1:-Console}"
OUTPUT_FILE="${2:-./jenkins-organizations-summary.txt}"

# Directory where j-*.csv files live (equivalent to ../output/)
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
OUTPUT_DIR="$BASE_DIR/../output"

# Find all CSV files
mapfile -t FILES < <(find "$OUTPUT_DIR" -maxdepth 1 -type f -name "j-*.csv" | sort)

if [[ ${#FILES[@]} -eq 0 ]]; then
    echo "WARNING: No j-*.csv files found in $OUTPUT_DIR"
    exit 1
fi

echo "Analyzing ${#FILES[@]} Jenkins server files..."
echo ""

# Temporary storage
SUMMARY_JSON="[]"

jq_add_summary() {
    local key="$1"
    local orgs_json="$2"
    local org_count="$3"
    local repo_count="$4"

    SUMMARY_JSON="$(jq \
        --arg key "$key" \
        --argjson orgs "$orgs_json" \
        --argjson oc "$org_count" \
        --argjson rc "$repo_count" \
        '. += [{
            server: $key,
            organizations: $orgs,
            organizationCount: $oc,
            repositoryCount: $rc
        }]' <<< "$SUMMARY_JSON")"
}

# Process each CSV
for file in "${FILES[@]}"; do
    filename="$(basename "$file")"
    server_key="${filename#j-}"
    server_key="${server_key%.csv}"

    # Extract organizations (column 4)
    mapfile -t ORGS < <(
        awk -F',' 'NR>1 && $4 != "" { print $4 }' "$file" | sort -u
    )

    # Count repos having organizations
    repo_count=$(awk -F',' 'NR>1 && $4 != "" {c++} END{print c+0}' "$file")

    # Prepare JSON array of organizations
    if [[ ${#ORGS[@]} -eq 0 ]]; then
        ORGS_JSON="[]"
    else
        ORGS_JSON="$(printf '%s\n' "${ORGS[@]}" | jq -R . | jq -s .)"
    fi

    jq_add_summary "$server_key" "$ORGS_JSON" "${#ORGS[@]}" "$repo_count"
done

############################################################
# Output section
############################################################
case "$OUTPUT_FORMAT" in
    Console)
        echo "======================================================================"
        echo " GitHub Organizations by Jenkins Server"
        echo "======================================================================"
        echo ""

        echo "$SUMMARY_JSON" | jq -c '.[]' | while read -r item; do
            server=$(jq -r '.server' <<< "$item")
            oc=$(jq -r '.organizationCount' <<< "$item")
            rc=$(jq -r '.repositoryCount' <<< "$item")
            orgs=$(jq -r '.organizations[]?' <<< "$item")

            echo -e "\e[33m${server^^}\e[0m (${oc} organizations, ${rc} repositories)"
            if [[ -z "$orgs" ]]; then
                echo "  (No organizations found)"
            else
                while read -r o; do
                    echo -e "  - $o"
                done <<< "$orgs"
            fi
            echo ""
        done

        # Overall summary
        ALL_ORGS="$(echo "$SUMMARY_JSON" | jq -r '.[].organizations[]?' | sort -u)"
        TOTAL_ORGS=$(echo "$ALL_ORGS" | wc -l | tr -d ' ')
        TOTAL_REPOS=$(echo "$SUMMARY_JSON" | jq '[.[].repositoryCount] | add')

        echo "======================================================================"
        echo "TOTAL: $TOTAL_ORGS unique organizations across all servers"
        echo "TOTAL: $TOTAL_REPOS repository references found"
        echo "======================================================================"
        echo "All unique organizations:"
        while read -r o; do
            echo "  - $o"
        done <<< "$ALL_ORGS"
        echo ""
    ;;

    CSV)
        {
            echo "Server,OrganizationCount,RepositoryCount,Organizations"
            echo "$SUMMARY_JSON" | jq -r '.[] | [.server, .organizationCount, .repositoryCount, (.organizations | join("; "))] | @csv'
        } > "$OUTPUT_FILE"
        echo "CSV output saved to $OUTPUT_FILE"
    ;;

    JSON)
        echo "$SUMMARY_JSON" | jq '.' > "$OUTPUT_FILE"
        echo "JSON output saved to: $OUTPUT_FILE"
    ;;

    *)
        echo "Invalid format. Use: Console | CSV | JSON"
        exit 1
    ;;
esac