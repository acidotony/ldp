# Jenkins Domain Reference Scanner

Scans Jenkins job configurations for references to specified domains (e.g., `ghe.fyiblue.com`). Takes about 20 minutes to scan all Jenkins servers.

## Repository Structure

```
jenkins-scripts/
├── config/          # Configuration files
│   ├── envs.json
│   └── example.envs.json
├── scripts/         # PowerShell scripts
├── output/          # Scan results (j-*.csv)
└── migrations/      # Wave files (repo-wave, jenkins-wave)
```

## Scripts

- **`Scan-JenkinsServers.ps1`** - Scan all Jenkins servers for domain references
- **`Generate-JenkinsWaveFile.ps1`** - Generate jenkins-wave file for migrations

## Quick Start

### 1. Create Configuration File
Create `config/envs.json` based on `config/example.envs.json`:
```json
{
  "cs": {
    "name": "Corporate Services",
    "url": "https://jenkins.cs.fyiblue.com",
    "username": "your_username",
    "token": "your_api_token"
  }
}
```

### 2. Scan the Servers (Two Options)
```powershell
# Scan all servers in envs.json (outputs to output/ directory)
.\scripts\Scan-JenkinsServers.ps1

# Scan specific servers only
.\scripts\Scan-JenkinsServers.ps1 -ServersToScan @('business', 'claims', 'cs')
```

### 3. Generate Jenkins Wave File for Migrations
```powershell
# Use custom file paths
.\scripts\Generate-JenkinsWaveFile.ps1 -RepoWaveFile "migrations\repo-wave" -OutputFile "migrations\jenkins-wave"

# Generate without comments (for automation)
.\scripts\Generate-JenkinsWaveFile.ps1 -NoComments
```

## Key Parameters (Scan-JenkinsServers.ps1)
- `Domains` - Array of domain substrings to search for (default: 'ghe.fyiblue.com','ghe.test.fyiblue.com')
- `ServersToScan` - Array of server keys to scan (default: all servers in envs.json)
- `MaxJobs` - Limit number of jobs to process per server (0 = unlimited)
- `ExcludeDisabled` - Skip disabled jobs (default: enabled)
- `StartPath` - Limit to specific Jenkins folder path
- `NameLike` - Filter jobs by name pattern (e.g., '*Build*')
- `IgnoreCert` - Ignore SSL certificate validation errors (default: enabled)

## Output

Scan results are saved to `output/` directory:
- `j-<server>.csv` - Individual server scan results

CSV columns: JobFullName, JobUrl, GitHubURL, Organization, RepositoryName