#!/bin/bash
#
# fix-incorrect-permissions.sh
#
# This script reads incorrect-permissions-report.csv and fixes team permissions
# to push (write) for each org/repo/team combination.
#
# Usage: ./fix-incorrect-permissions.sh [--dry-run]
#
# Options:
#   --dry-run    Show what would be done without making changes
#
# Prerequisites:
#   - gh CLI authenticated with appropriate permissions
#   - incorrect-permissions-report.csv in the same directory
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPORT_FILE="${SCRIPT_DIR}/team-assignment-report/incorrect-permissions-report.csv"
LOG_FILE="${SCRIPT_DIR}/fix-permissions-$(date +%Y%m%d-%H%M%S).log"
DRY_RUN=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: $0 [--dry-run]"
            exit 1
            ;;
    esac
done

# Check if report file exists
if [[ ! -f "$REPORT_FILE" ]]; then
    echo "Error: Report file not found: $REPORT_FILE"
    exit 1
fi

# Count total entries (excluding header)
TOTAL=$(tail -n +2 "$REPORT_FILE" | wc -l | tr -d ' ')
echo "========================================="
echo "Fix Elevated Permissions"
echo "========================================="
echo ""
echo "Report file: $REPORT_FILE"
echo "Total entries to process: $TOTAL"
echo "Dry run: $DRY_RUN"
echo "Log file: $LOG_FILE"
echo ""

if [[ "$DRY_RUN" == "true" ]]; then
    echo "*** DRY RUN MODE - No changes will be made ***"
    echo ""
fi

# Initialize counters
success_count=0
error_count=0
skipped_count=0

# Process each line (skip header)
# Format: Org,Repo,AppID,Team,PermissionLevel
tail -n +2 "$REPORT_FILE" | while IFS=',' read -r org repo appid team permission_level; do
    # Skip empty lines
    [[ -z "$org" ]] && continue

    echo "Processing: $org/$repo - Team: $team (current: $permission_level)"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo "  [DRY RUN] Would set permission to 'push' for team '$team' on repo '$org/$repo'"
        echo "[DRY RUN] $org,$repo,$team,$permission_level -> push" >> "$LOG_FILE"
    else
        # Use GitHub API to update team permission to push (write)
        # PUT /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}
        result=$(gh api \
            --method PUT \
            -H "Accept: application/vnd.github+json" \
            -H "X-GitHub-Api-Version: 2022-11-28" \
            "/orgs/$org/teams/$team/repos/$org/$repo" \
            -f permission='push' 2>&1) && status=0 || status=$?

        if [[ $status -eq 0 ]]; then
            echo "  ✅ Successfully updated to 'push'"
            echo "[SUCCESS] $org,$repo,$team,$permission_level -> push" >> "$LOG_FILE"
            ((success_count++)) || true
        else
            echo "  ❌ Failed to update: $result"
            echo "[ERROR] $org,$repo,$team,$permission_level - $result" >> "$LOG_FILE"
            ((error_count++)) || true
        fi
    fi
done

echo ""
echo "========================================="
echo "Summary"
echo "========================================="
if [[ "$DRY_RUN" == "true" ]]; then
    echo "Dry run completed. No changes were made."
    echo "Review the log file to see what would be changed: $LOG_FILE"
else
    echo "Successful updates: $success_count"
    echo "Failed updates: $error_count"
    echo "Log file: $LOG_FILE"
fi
echo ""
