#!/bin/bash
#
# add-missing-teams-to-repos.sh
#
# This script reads missing-teams-with-scim-report.csv and adds teams to repositories.
# The report contains teams that have SCIM groups available and need to be assigned.
#
# All teams are assigned 'push' (write) permission.
#
# Usage: ./add-missing-teams-to-repos.sh [--dry-run] [--report <path>]
#
# Options:
#   --dry-run           Show what would be done without making changes
#   --report <path>     Path to the missing teams report CSV (default: team-assignment-report/missing-teams-with-scim-report.csv)
#
# Prerequisites:
#   - gh CLI authenticated with appropriate permissions
#   - Teams must already exist in the destination orgs (SCIM synced)
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPORT_FILE="${SCRIPT_DIR}/team-assignment-report/missing-teams-with-scim-report.csv"
LOG_FILE="${SCRIPT_DIR}/add-missing-teams-$(date +%Y%m%d-%H%M%S).log"
DRY_RUN=false
PERMISSION="push"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --report)
            REPORT_FILE="$2"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: $0 [--dry-run] [--report <path>]"
            exit 1
            ;;
    esac
done

# Check if report file exists
if [[ ! -f "$REPORT_FILE" ]]; then
    echo "Error: Report file not found: $REPORT_FILE"
    exit 1
fi

# Count entries (excluding header)
TOTAL=$(tail -n +2 "$REPORT_FILE" | wc -l | tr -d ' ')

echo "========================================="
echo "Add Missing Teams to Repositories"
echo "========================================="
echo ""
echo "Report file: $REPORT_FILE"
echo "Total entries to process: $TOTAL"
echo "Dry run: $DRY_RUN"
echo "Log file: $LOG_FILE"
echo ""

if [[ "$DRY_RUN" == "true" ]]; then
    echo "*** DRY RUN MODE - No changes will be made ***"
    echo ""
fi

if [[ $TOTAL -eq 0 ]]; then
    echo "No entries found in the report."
    exit 0
fi

# Initialize counters
success_count=0
error_count=0
skipped_count=0

# Write header to log file
echo "Timestamp,Status,Org,Repo,Team,Permission,Details" > "$LOG_FILE"

# Process each line (skip header)
# Format: Org,Repo,AppID,Role,SCIMGroup
# Using process substitution to keep while loop in current shell (preserves counter variables)
while IFS=',' read -r org repo appid role team; do
    # Skip empty lines
    [[ -z "$org" ]] && continue

    timestamp=$(date +%Y-%m-%d\ %H:%M:%S)

    echo "Processing: $org/$repo - Team: $team"

    if [[ "$DRY_RUN" == "true" ]]; then
        echo "  [DRY RUN] Would add team '$team' to repo '$org/$repo' with permission '$PERMISSION'"
        echo "$timestamp,DRY_RUN,$org,$repo,$team,$PERMISSION,Would be added" >> "$LOG_FILE"
    else
        # Use GitHub API to add team to repository
        # PUT /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo}
        result=$(gh api \
            --method PUT \
            -H "Accept: application/vnd.github+json" \
            -H "X-GitHub-Api-Version: 2022-11-28" \
            "/orgs/$org/teams/$team/repos/$org/$repo" \
            -f permission="$PERMISSION" 2>&1) && status=0 || status=$?

        if [[ $status -eq 0 ]]; then
            echo "  ✅ Successfully added with permission '$PERMISSION'"
            echo "$timestamp,SUCCESS,$org,$repo,$team,$PERMISSION,Added successfully" >> "$LOG_FILE"
            ((success_count++)) || true
        else
            # Check if team doesn't exist
            if echo "$result" | grep -q "Could not find"; then
                echo "  ⚠️  Skipped: Team not found (may not be synced yet)"
                echo "$timestamp,SKIPPED,$org,$repo,$team,$PERMISSION,Team not found" >> "$LOG_FILE"
                ((skipped_count++)) || true
            else
                echo "  ❌ Failed to add: $result"
                echo "$timestamp,ERROR,$org,$repo,$team,$PERMISSION,$result" >> "$LOG_FILE"
                ((error_count++)) || true
            fi
        fi
    fi
done < <(tail -n +2 "$REPORT_FILE")

echo ""
echo "========================================="
echo "Summary"
echo "========================================="
if [[ "$DRY_RUN" == "true" ]]; then
    echo "Dry run completed. No changes were made."
    echo "Review the log file to see what would be changed: $LOG_FILE"
else
    echo "Successful additions: $success_count"
    echo "Skipped (team not found): $skipped_count"
    echo "Failed additions: $error_count"
    echo "Log file: $LOG_FILE"
fi
echo ""
