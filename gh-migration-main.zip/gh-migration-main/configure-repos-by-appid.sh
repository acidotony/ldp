#!/bin/bash

# Script to configure GitHub repositories by App ID
# Reads from a CSV file with format: AppID,Org/Repo
# For each repository:
#   1. Adds the AppID as a topic (lowercased)
#   2. Assigns the 4 role-based teams matching the AppID
#
# Team pattern: MSAZURE_APP00006416_GITHUB-{AppID}_*-{role}
# Roles: approver, developer, cicd_maintain, cicd_lead

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INPUT_FILE="${SCRIPT_DIR}/repo_app_ids.txt"

normalize_topic() {
    echo "$1" | tr '[:upper:]' '[:lower:]' | tr '_' '-'
}

normalize_appid() {
    echo "$1" | tr '[:lower:]' '[:upper:]'
}

# Parse command line arguments
while getopts ":i:" opt; do
  case ${opt} in
    i)
      INPUT_FILE=$OPTARG
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      echo "Usage: $0 [-i input_file]"
      exit 1
      ;;
  esac
done

# Verify input file exists
if [ ! -f "${INPUT_FILE}" ]; then
    echo "ERROR: Input file not found: ${INPUT_FILE}"
    exit 1
fi

echo "Starting repository configuration by App ID"
echo "Input file: ${INPUT_FILE}"

ROLES=("approver" "developer" "cicd_maintain" "cicd_lead")
PERMISSION="push"

# Cache: fetch teams once per unique org
declare -A ORG_TEAMS_FETCHED

fetch_org_teams() {
    local org=$1
    if [ -z "${ORG_TEAMS_FETCHED[$org]}" ]; then
        echo "Fetching teams for org: $org"
        gh api --paginate "/orgs/$org/teams" --jq '.[].slug' > "/tmp/teams-${org}.txt" 2>/dev/null
        if [ $? -eq 0 ]; then
            local count
            count=$(wc -l < "/tmp/teams-${org}.txt" | tr -d ' ')
            echo "  Found $count teams in $org"
        else
            echo "  WARNING: Failed to fetch teams for $org"
            > "/tmp/teams-${org}.txt"
        fi
        ORG_TEAMS_FETCHED[$org]=1
    fi
}

total_count=0
topic_success=0
topic_error=0
team_success=0
team_skip=0
team_error=0

while IFS=',' read -r appid org_repo || [ -n "$appid" ]; do
    appid=$(echo "$appid" | xargs)
    org_repo=$(echo "$org_repo" | xargs)

    # Skip header line
    if [[ "$appid" == "appID" ]] || [[ "$appid" == "AppID" ]]; then
        continue
    fi

    # Skip empty lines
    if [ -z "$appid" ] || [ -z "$org_repo" ]; then
        continue
    fi

    ((total_count++))

    org="${org_repo%%/*}"
    repo="${org_repo#*/}"
    topic=$(normalize_topic "$appid")
    appid_upper=$(normalize_appid "$appid")

    echo ""
    echo "Processing: $org_repo (AppID: $appid_upper)"

    # Verify repo exists
    if ! gh api "/repos/${org_repo}" -H "Accept: application/vnd.github+json" >/dev/null 2>&1; then
        echo "  ERROR: Repository not found: ${org_repo}"
        ((topic_error++))
        ((team_error++))
        continue
    fi

    # --- Add AppID as topic ---
    current_topics=$(gh api "/repos/${org_repo}/topics" \
        -H "Accept: application/vnd.github+json" \
        2>/dev/null | jq -r '.names // []')

    if [ $? -ne 0 ]; then
        echo "  ERROR: Failed to get current topics for ${org_repo}"
        ((topic_error++))
    else
        new_topics=$(echo "$current_topics" | jq --arg topic "$topic" '. + [$topic] | unique')
        payload=$(jq -n --argjson names "$new_topics" '{names: $names}')

        response=$(echo "$payload" | gh api "/repos/${org_repo}/topics" \
            -X PUT \
            -H "Accept: application/vnd.github+json" \
            --input - \
            2>&1)

        if [ $? -eq 0 ]; then
            echo "  SUCCESS: Added topic '$topic'"
            ((topic_success++))
        else
            echo "  ERROR: Failed to add topic: ${response}"
            ((topic_error++))
        fi
    fi

    # --- Assign role-based teams ---
    fetch_org_teams "$org"
    team_file="/tmp/teams-${org}.txt"

    for role in "${ROLES[@]}"; do
        matched_team=$(grep -iE "^MSAZURE_APP00006416_GITHUB-${appid_upper}_.*-${role}$" "$team_file" | head -n 1)

        if [ -z "$matched_team" ]; then
            echo "  SKIP: No team found for role '$role'"
            ((team_skip++))
            continue
        fi

        echo "  Assigning team '$matched_team' ($PERMISSION)"

        response=$(gh api \
            --method PUT \
            -H "Accept: application/vnd.github+json" \
            -H "X-GitHub-Api-Version: 2022-11-28" \
            "/orgs/$org/teams/$matched_team/repos/$org/$repo" \
            -f "permission=$PERMISSION" 2>&1)

        if [ $? -eq 0 ]; then
            echo "  SUCCESS: Assigned '$matched_team'"
            ((team_success++))
        else
            echo "  ERROR: Failed to assign '$matched_team': $response"
            ((team_error++))
        fi
    done

    sleep 0.5

done < "${INPUT_FILE}"

# Cleanup temp files
rm -f /tmp/teams-*.txt

echo ""
echo "================================"
echo "Summary:"
echo "Total repositories: ${total_count}"
echo ""
echo "Topics:"
echo "  Successful: ${topic_success}"
echo "  Errors: ${topic_error}"
echo ""
echo "Team Assignments:"
echo "  Successful: ${team_success}"
echo "  Skipped (not found): ${team_skip}"
echo "  Errors: ${team_error}"
echo "================================"
