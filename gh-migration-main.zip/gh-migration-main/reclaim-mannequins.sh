#!/bin/bash

# Script to generate and process mannequin CSV files for reclaiming mannequins
# This script can be used to generate a CSV mapping file from an organization
# and optionally transform the target users by removing _hcsc suffix
#
# Note: The CSV mapping assumes simple format without quoted fields or commas in values.
# The gh gei tool generates CSV in this format.

set -e

# Function to display usage
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Generate and process mannequin CSV files for reclaiming mannequins"
    echo ""
    echo "Options:"
    echo "  -o, --org ORG             Organization name (required)"
    echo "  -f, --output-file FILE    Output CSV file path (default: mannequins-ORG.csv)"
    echo "  -t, --target-api-url URL  Target API URL (optional, for GHEC)"
    echo "  -p, --github-pat TOKEN    GitHub PAT with admin:org scope (required)"
    echo "  -m, --map-users           Map GHEC users to GHE by removing _hcsc suffix"
    echo "  -i, --include-reclaimed   Include already reclaimed mannequins"
    echo "  -h, --help                Display this help message"
    echo ""
    echo "Examples:"
    echo "  # Generate mannequin CSV for an organization"
    echo "  $0 --org my-org --github-pat \$GITHUB_TOKEN"
    echo ""
    echo "  # Generate and map users (remove _hcsc suffix)"
    echo "  $0 --org my-org --github-pat \$GITHUB_TOKEN --map-users"
    echo ""
    exit 1
}

# Parse command line arguments
ORG=""
OUTPUT_FILE=""
TARGET_API_URL=""
GITHUB_PAT=""
MAP_USERS=false
INCLUDE_RECLAIMED=false

while [[ $# -gt 0 ]]; do
    case $1 in
        -o|--org)
            ORG="$2"
            shift 2
            ;;
        -f|--output-file)
            OUTPUT_FILE="$2"
            shift 2
            ;;
        -t|--target-api-url)
            TARGET_API_URL="$2"
            shift 2
            ;;
        -p|--github-pat)
            GITHUB_PAT="$2"
            shift 2
            ;;
        -m|--map-users)
            MAP_USERS=true
            shift
            ;;
        -i|--include-reclaimed)
            INCLUDE_RECLAIMED=true
            shift
            ;;
        -h|--help)
            usage
            ;;
        *)
            echo "Unknown option: $1"
            usage
            ;;
    esac
done

# Validate required parameters
if [ -z "$ORG" ]; then
    echo "Error: Organization name is required"
    usage
fi

if [ -z "$GITHUB_PAT" ]; then
    echo "Error: GitHub PAT is required"
    usage
fi

# Set default output file if not specified
if [ -z "$OUTPUT_FILE" ]; then
    OUTPUT_FILE="mannequins-${ORG}.csv"
fi

# Export PAT for gh CLI
# gh gei commands require GH_PAT environment variable
export GH_PAT="$GITHUB_PAT"
export GH_TOKEN="$GITHUB_PAT"

echo "Generating mannequin CSV for organization: $ORG"

# Build gh gei command
CMD="gh gei generate-mannequin-csv --github-target-org \"$ORG\" --output \"$OUTPUT_FILE\""

# Add optional parameters
if [ -n "$TARGET_API_URL" ]; then
    CMD="$CMD --target-api-url \"$TARGET_API_URL\""
fi

if [ "$INCLUDE_RECLAIMED" = true ]; then
    CMD="$CMD --include-reclaimed"
fi

echo "Running: $CMD"
eval $CMD

if [ $? -ne 0 ]; then
    echo "Error: Failed to generate mannequin CSV"
    exit 1
fi

echo "✓ Mannequin CSV generated: $OUTPUT_FILE"

# Map users if requested
if [ "$MAP_USERS" = true ]; then
    echo "Mapping users: adding _hcsc suffix to mannequin-user to create target-user (normalized to lowercase)"

    # Create temporary file
    TEMP_FILE="${OUTPUT_FILE}.tmp"

    # Process CSV: add _hcsc to mannequin-user to create target-user column (column 3)
    # First line is header, preserve it
    head -n 1 "$OUTPUT_FILE" > "$TEMP_FILE"

    # Process remaining lines using process substitution to avoid subshell
    while IFS=',' read -r mannequin_user mannequin_id target_user; do
        # Convert mannequin_user to lowercase for consistent matching
        mannequin_user_lower=$(echo "$mannequin_user" | tr '[:upper:]' '[:lower:]')

        # Add _hcsc suffix to mannequin_user if not already present
        if [[ "$mannequin_user_lower" == *"_hcsc" ]]; then
            # Already has suffix, use as-is
            mapped_user="$mannequin_user_lower"
        else
            # Add _hcsc suffix
            mapped_user="${mannequin_user_lower}_hcsc"
        fi
        echo "${mannequin_user},${mannequin_id},${mapped_user}" >> "$TEMP_FILE"
    done < <(tail -n +2 "$OUTPUT_FILE")

    # Replace original file with mapped version
    mv "$TEMP_FILE" "$OUTPUT_FILE"

    echo "✓ User mapping completed"
fi

echo ""
echo "Mannequin CSV file ready: $OUTPUT_FILE"
echo "Review and edit the CSV file as needed, then use it with the reclaim-mannequins workflow"
