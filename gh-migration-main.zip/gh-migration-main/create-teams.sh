#!/bin/bash

# create-teams.sh
#
# Purpose:
#   Automates the creation of GitHub teams in destination organizations based on
#   enterprise groups and external group mappings. This script:
#   1. Fetches enterprise groups and their associated app IDs
#   2. Maps source organization app IDs to destination organizations
#   3. Retrieves current teams in destination orgs to avoid duplicates
#   4. Generates a list of teams that need to be created
#   5. Creates teams via GitHub API and links them to external groups
#
# Usage:
#   ./create-teams.sh
#
# Prerequisites:
#   - GitHub CLI (gh) installed and authenticated
#   - Appropriate permissions to read enterprise groups and create teams
#   - jq installed for JSON processing
#
# Configuration:
#   - Update the 'orgs' variable to map source orgs to destination orgs
#   - Ensure output directory exists (migration-test-files/)
#
# Output Files:
#   - enterprise-groups.json: All enterprise groups with app IDs
#   - org-appids.json: App IDs by source organization
#   - current-groups.json: Existing teams in destination orgs
#   - ext-groups.json: External group ID mappings
#   - needed-groups.json: All teams that should exist
#   - missing-groups.json: Teams that need to be created
#

groupsFile="migration-test-files/enterprise-groups.json"
reposFile="migration-test-files/org-appids.json"
currentGroupsFile="migration-test-files/current-groups.json"
extGroupsFile="migration-test-files/ext-groups.json"
neededGroupsFile="migration-test-files/needed-groups.json"
missingGroupsFile="migration-test-files/missing-groups.json"

orgs='''
{
  "dearborn": "hcsc-dearborn",
  "DevOps": "hcsc-devops",
  "HCSC-AnalyticsLab": "hcsc-analyticslab",
  "HCSC-InnerSource": "hcsc-innersource",
  "HCSC-Pilot": "hcsc-core",
  "HCSC-XP": "hcsc-core",
  "paas-engineering": "hcsc-paasengineering",
  "Salesforce": "hcsc-salesforce",
  "TestOrg": "hcsc-test"
}
'''

getEnterpriseGroups() {
  # The scim endpoints don't work with --paginate and so we have to handle it ourselves
  total=$(gh api -X GET scim/v2/enterprises/hcsc/Groups -f excludedAttributes=members,meta,externalId -f count=1 --jq .totalResults)
  # total=105 # useful for faster testing
  count=100
  start=1
  echo "Total enterprise groups to retrieve: $total" 1>&2

  while :; do
    [ $start -gt $total ] && break
    echo "Retrieving GitHub Enterprise groups: index $start" 1>&2
    # Get enterprise groups and return the names as a simple list, delimited by \n
    gh api -X GET scim/v2/enterprises/hcsc/Groups -f excludedAttributes=members,meta,externalId -f startIndex="$start" -f count="$count" --jq '[.Resources[].displayName]'
    start=$((start + count))
  # Store both original name and uppercased name for comparison
  # Structure: {APP_ID: [{name: "Original-Name", nameUpper: "ORIGINAL-NAME"}]}
  done | jq -s 'add | reduce .[] as $role ({}; .[$role | match("MSAZURE_APP00006416_GITHUB-(app[0-9]{8})"; "in").captures[0].string | ascii_upcase] += [{name: $role, nameUpper: ($role | ascii_upcase)}])'
}

# Get all app IDs per org from ghe.fyiblue.com
getOrgAppIds() {
  jq -b -r -n --argjson orgs "$orgs" '$orgs | keys[]' | while read org; do
    echo "Retrieving GHE app IDs by repo for \"$org\"" 1>&2
    GH_HOST=ghe.fyiblue.com gh api "orgs/$org/repos" --paginate | jq "{org: \"$org\", appids: ([.[].topics[] | select(test(\"^app[0-9]{8}$\"; \"i\")) | ascii_upcase] | unique)}"
  done | jq -s '.'
}

# The external groups are fetched from the org. But all hcsc orgs share the same available external groups
# So we hardcode core org and fetch the list of groups only once
# Note: group_name is uppercased to match the case normalization in getEnterpriseGroups
getExtGroups() {
  echo "Retrieving external groups for hcsc-core" 1>&2
  gh api "orgs/hcsc-core/external-groups" --paginate | jq -s '. | [map(.groups[]).[] | {(.group_name | ascii_upcase): .group_id}] | add'
}

# Get all current teams per destination org from github.com
# Note: team names are uppercased to match case normalization elsewhere
getCurrentGroups() {
  jq -b -r -n --argjson orgs "$orgs" '$orgs | map(.) | unique | .[]' | while read org; do
    echo "Retrieving github.com teams for \"$org\"" 1>&2
    gh api "orgs/$org/teams" --paginate | jq " {(\"$org\"): [.[].name | ascii_upcase]}"
  done | jq -s "add"
}

generateNeededGroups() {
  echo "Combining data files to generate list of all necessary groups" 1>&2
  echo " - $groupsFile" 1>&2
  echo " - $extGroupsFile" 1>&2
  echo " - $reposFile" 1>&2
  # Output: {org, name (original case for creation), nameUpper (for comparison), extGroupId}
  jq -n --argjson orgs "$orgs" 'input as $groups | input as $extGroups | input | map($orgs[.org] as $org | .appids[] as $appid | $groups[$appid][]? | {org: $org, name: .name, nameUpper: .nameUpper, extGroupId: $extGroups[.nameUpper]})' $groupsFile $extGroupsFile $reposFile
}

filterNeededGroups() {
  echo "Filtering \"$neededGroupsFile\" based on \"$currentGroupsFile\"" 1>&2
  # Compare using nameUpper (both currentGroups and nameUpper are uppercased)
  jq -n 'input as $currentGroups | input | del(.[] | select(IN(.nameUpper; $currentGroups[.org][])))' $currentGroupsFile $neededGroupsFile
}

createTeams() {
  ghUser=$(gh api user | jq -r .login)
  echo "Creating teams via user '${ghUser}'"
  jq -b -r -n 'input | .[] | [.org, .name, .extGroupId] | @tsv' $missingGroupsFile | while IFS=$'\t' read -r org team groupId; do
    echo "org: '${org}', groupId: '${groupId}', team: '${team}'"
    gh api --silent -X POST orgs/${org}/teams -f "name=${team}" -f privacy=closed \
    && gh api --silent -X DELETE orgs/${org}/teams/${team}/memberships/${ghUser} \
    && gh api --silent -X PATCH orgs/${org}/teams/${team}/external-groups -F "group_id=${groupId}"
  done
}

getEnterpriseGroups > $groupsFile
getOrgAppIds > $reposFile
getExtGroups > $extGroupsFile
getCurrentGroups > $currentGroupsFile
generateNeededGroups > $neededGroupsFile
filterNeededGroups > $missingGroupsFile
createTeams
