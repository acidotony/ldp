#!/bin/bash
# One-time script to fix/cleanup team descriptions across all orgs
# Format: MSAZURE_APP00006416_GITHUB-{appid}_{env}-{role}
# Example: MSAZURE_APP00006416_GITHUB-APP00000061_BAProd-approver -> "The approver team for APP00000061_BAProd."
#
# Usage: ./fix-team-descriptions.sh [--dry-run]
#   --dry-run: Show what would be changed without making changes

set -e

DRY_RUN=false
if [[ "$1" == "--dry-run" ]]; then
  DRY_RUN=true
  echo "🔍 DRY RUN MODE - No changes will be made"
  echo ""
fi

# Ensure gh CLI is authenticated
if ! gh auth status &>/dev/null; then
  echo "❌ Error: Not authenticated with GitHub CLI. Run 'gh auth login' first."
  exit 1
fi

# List of orgs to process
ORGS=(
  "hcsc-core"
  "hcsc-dearborn"
  "hcsc-devops"
  "hcsc-analyticslab"
  "hcsc-innersource"
  "hcsc-paasengineering"
  "hcsc-salesforce"
  "hcsc-test"
)

# Track statistics
total_teams=0
updated_teams=0
skipped_teams=0
failed_teams=0

# Create log files
timestamp=$(date +%Y%m%d_%H%M%S)
log_file="team-description-update-${timestamp}.log"
> "$log_file"

echo "📝 Logging to: $log_file"
echo ""

# Function to parse team name and generate description
generate_description() {
  local team_name="$1"

  # Format: MSAZURE_APP00006416_GITHUB-{appid}_{env}-{role}
  # Example: MSAZURE_APP00006416_GITHUB-APP00000061_BAProd-approver
  if [[ "$team_name" =~ MSAZURE_APP[0-9]+_GITHUB-([^-]+_[^-]+)-(.+)$ ]]; then
    local app_env="${BASH_REMATCH[1]}"
    local role="${BASH_REMATCH[2]}"
    echo "The ${role} team for ${app_env}."
    return 0
  else
    return 1
  fi
}

echo "🚀 Starting team description update..."
echo ""

for org in "${ORGS[@]}"; do
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "📁 Processing organization: $org"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  # Get all teams for the org
  teams_json=$(gh api "orgs/$org/teams" --paginate 2>&1) || {
    echo "  ⚠️  Failed to fetch teams for $org (may need SSO authorization)"
    echo "[$org] FAILED: Could not fetch teams" >> "$log_file"
    continue
  }

  # Parse teams and process each one
  echo "$teams_json" | jq -r '.[] | [.slug, .name, .description // ""] | @tsv' | while IFS=$'\t' read -r slug name current_desc; do
    ((total_teams++)) || true

    # Try to generate new description
    new_desc=$(generate_description "$name") || {
      # No match found, skip this team
      echo "  ⊘ Skipping '$name' (no pattern match)"
      echo "[$org] SKIPPED: $name (no pattern match)" >> "$log_file"
      ((skipped_teams++)) || true
      continue
    }

    # Check if description needs updating
    if [[ "$current_desc" == "$new_desc" ]]; then
      echo "  ✓ '$name' already has correct description"
      echo "[$org] UNCHANGED: $name" >> "$log_file"
      ((skipped_teams++)) || true
      continue
    fi

    # Update the description
    if [[ "$DRY_RUN" == "true" ]]; then
      echo "  🔄 Would update '$name'"
      echo "     Current: '$current_desc'"
      echo "     New:     '$new_desc'"
      echo "[$org] WOULD UPDATE: $name | '$current_desc' -> '$new_desc'" >> "$log_file"
      ((updated_teams++)) || true
    else
      echo "  🔄 Updating '$name'"
      echo "     Current: '$current_desc'"
      echo "     New:     '$new_desc'"

      # Retry logic with exponential backoff for rate limiting
      max_retries=3
      retry_count=0
      success=false

      while [ $retry_count -lt $max_retries ] && [ "$success" = "false" ]; do
        response=$(gh api -X PATCH "orgs/$org/teams/$slug" -f "description=$new_desc" 2>&1) && {
          echo "  ✓ Updated successfully"
          echo "[$org] UPDATED: $name | '$current_desc' -> '$new_desc'" >> "$log_file"
          ((updated_teams++)) || true
          success=true
        } || {
          if echo "$response" | grep -qi "rate limit\|abuse\|secondary"; then
            retry_count=$((retry_count + 1))
            wait_time=$((30 * retry_count))
            echo "  ⏳ Rate limited, waiting ${wait_time}s before retry ($retry_count/$max_retries)..."
            sleep $wait_time
          else
            echo "  ✗ Failed to update: $response"
            echo "[$org] FAILED: $name | Error: $response" >> "$log_file"
            ((failed_teams++)) || true
            break
          fi
        }
      done

      if [ "$success" = "false" ] && [ $retry_count -eq $max_retries ]; then
        echo "  ✗ Failed after $max_retries retries (rate limited)"
        echo "[$org] FAILED: $name | Rate limited after retries" >> "$log_file"
        ((failed_teams++)) || true
      fi

      # Rate limiting - delay between API calls
      sleep 0.1
    fi
  done

  echo ""
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 Summary"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Count results from log file since subshell variables don't persist
if [[ "$DRY_RUN" == "true" ]]; then
  updated_count=$(grep -c "WOULD UPDATE" "$log_file" 2>/dev/null || echo "0")
  echo "Teams that would be updated: $updated_count"
else
  updated_count=$(grep -c "UPDATED:" "$log_file" 2>/dev/null || echo "0")
  failed_count=$(grep -c "FAILED:" "$log_file" 2>/dev/null || echo "0")
  echo "Teams updated: $updated_count"
  echo "Teams failed: $failed_count"
fi

skipped_count=$(grep -c "SKIPPED\|UNCHANGED" "$log_file" 2>/dev/null || echo "0")
echo "Teams skipped: $skipped_count"
echo ""
echo "📝 Full log saved to: $log_file"

if [[ "$DRY_RUN" == "true" ]]; then
  echo ""
  echo "💡 To apply changes, run without --dry-run flag:"
  echo "   ./fix-team-descriptions.sh"
fi
