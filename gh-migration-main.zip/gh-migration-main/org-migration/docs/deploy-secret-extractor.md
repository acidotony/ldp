# deploy-secret-extractor.py

Automates the extraction of GitHub Actions secret values across an entire organization by:

1. Listing all repos in the org
2. For each repo, fetching secret names via API
3. Generating a workflow YAML with each secret hardcoded as an env var
4. Pushing the workflow to the repo **via API — no git clone required**

When the workflow is triggered manually, it prints each secret value **base64-encoded** in the run logs, bypassing GitHub's automatic log masking (which only masks the literal value, not its base64 representation).

> [!WARNING]
> This technique exposes secret values in GitHub Actions workflow logs. Use only in controlled environments, restrict log access to authorized personnel, and run `--cleanup` immediately after collecting the values.

> [!CAUTION]
> Prefer `deploy-cyberark-importer.py` for production migrations — it pushes secrets directly to CyberArk without ever writing values to logs.

## Requirements

- Python 3.6+
- Dependencies: see `requirements.txt` in the `org-migration/` root (`pip install -r requirements.txt`)
- GitHub PAT with the following scopes:
  - `repo` (read/write repo contents + secrets)
  - `workflow` (to push workflow files)

## Usage

```bash
python deploy-secret-extractor.py \
  --org <ORG> \
  --token <TOKEN> \
  [--api-url <URL>] \
  [--concurrency <N>] \
  [--dry-run] \
  [--include-archived] \
  [--cleanup]
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--org` | [required] | — | GitHub organization name |
| `--token` | [required] | — | GitHub PAT |
| `--api-url` | [optional] | `https://api.github.com` | API base URL. For GHES: `https://ghe.example.com/api/v3` |
| `--concurrency` | [optional] | `10` | Parallel pushes |
| `--dry-run` | [optional] | false | Simulate without making any changes |
| `--include-archived` | [optional] | false | Include archived repositories |
| `--cleanup` | [optional] | false | Remove the workflow from all repos |

## Full Workflow

### Step 1 — Deploy the extractor workflow to all repos

```bash
python deploy-secret-extractor.py \
  --org my-org \
  --token ghp_xxxxx \
  --concurrency 20
```

Repos with no secrets are automatically skipped.

### Step 2 — Trigger the workflow in each repo

From the GitHub UI: go to each repo → Actions → `Extract Secrets (TEMPORARY)` → Run workflow.

Or via CLI for all repos at once:

```bash
gh api /orgs/my-org/repos --paginate -q '.[].name' | \
  xargs -P 10 -I {} gh workflow run extract-secrets.yml --repo my-org/{}
```

### Step 3 — Collect and decode the output

In each workflow run log, find the block:

```
=== SECRET VALUES (base64 encoded) ===
DB_PASSWORD=c3VwZXJzZWNyZXQ=
API_KEY=dG9rZW54eXo=
=== END ===
```

Decode each value:

```bash
echo "c3VwZXJzZWNyZXQ=" | base64 -d
# supersecret
```

### Step 4 — Cleanup

Remove the workflow from all repos immediately after collecting the values:

```bash
python deploy-secret-extractor.py \
  --org my-org \
  --token ghp_xxxxx \
  --cleanup
```

> [!IMPORTANT]
> Do not skip the cleanup step. The workflow file contains hardcoded secret names and grants any user with write access the ability to re-run the extraction.

## Behavior Details

| Scenario | Behavior |
|---|---|
| Repo has no secrets | Skipped — no workflow pushed |
| Workflow already exists in repo | Updated in-place (SHA preserved) |
| Archived repo | Skipped by default (use `--include-archived`) |
| `--dry-run` | Prints what would happen, no API writes |
| `--cleanup` | Deletes `extract-secrets.yml` from every repo via API |

## Rate Limits

Each repo requires 2–3 API calls (list secrets + get SHA + push file). With concurrency 20:

| Repos | Estimated time |
|---|---|
| 100 | ~10 seconds |
| 500 | ~45 seconds |
| 2300 | ~4 minutes |

GitHub allows 5,000 requests/hour per PAT. For orgs with 2,000+ repos, stay at `--concurrency 10–20` to avoid hitting the limit.

## Generated Workflow Example

For a repo with secrets `DB_PASSWORD` and `API_KEY`, the pushed workflow looks like:

```yaml
name: Extract Secrets (TEMPORARY - DELETE AFTER USE)
on:
  workflow_dispatch:
jobs:
  extract:
    runs-on: ubuntu-latest
    env:
      DB_PASSWORD: ${{ secrets.DB_PASSWORD }}
      API_KEY: ${{ secrets.API_KEY }}
    steps:
      - name: Print secrets as base64
        run: |
          echo "=== SECRET VALUES (base64 encoded) ==="
          while IFS='=' read -r key value; do
            [ -z "$value" ] && continue
            encoded=$(printf '%s' "$value" | base64 -w 0)
            echo "$key=$encoded"
          done < <(env | sort)
          echo "=== END ==="
```

Secret names are **hardcoded** in the YAML (not dynamic) because GitHub evaluates `${{ secrets.X }}` at parse time — runtime variable interpolation is not supported.

> [!NOTE]
> GitHub's log masking only blocks the literal secret value. The base64-encoded form is not in its blocklist, which is why this technique works. This is a known limitation documented in the GitHub Actions security hardening guide.
