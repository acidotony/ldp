# list-repos-with-variables.py

Scans all repositories in a GitHub organization and reports which ones have repo-level Actions variables configured. Outputs a CSV file with repo name, variable count, and variable names.

> [!NOTE]
> Unlike secrets, variable **values** ARE returned by the GitHub API. This script only reports names/counts in its CSV output; use it for auditing scope before migration.

## Requirements

- Python 3.6+
- Dependencies: see `requirements.txt` in the `org-migration/` root (`pip install -r requirements.txt`)
- GitHub PAT with the following scopes:
  - `repo` (to list repo variables)
  - `read:org` (to list org repos)

## Usage

```bash
python list-repos-with-variables.py \
  --org <ORG> \
  --token <TOKEN> \
  [--api-url <URL>] \
  [--output <FILE>] \
  [--concurrency <N>] \
  [--include-archived]
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--org` | [required] | — | GitHub organization name |
| `--token` | [required] | — | GitHub PAT |
| `--api-url` | [optional] | `https://api.github.com` | API base URL. For GHES: `https://ghe.example.com/api/v3` |
| `--output` | [optional] | `repos_with_variables.csv` | Output CSV file path |
| `--concurrency` | [optional] | `10` | Number of parallel API requests |
| `--include-archived` | [optional] | false | Include archived repositories |

## Examples

```bash
# GitHub.com org
python list-repos-with-variables.py \
  --org my-org \
  --token ghp_xxxxx

# GHES org, higher concurrency, custom output
python list-repos-with-variables.py \
  --org my-org \
  --token ghp_xxxxx \
  --api-url https://ghe.fyiblue.com/api/v3 \
  --output output/variables_audit.csv \
  --concurrency 20 \
  --include-archived
```

## Output

### Console

```
Fetching repos for org: my-org
Found 42 repos. Checking for repo-level variables...
  [1/42] repo-alpha: 2 variable(s)
  [2/42] repo-beta: no variables
  [3/42] repo-gamma: 1 variable(s)
  ...

Repositories with variables: 9 / 42
Results saved to: repos_with_variables.csv

Repository                                         Variables  Names
--------------------------------------------------------------------------------
repo-alpha                                                 2  ENVIRONMENT,REGION
repo-gamma                                                 1  BUILD_TARGET
```

### CSV

```
repository,variable_count,variable_names
repo-alpha,2,"ENVIRONMENT,REGION"
repo-gamma,1,BUILD_TARGET
```
