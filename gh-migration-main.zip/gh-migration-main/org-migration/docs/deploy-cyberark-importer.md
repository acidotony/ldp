# deploy-cyberark-importer.py

Migrates GitHub Actions secrets from an entire organization into CyberArk automatically. For each repo, generates a workflow that reads secret values at runtime and creates/updates accounts in CyberArk via its REST API — no `git clone` needed, no values stored in logs.

Covers all three GitHub secret scopes:
- **Org-level** secrets
- **Repo-level** secrets
- **Environment** secrets (one workflow job per environment)

---

## Requirements

- Python 3.6+
- Dependencies: see `requirements.txt` in the `org-migration/` root (`pip install -r requirements.txt`)
- GitHub PAT with scopes: `repo`, `workflow`
- CyberArk PVWA accessible from GitHub Actions runners

> [!IMPORTANT]
> The following secrets must exist at org level (or in each repo) before triggering the workflow:

| Secret name | Description |
|---|---|
| `CYBERARK_URL` | PVWA base URL, e.g. `https://cyberark.example.com` |
| `CYBERARK_USERNAME` | CyberArk auth username |
| `CYBERARK_PASSWORD` | CyberArk auth password |

> [!TIP]
> Configure these three secrets at org level with `visibility: all` so every repo's generated workflow can access them automatically — no per-repo setup needed.

---

## CyberArk Account Naming Convention

Every secret becomes a CyberArk account with a structured name that encodes its origin:

```
GH-{ORG}-{SCOPE}-{SECRET_NAME}
```

| Secret type | CyberArk account name | Example |
|---|---|---|
| Org secret | `GH-{ORG}-ORG-{SECRET_NAME}` | `GH-myorg-ORG-DB_PASSWORD` |
| Repo secret | `GH-{ORG}-{REPO}-REPO-{SECRET_NAME}` | `GH-myorg-my-repo-REPO-API_KEY` |
| Environment secret | `GH-{ORG}-{REPO}-ENV-{ENV_NAME}-{SECRET_NAME}` | `GH-myorg-my-repo-ENV-production-DEPLOY_KEY` |

This naming makes it easy to:
- Filter by org: search `GH-myorg`
- Filter by repo: search `GH-myorg-my-repo`
- Filter by type: search `-ORG-`, `-REPO-`, `-ENV-`
- Filter by environment: search `-ENV-production-`

---

## Usage

```bash
python deploy-cyberark-importer.py \
  --org <ORG> \
  --token <TOKEN> \
  [--api-url <URL>] \
  [--concurrency <N>] \
  [--dry-run] \
  [--include-archived] \
  [--cleanup]
```

### Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--org` | [required] | — | GitHub organization name |
| `--token` | [required] | — | GitHub PAT |
| `--api-url` | [optional] | `https://api.github.com` | API base URL. For GHES: `https://ghe.fyiblue.com/api/v3` |
| `--concurrency` | [optional] | `10` | Parallel repo processing |
| `--dry-run` | [optional] | false | Simulate without pushing any files |
| `--include-archived` | [optional] | false | Include archived repositories |
| `--cleanup` | [optional] | false | Remove the workflow from all repos |

> [!TIP]
> Always run with `--dry-run` first on a large org to verify the scope before committing changes.

---

## Full Migration Workflow

### Step 1 — Deploy the importer workflow to all repos

```bash
python deploy-cyberark-importer.py \
  --org my-org \
  --token ghp_xxxxx \
  --concurrency 15
```

Console output:
```
Fetching repos for org: my-org
Found 120 repos.

Fetching org-level secrets...
Org secrets: 5

  [1/120] ✓ repo-alpha: created — org=5 repo=3 env=2 (1 environments)
  [2/120] ✓ repo-beta: created — org=5 repo=0 env=0 (0 environments)
  [3/120] ✓ repo-gamma: no secrets (skipped)
  ...
```

### Step 2 — Verify CyberArk prerequisites

Ensure these secrets exist at org level before triggering:

```bash
# Check org secrets exist
gh api /orgs/my-org/actions/secrets -q '.secrets[].name'
# Should include: CYBERARK_URL, CYBERARK_USERNAME, CYBERARK_PASSWORD
```

### Step 3 — Trigger the workflow in all repos

```bash
gh api /orgs/my-org/repos --paginate -q '.[].name' | \
  xargs -P 5 -I {} gh workflow run import-to-cyberark.yml \
    --repo my-org/{} \
    --field cyberark_safe=YOUR_SAFE_NAME
```

Or trigger manually from the GitHub Actions UI: **Actions → Import Secrets to CyberArk → Run workflow**.

### Step 4 — Verify accounts in CyberArk

Search for `GH-my-org` in the CyberArk PVWA to see all imported accounts grouped by org, repo, and type.

### Step 5 — Cleanup

Remove the workflow from all repos once the import is complete:

```bash
python deploy-cyberark-importer.py \
  --org my-org \
  --token ghp_xxxxx \
  --cleanup
```

> [!IMPORTANT]
> Run cleanup as soon as the import is verified in CyberArk. The workflow grants any user who can trigger it the ability to push all secrets into a CyberArk safe.

---

## Generated Workflow Structure

For a repo with org secrets, repo secrets, and a `production` environment, the generated workflow has this structure:

```
jobs:
  import-org-and-repo-secrets       ← handles org + repo secrets
  import-env-production-secrets     ← one job per environment (with environment: production)
  import-env-staging-secrets        ← another environment if present
```

Environment secrets **must** run in a job with `environment: <name>` — this is a GitHub Actions requirement; there is no other way to inject environment-scoped secrets into the runner.

> [!NOTE]
> If an environment has required reviewers or protection rules configured, the job will pause and wait for approval before running. Plan accordingly when triggering the import in bulk.

### Example generated workflow (simplified)

```yaml
name: Import Secrets to CyberArk (TEMPORARY - DELETE AFTER USE)
on:
  workflow_dispatch:
    inputs:
      cyberark_safe:
        description: "CyberArk safe name"
        required: true
        type: string

env:
  CYBERARK_URL: ${{ secrets.CYBERARK_URL }}
  CYBERARK_SAFE: ${{ github.event.inputs.cyberark_safe }}

jobs:
  import-org-and-repo-secrets:
    runs-on: ubuntu-latest
    env:
      CYBERARK_USERNAME: ${{ secrets.CYBERARK_USERNAME }}
      CYBERARK_PASSWORD: ${{ secrets.CYBERARK_PASSWORD }}
      ORG__DB_PASSWORD: ${{ secrets.DB_PASSWORD }}      # org secret
      REPO__API_KEY: ${{ secrets.API_KEY }}              # repo secret
    steps:
      - name: Authenticate to CyberArk
        ...
      - name: Push secrets to CyberArk
        # Iterates env vars by prefix (ORG__ / REPO__)
        # Creates account: GH-myorg-ORG-DB_PASSWORD
        # Creates account: GH-myorg-my-repo-REPO-API_KEY
      - name: Logoff CyberArk

  import-env-production-secrets:
    runs-on: ubuntu-latest
    environment: production
    env:
      ENV__production__DEPLOY_KEY: ${{ secrets.DEPLOY_KEY }}
    steps:
      - name: Authenticate to CyberArk
        ...
      - name: Push environment secrets (production) to CyberArk
        # Creates account: GH-myorg-my-repo-ENV-production-DEPLOY_KEY
      - name: Logoff CyberArk
```

---

## CyberArk API Behavior

For each secret the workflow:

1. **Searches** for an existing account by name (`GET /PasswordVault/API/Accounts?search=...`)
2. If found → **updates** the password (`POST /PasswordVault/API/Accounts/{id}/Password/Update`)
3. If not found → **creates** a new account (`POST /PasswordVault/API/Accounts`) with:
   - `safeName` — from the workflow dispatch input
   - `name` — structured identifier (see naming convention above)
   - `address` — `github.com`
   - `userName` — the secret name
   - `secret` — the secret value
   - `platformId` — `WinServerLocal` (change if needed)

> [!NOTE]
> `platformId` may need to be adjusted to match an existing platform in your CyberArk instance. Common values: `WinServerLocal`, `UnixSSH`, `Oracle`, `MySQL`. Check with your CyberArk admin if account creation fails with a platform-related error.

---

## Script Behavior Reference

| Scenario | Behavior |
|---|---|
| Repo has no secrets of any type | Skipped — no workflow pushed |
| Workflow already exists in repo | Updated in-place (SHA preserved) |
| Archived repo | Skipped by default (`--include-archived` to override) |
| `--dry-run` | Prints what would happen, no API writes |
| `--cleanup` | Deletes `import-to-cyberark.yml` from every repo via API |
| CyberArk account already exists | Password is updated, not duplicated |
| CyberArk account does not exist | New account created in specified safe |

---

## Rate Limits

Each repo requires approximately 3–5 API calls (list secrets + list envs + list env secrets + push file). With `--concurrency 10`:

| Repos | Estimated time |
|---|---|
| 100 | ~20 seconds |
| 500 | ~2 minutes |
| 2300 | ~8 minutes |

GitHub allows 5,000 requests/hour per PAT. For large orgs keep `--concurrency` at 10–15.

> [!CAUTION]
> The CyberArk PVWA may also have its own rate limits or session concurrency caps. Check with your CyberArk admin before running against 2,000+ repos — consider using `--concurrency 5` for the first run.
