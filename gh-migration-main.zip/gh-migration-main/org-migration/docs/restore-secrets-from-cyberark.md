# restore-secrets-from-cyberark.py

Reads GitHub secrets stored in CyberArk (previously imported by `deploy-cyberark-importer.py`) and recreates them in a destination GitHub organization. Handles all three GitHub secret scopes — org, repo, and environment — automatically based on the CyberArk account naming convention.

Zero changes required in any repo: secrets are recreated with the same names, same scopes, and workflows continue using `${{ secrets.X }}` without modification.

> [!IMPORTANT]
> This script is the final step of the secret migration pipeline. Run it only after `deploy-cyberark-importer.py` has successfully imported all secrets into CyberArk and the destination org repos have been created by GEI.

---

## Requirements

- Python 3.6+
- Dependencies: see `requirements.txt` in the `org-migration/` root (`pip install -r requirements.txt`)
- CyberArk PVWA accessible from the machine running the script
- GitHub PAT for the destination org with scopes: `repo`, `secrets` (write)

---

## Secret Migration Pipeline

This script is step 3 of 3:

```
[1] deploy-cyberark-importer.py   -- reads secrets from source GitHub org
                                      writes them to CyberArk as structured accounts
        |
        v
[2] (GEI migration runs)          -- repos are migrated to destination org
        |
        v
[3] restore-secrets-from-cyberark.py  -- reads accounts from CyberArk
                                         recreates secrets in destination org
```

---

## CyberArk Account Naming Convention

The script resolves each account's destination scope from its name:

| Account name pattern | Restored as |
|---|---|
| `GH-{ORG}-ORG-{SECRET_NAME}` | Org-level secret in dest org |
| `GH-{ORG}-{REPO}-REPO-{SECRET_NAME}` | Repo-level secret in dest repo |
| `GH-{ORG}-{REPO}-ENV-{ENV_NAME}-{SECRET_NAME}` | Environment secret in dest repo/env |

> [!NOTE]
> `--source-org` is the **source** org name used when the accounts were originally created in CyberArk (by `deploy-cyberark-importer.py`). It does not need to match `--dest-org`. The script uses it only to match the `GH-{source-org}-*` prefix in CyberArk.

---

## Usage

```bash
python restore-secrets-from-cyberark.py \
  --cyberark-url https://cyberark.example.com \
  --cyberark-username <USERNAME> \
  --cyberark-password <PASSWORD> \
  --cyberark-safe <SAFE_NAME> \
  --source-org <SOURCE_ORG> \
  --dest-org <DEST_ORG> \
  --dest-token <GITHUB_PAT> \
  [--api-url <URL>] \
  [--filter-repo <REPO>] \
  [--dry-run]
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--cyberark-url` | [required] | — | PVWA base URL, e.g. `https://cyberark.example.com` |
| `--cyberark-username` | [required] | — | CyberArk auth username |
| `--cyberark-password` | [required] | — | CyberArk auth password |
| `--cyberark-safe` | [required] | — | Safe where secrets were imported |
| `--source-org` | [required] | — | Source org name (to match account names in CyberArk) |
| `--dest-org` | [required] | — | Destination org name on GitHub.com |
| `--dest-token` | [required] | — | GitHub PAT for the destination org |
| `--api-url` | [optional] | `https://api.github.com` | GitHub API base URL |
| `--filter-repo` | [optional] | (all) | Restore secrets only for a specific repo |
| `--dry-run` | [optional] | false | Simulate without writing anything to GitHub |

---

## Examples

### Full org restoration

```bash
python restore-secrets-from-cyberark.py \
  --cyberark-url https://cyberark.example.com \
  --cyberark-username admin \
  --cyberark-password secret \
  --cyberark-safe GH_MIGRATION_SAFE \
  --source-org my-source-org \
  --dest-org my-dest-org \
  --dest-token ghp_xxxxx
```

### Dry run first (recommended)

```bash
python restore-secrets-from-cyberark.py \
  --cyberark-url https://cyberark.example.com \
  --cyberark-username admin \
  --cyberark-password secret \
  --cyberark-safe GH_MIGRATION_SAFE \
  --source-org my-source-org \
  --dest-org my-dest-org \
  --dest-token ghp_xxxxx \
  --dry-run
```

### Restore secrets for a single repo only

```bash
python restore-secrets-from-cyberark.py \
  ... \
  --filter-repo my-specific-repo
```

> [!TIP]
> Use `--filter-repo` to restore a single repo first and validate before running the full org. Useful when testing or when a specific repo's migration needs to be retried.

---

## Console Output

```
Secret restoration plan
  Source org   : my-source-org
  Dest org     : my-dest-org
  CyberArk safe: GH_MIGRATION_SAFE
  API URL      : https://api.github.com
  Dry run      : False
  Filter repo  : (all)

Authenticating to CyberArk: https://cyberark.example.com
Authenticated to CyberArk.

Searching CyberArk safe 'GH_MIGRATION_SAFE' for accounts matching: GH-my-source-org
Found 87 account(s).

Accounts to restore: org=5 repo=61 env=21

  [1/87] [org]  my-dest-org / DB_PASSWORD
          -> OK
  [2/87] [repo] my-dest-org/repo-alpha / API_KEY
          -> OK
  [3/87] [env]  my-dest-org/repo-beta (production) / DEPLOY_KEY
          -> OK
  ...

Logged off from CyberArk.

============================================================
SUMMARY  Total: 87  |  OK: 85  |  Failed: 2  |  Skipped: 0
```

---

## Behavior Details

| Scenario | Behavior |
|---|---|
| Secret already exists in dest | Overwritten with the CyberArk value |
| Environment does not exist in dest repo | Created automatically before writing the secret |
| Account name does not match any pattern | Skipped with `[SKIP]` log entry |
| CyberArk fetch fails | Logged as `[FAIL]`, continues with next secret |
| GitHub API write fails | Logged as `[FAIL]`, continues with next secret |
| `--dry-run` | Logs what would happen, no writes to GitHub or CyberArk |
| Script exits with code `1` | One or more secrets failed — check `[FAIL]` entries |

> [!WARNING]
> Org-level secrets are restored with `visibility: all` by default, making them accessible to all repos in the org. If the source org had restricted visibility (e.g. selected repos only), you will need to update visibility manually after restoration.

---

## How Secret Encryption Works

GitHub's API requires secrets to be encrypted client-side before upload using the repo or org's public key (libsodium sealed box / X25519). The script:

1. Fetches the target's public key once per org/repo/environment (cached to avoid redundant calls)
2. Encrypts the value with `PyNaCl` `SealedBox`
3. Sends the base64-encoded ciphertext to the GitHub API

> [!NOTE]
> Public keys are cached in memory per run. If the script is interrupted and restarted, keys are re-fetched automatically.

---

## Exit Codes

| Code | Meaning |
|---|---|
| `0` | All secrets restored successfully |
| `1` | One or more secrets failed — review `[FAIL]` entries in output |
