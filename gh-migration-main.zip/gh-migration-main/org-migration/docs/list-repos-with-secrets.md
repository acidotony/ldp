# list-repos-with-secrets.py

Scans all repositories in a GitHub organization and reports which ones have Actions secrets configured. Outputs a CSV file with repo name, secret count, and secret names.

> [!NOTE]
> Only secret **names** are accessible via the GitHub API. Values are never returned regardless of permission level.

## Requirements

- Python 3.6+
- Dependencies: see `requirements.txt` in the `org-migration/` root (`pip install -r requirements.txt`)
- GitHub PAT with the following scopes:
  - `repo` (to list repo secrets)
  - `read:org` (to list org repos)

## Usage

```bash
python list-repos-with-secrets.py \
  --org <ORG> \
  --token <TOKEN> \
  [--api-url <URL>] \
  [--output <FILE>] \
  [--concurrency <N>] \
  [--include-archived]
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--org` | [required] | — | GitHub organization name |
| `--token` | [required] | — | GitHub PAT |
| `--api-url` | [optional] | `https://api.github.com` | API base URL. For GHES: `https://ghe.example.com/api/v3` |
| `--output` | [optional] | `repos_with_secrets.csv` | Output CSV file path |
| `--concurrency` | [optional] | `10` | Number of parallel API requests |
| `--include-archived` | [optional] | false | Include archived repositories |

## Examples

```bash
# GitHub.com org
python list-repos-with-secrets.py \
  --org my-org \
  --token ghp_xxxxx

# GHES org, higher concurrency, custom output
python list-repos-with-secrets.py \
  --org my-org \
  --token ghp_xxxxx \
  --api-url https://ghe.fyiblue.com/api/v3 \
  --output output/secrets_audit.csv \
  --concurrency 20 \
  --include-archived
```

## Output

### Console

```
Fetching repos for org: my-org
Found 42 repos. Checking for secrets...
  [1/42] repo-alpha: 3 secret(s)
  [2/42] repo-beta: no secrets
  [3/42] repo-gamma: 1 secret(s)
  ...

Repositories with secrets: 12 / 42
Results saved to: repos_with_secrets.csv

Repository                                         Secrets  Names
--------------------------------------------------------------------------------
repo-alpha                                               3  DB_PASSWORD,API_KEY,TOKEN
repo-gamma                                               1  DEPLOY_KEY
```

### CSV

```
repository,secret_count,secret_names
repo-alpha,3,DB_PASSWORD,API_KEY,TOKEN
repo-gamma,1,DEPLOY_KEY
```

## Rate Limits

Each repo requires 1 API request. With default concurrency of 10:

| Repos | Estimated time |
|---|---|
| 100 | ~5 seconds |
| 500 | ~25 seconds |
| 2300 | ~2 minutes |

GitHub allows 5,000 requests/hour per PAT. For large orgs (2,000+ repos), stay within this limit by keeping `--concurrency` at 10–20.

> [!TIP]
> Run this script first before `deploy-cyberark-importer.py` to get a clear picture of which repos have secrets and how many, so you can estimate the CyberArk import scope.
