# migrate-webhooks.py

Migrates repo-level webhooks from a source org to a destination org.

> [!IMPORTANT]
> GitHub's API never returns a webhook's **secret** value (write-only), so it cannot be read from the source and copied automatically. This script recreates each webhook's config (URL, content type, events, active flag) and:
> - Applies `--default-secret` to any migrated webhook that originally had a secret configured, if provided.
> - Otherwise creates the webhook **without** a secret and reports it under `needs_secret` so it can be set manually in the destination repo.

## Requirements

- Python 3.6+
- Dependencies: see `requirements.txt` in the `org-migration/` root (`pip install -r requirements.txt`)
- GitHub PAT for the source org with scope: `admin:repo_hook` (read)
- GitHub PAT for the destination org with scope: `admin:repo_hook` (write)

## How it works

For every repo in the source org (or a single repo via `--filter-repo`):

1. List all repo-level webhooks (`GET /repos/{org}/{repo}/hooks`).
2. Skip any webhook whose URL already exists on the destination repo (idempotent re-runs).
3. Create the webhook on the destination repo (`POST /repos/{org}/{repo}/hooks`) with the same URL, content type, events, and active flag.
4. If the source webhook had a secret and `--default-secret` was provided, apply it to the new webhook. Otherwise the webhook is created without a secret and flagged as `needs_secret`.

Repos without any repo-level webhooks are skipped (not an error).

## Usage

```bash
python migrate-webhooks.py \
  --source-org <SOURCE_ORG> \
  --source-token <SOURCE_TOKEN> \
  --dest-org <DEST_ORG> \
  --dest-token <DEST_TOKEN> \
  [--api-url <SOURCE_API_URL>] \
  [--dest-api-url <DEST_API_URL>] \
  [--filter-repo <REPO>] \
  [--default-secret <SECRET>] \
  [--skip-inactive] \
  [--concurrency <N>] \
  [--include-archived] \
  [--dry-run]
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--source-org` | [required] | — | Source org name |
| `--source-token` | [required] | — | GitHub PAT for the source org |
| `--dest-org` | [required] | — | Destination org name |
| `--dest-token` | [required] | — | GitHub PAT for the destination org |
| `--api-url` | [optional] | `https://api.github.com` | Source GitHub API base URL. For GHES: `https://ghe.example.com/api/v3` |
| `--dest-api-url` | [optional] | `https://api.github.com` | Destination GitHub API base URL |
| `--filter-repo` | [optional] | (all) | Restrict migration to a single repo |
| `--default-secret` | [optional] | (none) | Secret value applied to migrated webhooks that had a secret configured in the source |
| `--skip-inactive` | [optional] | false | Do not migrate disabled webhooks |
| `--concurrency` | [optional] | `10` | Number of repos processed in parallel |
| `--include-archived` | [optional] | false | Include archived repositories |
| `--dry-run` | [optional] | false | Simulate without writing anything to the destination |

## Examples

### Full org migration

```bash
python migrate-webhooks.py \
  --source-org my-source-org \
  --source-token ghp_xxxxx \
  --dest-org my-dest-org \
  --dest-token ghp_yyyyy
```

### Dry run first (recommended)

```bash
python migrate-webhooks.py \
  --source-org my-source-org \
  --source-token ghp_xxxxx \
  --dest-org my-dest-org \
  --dest-token ghp_yyyyy \
  --dry-run
```

### With a shared secret applied to all secured webhooks

```bash
python migrate-webhooks.py \
  --source-org my-source-org \
  --source-token ghp_xxxxx \
  --dest-org my-dest-org \
  --dest-token ghp_yyyyy \
  --default-secret "$WEBHOOK_SHARED_SECRET"
```

## Output

```
Migrating repo-level webhooks for 42 repo(s): my-source-org -> my-dest-org
  [skip] repo-beta: no repo-level webhooks
  [ok]   repo-alpha:https://ci.example.com/hooks/gh -
  [warn] repo-gamma:https://slack.example.com/hooks/gh - created WITHOUT secret - set manually

OK           : 1
Failed       : 0
Skipped      : 39
Needs secret : 1

Webhooks created WITHOUT a secret (set manually):
  [warn] repo-gamma:https://slack.example.com/hooks/gh: created WITHOUT secret - set manually
```

Exit code is non-zero if any webhook failed to migrate.
