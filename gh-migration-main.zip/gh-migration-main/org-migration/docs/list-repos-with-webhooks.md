# list-repos-with-webhooks.py

Scans all repositories in a GitHub organization and reports which ones have repo-level webhooks configured. Outputs a CSV file with repo name, webhook count, and webhook URLs.

> [!NOTE]
> Webhook **secret** values are write-only in the GitHub API and are never returned, regardless of permission level. This script only reports whether a secret is configured (`has_secret`), not its value.

## Requirements

- Python 3.6+
- Dependencies: see `requirements.txt` in the `org-migration/` root (`pip install -r requirements.txt`)
- GitHub PAT with the following scopes:
  - `admin:repo_hook` (to list repo webhooks)
  - `read:org` (to list org repos)

## Usage

```bash
python list-repos-with-webhooks.py \
  --org <ORG> \
  --token <TOKEN> \
  [--api-url <URL>] \
  [--output <FILE>] \
  [--concurrency <N>] \
  [--include-archived]
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--org` | [required] | — | GitHub organization name |
| `--token` | [required] | — | GitHub PAT |
| `--api-url` | [optional] | `https://api.github.com` | API base URL. For GHES: `https://ghe.example.com/api/v3` |
| `--output` | [optional] | `repos_with_webhooks.csv` | Output CSV file path |
| `--concurrency` | [optional] | `10` | Number of parallel API requests |
| `--include-archived` | [optional] | false | Include archived repositories |

## Examples

```bash
# GitHub.com org
python list-repos-with-webhooks.py \
  --org my-org \
  --token ghp_xxxxx

# GHES org, higher concurrency, custom output
python list-repos-with-webhooks.py \
  --org my-org \
  --token ghp_xxxxx \
  --api-url https://ghe.fyiblue.com/api/v3 \
  --output output/webhooks_audit.csv \
  --concurrency 20 \
  --include-archived
```

## Output

### Console

```
Fetching repos for org: my-org
Found 42 repos. Checking for webhooks...
  [1/42] repo-alpha: 1 webhook(s)
  [2/42] repo-beta: no webhooks
  [3/42] repo-gamma: 2 webhook(s)
  ...

Repositories with webhooks: 7 / 42
Results saved to: repos_with_webhooks.csv

Repository                                         Webhooks  URLs
--------------------------------------------------------------------------------
repo-alpha                                                1  https://ci.example.com/hooks/gh
repo-gamma                                                2  https://ci.example.com/hooks/gh,https://slack.example.com/hooks/gh
```

### CSV

```
repository,webhook_count,webhook_urls
repo-alpha,1,https://ci.example.com/hooks/gh
repo-gamma,2,"https://ci.example.com/hooks/gh,https://slack.example.com/hooks/gh"
```
