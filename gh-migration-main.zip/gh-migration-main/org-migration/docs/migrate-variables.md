# migrate-variables.py

Migrates repo-level GitHub Actions variables from a source org to a destination org.

Unlike secrets, variable **values** are readable via the GitHub API, so this script copies them directly from source to destination using two GitHub PATs — no external vault (e.g. CyberArk) is required.

## Requirements

- Python 3.6+
- Dependencies: see `requirements.txt` in the `org-migration/` root (`pip install -r requirements.txt`)
- GitHub PAT for the source org with scope: `repo` (read)
- GitHub PAT for the destination org with scope: `repo` (write) / `actions:write`

## How it works

For every repo in the source org (or a single repo via `--filter-repo`):

1. List all repo-level Actions variables (`GET /repos/{org}/{repo}/actions/variables`).
2. For each variable, check whether it already exists in the destination repo.
3. `PATCH` to update if it exists, otherwise `POST` to create it.

Repos without any repo-level variables are skipped (not an error).

## Usage

```bash
python migrate-variables.py \
  --source-org <SOURCE_ORG> \
  --source-token <SOURCE_TOKEN> \
  --dest-org <DEST_ORG> \
  --dest-token <DEST_TOKEN> \
  [--api-url <SOURCE_API_URL>] \
  [--dest-api-url <DEST_API_URL>] \
  [--filter-repo <REPO>] \
  [--concurrency <N>] \
  [--include-archived] \
  [--dry-run]
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--source-org` | [required] | — | Source org name |
| `--source-token` | [required] | — | GitHub PAT for the source org |
| `--dest-org` | [required] | — | Destination org name |
| `--dest-token` | [required] | — | GitHub PAT for the destination org |
| `--api-url` | [optional] | `https://api.github.com` | Source GitHub API base URL. For GHES: `https://ghe.example.com/api/v3` |
| `--dest-api-url` | [optional] | `https://api.github.com` | Destination GitHub API base URL |
| `--filter-repo` | [optional] | (all) | Restrict migration to a single repo |
| `--concurrency` | [optional] | `10` | Number of repos processed in parallel |
| `--include-archived` | [optional] | false | Include archived repositories |
| `--dry-run` | [optional] | false | Simulate without writing anything to the destination |

## Examples

### Full org migration

```bash
python migrate-variables.py \
  --source-org my-source-org \
  --source-token ghp_xxxxx \
  --dest-org my-dest-org \
  --dest-token ghp_yyyyy
```

### Dry run first (recommended)

```bash
python migrate-variables.py \
  --source-org my-source-org \
  --source-token ghp_xxxxx \
  --dest-org my-dest-org \
  --dest-token ghp_yyyyy \
  --dry-run
```

### Single repo

```bash
python migrate-variables.py \
  --source-org my-source-org \
  --source-token ghp_xxxxx \
  --dest-org my-dest-org \
  --dest-token ghp_yyyyy \
  --filter-repo my-repo
```

## Output

```
Migrating repo-level variables for 42 repo(s): my-source-org -> my-dest-org
  [skip] repo-beta: no repo-level variables
  [ok]   repo-alpha: ENVIRONMENT
  [ok]   repo-alpha: REGION
  [ok]   repo-gamma: BUILD_TARGET

OK      : 3
Failed  : 0
Skipped : 39
```

Exit code is non-zero if any variable failed to migrate.
