"""
autolink_references — Repo-level autolink reference migration utilities.

Autolink references (e.g. JIRA-123 -> https://jira.example.com/browse/JIRA-123)
are fully readable/writable via the REST API, so migration is a direct copy
from source to destination.

Exposed functions:
    list_repos_with_autolinks(api_url, org, token, include_archived, concurrency) -> list[dict]
    migrate_repo_autolinks(args) -> dict {success, failed, skipped}
"""

import importlib.util
import pathlib
from types import SimpleNamespace

_HERE = pathlib.Path(__file__).parent


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, _HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def list_repos_with_autolinks(
    api_url, org, token, include_archived=False, concurrency=10
):
    """
    Scan all repos in an org and return those that have autolink references.
    Returns list of dicts: {repo, autolink_count, key_prefixes}
    """
    mod = _load("list-repos-with-autolinks.py")
    repos = mod.get_all_repos(org, token, api_url, include_archived)

    import concurrent.futures
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as ex:
        futures = {
            ex.submit(mod.get_repo_autolinks, org, repo, token, api_url): repo
            for repo in repos
        }
        for future in concurrent.futures.as_completed(futures):
            repo_name, count, rows = future.result()
            if count > 0:
                results.append({
                    "repo": repo_name,
                    "autolink_count": count,
                    "key_prefixes": [r["key_prefix"] for r in rows],
                })

    results.sort(key=lambda r: r["repo"])
    return results


def migrate_repo_autolinks(
    source_org, dest_org, source_token, dest_token,
    api_url="https://api.github.com", dest_api_url="https://api.github.com",
    filter_repo=None, concurrency=10, include_archived=False, dry_run=False,
):
    """
    Migrate repo-level autolink references from source org to destination org.
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    mod = _load("migrate-autolinks.py")

    args = SimpleNamespace(
        source_org=source_org,
        dest_org=dest_org,
        source_token=source_token,
        dest_token=dest_token,
        api_url=api_url,
        dest_api_url=dest_api_url,
        filter_repo=filter_repo,
        concurrency=concurrency,
        include_archived=include_archived,
        dry_run=dry_run,
    )

    return mod.migrate_all(args)
