#!/usr/bin/env python3
"""
Migrates repo-level autolink references from a source org to a destination org.

Autolink references are simple metadata (key_prefix, url_template,
is_alphanumeric) and are fully readable/writable via the REST API, so this
is a direct copy — no external vault or manual hand-off required.

Requirements:
    pip install requests

Usage:
    python migrate-autolinks.py \
        --source-org <SOURCE_ORG> \
        --source-token <SOURCE_TOKEN> \
        --dest-org <DEST_ORG> \
        --dest-token <DEST_TOKEN> \
        [--api-url <SOURCE_API_URL>] \
        [--dest-api-url <DEST_API_URL>] \
        [--filter-repo <REPO>] \
        [--concurrency <N>] \
        [--include-archived] \
        [--dry-run]
"""

import argparse
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_request(method, url, token, body=None):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    resp = requests.request(method, url, headers=headers, json=body)
    try:
        data = resp.json() if resp.content else {}
    except ValueError:
        data = {}
    return resp.status_code, data


def gh_paginate(url, token):
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        status, data = gh_request("GET", f"{url}{sep}per_page=100&page={page}", token)
        if status in (403, 404):
            return results
        if status != 200:
            msg = data.get("message", "") if isinstance(data, dict) else ""
            print(f"  Warning: GET {url} -> HTTP {status}: {msg}", file=sys.stderr)
            return results
        if not isinstance(data, list) or not data:
            return results
        results.extend(data)
        if len(data) < 100:
            return results
        page += 1


def get_all_repos(org, token, api_url, include_archived=False):
    repos = gh_paginate(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_repo_autolinks(org, repo, token, api_url):
    """Return list of autolink dicts for a repo."""
    links = gh_paginate(f"{api_url}/repos/{org}/{repo}/autolinks", token)
    return [
        {
            "key_prefix": link.get("key_prefix", ""),
            "url_template": link.get("url_template", ""),
            "is_alphanumeric": link.get("is_alphanumeric", True),
        }
        for link in links
    ]


def get_existing_autolink_prefixes(org, repo, token, api_url):
    links = gh_paginate(f"{api_url}/repos/{org}/{repo}/autolinks", token)
    return {link.get("key_prefix", "") for link in links}


def create_repo_autolink(org, repo, token, api_url, autolink):
    """Create an autolink reference on the destination repo. Returns (ok, msg)."""
    body = {
        "key_prefix": autolink["key_prefix"],
        "url_template": autolink["url_template"],
        "is_alphanumeric": autolink["is_alphanumeric"],
    }
    status, data = gh_request("POST", f"{api_url}/repos/{org}/{repo}/autolinks", token, body)
    ok = status == 201
    msg = data.get("message", "") if isinstance(data, dict) else ""
    return ok, msg


# ─────────────────────────────────────────────
# Migration
# ─────────────────────────────────────────────

def migrate_repo_autolinks(
    source_org, dest_org, repo, source_token, dest_token,
    source_api_url="https://api.github.com", dest_api_url="https://api.github.com",
    dry_run=False,
):
    """
    Copy all autolink references for a single repo from source to dest.
    Returns list of (key_prefix, ok, msg).
    """
    links = get_repo_autolinks(source_org, repo, source_token, source_api_url)

    existing_prefixes = set()
    if not dry_run and links:
        existing_prefixes = get_existing_autolink_prefixes(dest_org, repo, dest_token, dest_api_url)

    results = []
    for link in links:
        if link["key_prefix"] in existing_prefixes:
            results.append((link["key_prefix"], True, "skipped: already exists in destination"))
            continue
        if dry_run:
            results.append((link["key_prefix"], True, "dry-run: would create"))
            continue
        ok, msg = create_repo_autolink(dest_org, repo, dest_token, dest_api_url, link)
        results.append((link["key_prefix"], ok, msg or ("created" if ok else "failed")))
    return results


def migrate_all(args):
    """
    Migrate repo-level autolink references for every repo in the source org
    (or a single repo if args.filter_repo is set).
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    source_api_url = args.api_url.rstrip("/")
    dest_api_url = args.dest_api_url.rstrip("/")

    if args.filter_repo:
        repos = [args.filter_repo]
    else:
        repos = get_all_repos(args.source_org, args.source_token, source_api_url, args.include_archived)

    print(f"Migrating repo-level autolink references for {len(repos)} repo(s): "
          f"{args.source_org} -> {args.dest_org}")

    success, failed, skipped = [], [], []

    def _process(repo):
        link_results = migrate_repo_autolinks(
            args.source_org, args.dest_org, repo,
            args.source_token, args.dest_token,
            source_api_url, dest_api_url, args.dry_run,
        )
        if not link_results:
            return repo, "skipped", []
        return repo, "done", link_results

    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {executor.submit(_process, repo): repo for repo in repos}
        for future in as_completed(futures):
            repo, status, link_results = future.result()
            if status == "skipped":
                skipped.append(repo)
                print(f"  [skip] {repo}: no autolink references")
                continue
            for prefix, ok, msg in link_results:
                label = f"{repo}:{prefix}"
                if ok and msg.startswith("skipped"):
                    skipped.append((label, msg))
                    print(f"  [skip] {label}: {msg}")
                elif ok:
                    success.append((label, msg))
                    print(f"  [ok]   {label}: {msg}")
                else:
                    failed.append((label, msg))
                    print(f"  [FAIL] {label}: {msg}")

    return {"success": success, "failed": failed, "skipped": skipped}


def build_parser():
    parser = argparse.ArgumentParser(description="Migrate repo-level autolink references between GitHub orgs")
    parser.add_argument("--source-org", required=True)
    parser.add_argument("--source-token", required=True)
    parser.add_argument("--dest-org", required=True)
    parser.add_argument("--dest-token", required=True)
    parser.add_argument("--api-url", default="https://api.github.com")
    parser.add_argument("--dest-api-url", default="https://api.github.com")
    parser.add_argument("--filter-repo", default=None)
    parser.add_argument("--concurrency", type=int, default=10)
    parser.add_argument("--include-archived", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    migrate_all(args)


if __name__ == "__main__":
    main()
