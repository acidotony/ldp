#!/usr/bin/env python3
"""
List all repositories in a GitHub organization that have autolink references
configured (e.g. JIRA-123 -> https://jira.example.com/browse/JIRA-123).

Usage:
    python list-repos-with-autolinks.py --org <ORG> --token <TOKEN> \
        [--api-url <URL>] [--output <FILE>] [--include-archived]
"""

import argparse
import csv
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import urllib.request
import urllib.error


def github_get(url, token, api_url):
    """Paginate through a GitHub API endpoint and return all results."""
    results = []
    page = 1
    while True:
        paginated = f"{url}{'&' if '?' in url else '?'}per_page=100&page={page}"
        req = urllib.request.Request(
            paginated,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            if e.code not in (403, 404):
                print(f"  HTTP {e.code} for {paginated}: {body}", file=sys.stderr)
            return results
        except urllib.error.URLError as e:
            print(f"  Request error for {paginated}: {e}", file=sys.stderr)
            return results

        if isinstance(data, list):
            if not data:
                break
            results.extend(data)
            if len(data) < 100:
                break
        else:
            break

        page += 1

    return results


def get_all_repos(org, token, api_url, include_archived=False):
    """Return list of repo names in the org."""
    repos = github_get(f"{api_url}/orgs/{org}/repos?type=all", token, api_url)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_repo_autolinks(org, repo, token, api_url):
    """Return (repo_name, autolink_count, autolinks list of dicts)."""
    links = github_get(f"{api_url}/repos/{org}/{repo}/autolinks", token, api_url)
    rows = []
    for link in links:
        rows.append({
            "id": link.get("id"),
            "key_prefix": link.get("key_prefix", ""),
            "url_template": link.get("url_template", ""),
            "is_alphanumeric": link.get("is_alphanumeric", True),
        })
    return repo, len(rows), rows


def main():
    parser = argparse.ArgumentParser(description="List repos with autolink references")
    parser.add_argument("--org", required=True, help="GitHub organization name")
    parser.add_argument("--token", required=True, help="GitHub PAT")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="GitHub API base URL (default: https://api.github.com)")
    parser.add_argument("--output", default="repos_with_autolinks.csv",
                        help="Output CSV file (default: repos_with_autolinks.csv)")
    parser.add_argument("--concurrency", type=int, default=10,
                        help="Parallel requests (default: 10)")
    parser.add_argument("--include-archived", action="store_true",
                        help="Include archived repositories")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")

    print(f"Fetching repos for org: {args.org}")
    repos = get_all_repos(args.org, args.token, api_url, args.include_archived)
    print(f"Found {len(repos)} repos. Checking for autolink references...")

    results = []
    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {
            executor.submit(get_repo_autolinks, args.org, repo, args.token, api_url): repo
            for repo in repos
        }
        done = 0
        for future in as_completed(futures):
            done += 1
            repo_name, count, rows = future.result()
            if count > 0:
                prefixes = ",".join(r["key_prefix"] for r in rows)
                results.append((repo_name, count, prefixes))
                print(f"  [{done}/{len(repos)}] {repo_name}: {count} autolink(s)")
            else:
                print(f"  [{done}/{len(repos)}] {repo_name}: no autolinks", end="\r")

    print(f"\n\nRepositories with autolinks: {len(results)} / {len(repos)}")

    results.sort(key=lambda x: x[0])

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["repository", "autolink_count", "key_prefixes"])
        for repo, count, prefixes in results:
            writer.writerow([repo, count, prefixes])

    print(f"Results saved to: {args.output}")

    print(f"\n{'Repository':<50} {'Links':>5}  Key prefixes")
    print("-" * 80)
    for repo, count, prefixes in results:
        print(f"{repo:<50} {count:>5}  {prefixes}")


if __name__ == "__main__":
    main()
