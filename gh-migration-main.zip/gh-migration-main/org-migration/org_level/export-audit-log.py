#!/usr/bin/env python3
"""
Exports an organization's audit log history to a local JSON file before the
source org is decommissioned.

IMPORTANT — this is an EXPORT tool, not a migration tool: GitHub's audit log
is generated organically as actions happen; there is no REST or GraphQL
endpoint to write historical audit log entries into another org's log. A
destination org's audit log will naturally start recording from the point
migrated activity happens there. This script exists only to preserve a
point-in-time archive of the source org's history (e.g. for compliance
retention) since GET /orgs/{org}/audit-log only returns a rolling window
(historically ~180 days, less on some plans) by default.

Requires: GitHub Enterprise Cloud (the audit-log endpoint doesn't exist on
github.com Free/Pro/Team orgs) and a token with read:audit_log scope
(classic PAT) or "Administration" org permission (read, fine-grained).

Usage:
    python export-audit-log.py --org <ORG> --token <TOKEN> \
        [--api-url <URL>] [--output <FILE>] [--include git|web|all] \
        [--phrase <SEARCH_PHRASE>]
"""

import argparse
import json
import sys

import urllib.request
import urllib.error


def github_get_page(url, token):
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:
            link_header = resp.headers.get("Link", "")
            data = json.loads(resp.read().decode())
            return data, link_header
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        if e.code == 404:
            print("  ERROR: audit-log endpoint not found - this feature requires GitHub Enterprise Cloud.", file=sys.stderr)
        else:
            print(f"  HTTP {e.code}: {body}", file=sys.stderr)
        return None, None
    except urllib.error.URLError as e:
        print(f"  Request error: {e}", file=sys.stderr)
        return None, None


def _next_link(link_header):
    if not link_header:
        return None
    for part in link_header.split(","):
        segments = part.split(";")
        if len(segments) < 2:
            continue
        url_part = segments[0].strip().strip("<>")
        rel_part = segments[1].strip()
        if rel_part == 'rel="next"':
            return url_part
    return None


def export_org_audit_log(org, token, api_url, include="all", phrase=None):
    """
    Paginate through GET /orgs/{org}/audit-log and return the full list of
    events available within GitHub's retention window.
    """
    params = [f"include={include}", "per_page=100"]
    if phrase:
        from urllib.parse import quote
        params.append(f"phrase={quote(phrase)}")
    url = f"{api_url}/orgs/{org}/audit-log?{'&'.join(params)}"

    events = []
    while url:
        data, link_header = github_get_page(url, token)
        if data is None:
            break
        if not data:
            break
        events.extend(data)
        url = _next_link(link_header)

    return events


def main():
    parser = argparse.ArgumentParser(description="Export org audit log history to a local file (GitHub Enterprise Cloud only)")
    parser.add_argument("--org", required=True)
    parser.add_argument("--token", required=True, help="Needs read:audit_log scope")
    parser.add_argument("--api-url", default="https://api.github.com")
    parser.add_argument("--output", default="audit_log_export.json")
    parser.add_argument("--include", choices=["web", "git", "all"], default="all")
    parser.add_argument("--phrase", default=None, help="Audit log search phrase, e.g. 'created:>2024-01-01'")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")

    print(f"Exporting audit log for org: {args.org}")
    events = export_org_audit_log(args.org, args.token, api_url, args.include, args.phrase)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(events, f, indent=2)

    print(f"Exported {len(events)} audit log event(s) to: {args.output}")
    print("\nNOTE: this is a point-in-time export for archival/compliance purposes only.")
    print("      There is no API to write these events into the destination org's audit")
    print("      log - GitHub generates audit log entries organically as actions occur.")
    print("      Also note: GET /orgs/{org}/audit-log only returns a rolling retention")
    print("      window by default; use --phrase with a 'created:' qualifier for older events.")


if __name__ == "__main__":
    main()
