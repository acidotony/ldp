"""
org_level — Organization-level settings migration/audit utilities.

Of the four organization-level items tracked in tasks.md:
  - GitHub App installations: audit-only (list_org_level_settings). No API
    to install an app; requires manual consent-flow installation.
  - IP allow list entries: ACTUALLY migratable via GraphQL (no REST support
    exists, but createIpAllowListEntry/updateIpAllowListEnabledSetting
    mutations do) — see migrate_ip_allowlist(). Requires GitHub Enterprise
    Cloud on both orgs.
  - Audit log history: read-only export only (export_audit_log_history) —
    GitHub generates audit log entries organically; there is no endpoint to
    write historical entries into another org's log.
  - OAuth App access restrictions: genuinely has NO API (REST or GraphQL).
    The only way to automate this is browser automation against GitHub's
    web UI (Settings > Third-party access), which is not implemented here
    due to GitHub Terms of Service and session-security concerns. See
    tasks.md for details on this limitation.

Exposed functions:
    list_org_level_settings(api_url, org, token) -> dict
        {app_installations: list[dict]}
    migrate_ip_allowlist(source_api_url, source_org, source_token,
                          dest_api_url, dest_org, dest_token, dry_run=False) -> dict
    export_audit_log_history(api_url, org, token, include="all", phrase=None) -> list[dict]
"""

import importlib.util
import pathlib

_HERE = pathlib.Path(__file__).parent


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, _HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def list_org_level_settings(api_url, org, token):
    """
    Audit org-level settings requiring manual migration.
    Returns dict: {app_installations: list[dict]}
    """
    mod = _load("list-org-level-settings.py")
    installations = mod.get_org_app_installations(org, token, api_url)

    app_installations = [
        {
            "app_slug": inst.get("app_slug", ""),
            "app_id": inst.get("app_id", ""),
            "repository_selection": inst.get("repository_selection", ""),
            "permissions": inst.get("permissions", {}),
            "suspended": bool(inst.get("suspended_at")),
        }
        for inst in installations
    ]

    return {"app_installations": app_installations}


def migrate_ip_allowlist(source_api_url, source_org, source_token,
                          dest_api_url, dest_org, dest_token, dry_run=False):
    """
    Migrate IP allow list entries (and the two enabled-settings toggles)
    from source org to dest org via GraphQL. Requires GitHub Enterprise
    Cloud on both orgs. Returns {"success": [...], "failed": [(name, err)]}
    """
    mod = _load("migrate-ip-allowlist.py")
    return mod.migrate_ip_allowlist(
        source_org, source_token, source_api_url,
        dest_org, dest_token, dest_api_url, dry_run=dry_run,
    )


def export_audit_log_history(api_url, org, token, include="all", phrase=None):
    """
    Read-only export of an org's audit log history (point-in-time archive
    only — cannot be written into another org's log, see module docstring).
    Returns list of event dicts.
    """
    mod = _load("export-audit-log.py")
    return mod.export_org_audit_log(org, token, api_url, include=include, phrase=phrase)

