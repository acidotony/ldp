#!/usr/bin/env python3
"""
Audit organization-level settings that cannot be auto-migrated by this toolkit
and require manual review/action on the destination org:

  - GitHub Apps installed at the org level (no repo-selection) — GitHub's API
    has no endpoint to "install" an app; installation requires the org owner
    to click through the app's OAuth-style consent flow on GitHub.com.
  - OAuth App access restrictions — managed only via the org's
    Settings > Third-party access page (GitHub Enterprise Cloud); no public
    REST endpoint exists to read/write this setting.
  - IP allow list entries — managed via GraphQL (ipAllowListEntries) on
    GitHub Enterprise Cloud orgs; not present in the standard REST API.
  - Audit log history — available via GET /orgs/{org}/audit-log on GitHub
    Enterprise Cloud only, and only retains a rolling window; history is not
    "migratable" in the sense of writing it to a new org.

This script only reports on the one item that has a real read API (GitHub
App installations). The rest are documented here as manual follow-up items.

Usage:
    python list-org-level-settings.py --org <ORG> --token <TOKEN> \
        [--api-url <URL>] [--output <FILE>]
"""

import argparse
import csv
import json
import sys

import urllib.request
import urllib.error


def github_get(url, token, api_url):
    """GET a single GitHub API resource. Returns parsed JSON dict, or None on 403/404."""
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        if e.code not in (403, 404):
            body = e.read().decode()
            print(f"  HTTP {e.code} for {url}: {body}", file=sys.stderr)
        return None
    except urllib.error.URLError as e:
        print(f"  Request error for {url}: {e}", file=sys.stderr)
        return None


def get_org_app_installations(org, token, api_url):
    """Return list of GitHub App installations at the org level."""
    installations = []
    page = 1
    while True:
        data = github_get(
            f"{api_url}/orgs/{org}/installations?per_page=100&page={page}",
            token, api_url,
        )
        if not data:
            break
        page_installations = data.get("installations", [])
        installations.extend(page_installations)
        if len(page_installations) < 100:
            break
        page += 1
    return installations


def main():
    parser = argparse.ArgumentParser(description="Audit org-level settings requiring manual migration")
    parser.add_argument("--org", required=True, help="GitHub organization name")
    parser.add_argument("--token", required=True, help="GitHub PAT (needs admin:org / admin:read scope)")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="GitHub API base URL (default: https://api.github.com)")
    parser.add_argument("--output", default="org_level_settings.csv",
                        help="Output CSV file (default: org_level_settings.csv)")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")

    print(f"Auditing org-level settings for: {args.org}")
    print("=" * 60)

    # ── GitHub App installations ───────────────────────────────────────────
    print("\n[1/1] GitHub App installations on the org...")
    installations = get_org_app_installations(args.org, token=args.token, api_url=api_url)
    print(f"      Found {len(installations)} app installation(s)")

    rows = []
    for inst in installations:
        rows.append({
            "app_slug": inst.get("app_slug", ""),
            "app_id": inst.get("app_id", ""),
            "repository_selection": inst.get("repository_selection", ""),
            "permissions": ",".join(f"{k}:{v}" for k, v in inst.get("permissions", {}).items()),
            "suspended": bool(inst.get("suspended_at")),
        })

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["app_slug", "app_id", "repository_selection", "permissions", "suspended"])
        for r in rows:
            writer.writerow([r["app_slug"], r["app_id"], r["repository_selection"], r["permissions"], r["suspended"]])

    print(f"      Results saved to: {args.output}")

    if rows:
        print(f"\n{'App':<30} {'ID':>8}  {'Selection':<10} Permissions")
        print("-" * 90)
        for r in rows:
            print(f"{r['app_slug']:<30} {r['app_id']:>8}  {r['repository_selection']:<10} {r['permissions']}")

    # ── Manual-only items ───────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("MANUAL FOLLOW-UP REQUIRED (no REST API support to auto-migrate):")
    print("=" * 60)
    print("  - OAuth App access restrictions:")
    print("      Recreate manually under Settings > Third-party access on the destination org.")
    print("  - IP allow list entries:")
    print("      Only available via GraphQL (ipAllowListEntries) on GitHub Enterprise Cloud;")
    print("      recreate manually under Settings > Authentication security on the destination org.")
    print("  - Audit log history:")
    print("      Not portable between orgs; export via GET /orgs/{org}/audit-log (Enterprise Cloud)")
    print("      or the UI's 'Export' button if long-term retention/compliance records are needed")
    print("      before the source org is decommissioned.")
    print("  - GitHub App installations listed above:")
    print("      Must be re-installed on the destination org via each app's install/consent page")
    print("      (no REST API to install an app for a user); this list documents which apps and")
    print("      what permissions/repo-selection to reproduce.")


if __name__ == "__main__":
    main()
