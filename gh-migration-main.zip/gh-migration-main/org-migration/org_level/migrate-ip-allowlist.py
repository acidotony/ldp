#!/usr/bin/env python3
"""
Migrates IP allow list entries between GitHub organizations using the
GraphQL API (this setting has NO REST endpoint — it is only exposed via
GraphQL: Organization.ipAllowListEntries / createIpAllowListEntry mutation).

Requires GitHub Enterprise Cloud on both source and destination org (IP
allow lists are an Enterprise Cloud feature). If the destination org is not
Enterprise Cloud, entry creation will fail with a GraphQL error, which is
reported per-entry rather than raised.

Also copies the two related organization-wide toggles when present:
    - ipAllowListEnabledSetting (ENABLED / DISABLED)
    - ipAllowListForInstalledGitHubAppsEnabledSetting (ENABLED / DISABLED)

Usage:
    python migrate-ip-allowlist.py \
        --source-org <SOURCE_ORG> --source-token <SOURCE_TOKEN> \
        --dest-org <DEST_ORG> --dest-token <DEST_TOKEN> \
        [--source-api-url <URL>] [--dest-api-url <URL>] [--dry-run]
"""

import argparse
import json
import sys

import urllib.request
import urllib.error


def graphql_query(api_url, token, query, variables=None):
    graphql_url = "https://api.github.com/graphql" if api_url.rstrip("/") == "https://api.github.com" \
        else (api_url.rsplit("/v3", 1)[0] + "/graphql" if api_url.endswith("/v3") else f"{api_url}/graphql")

    body = json.dumps({"query": query, "variables": variables or {}}).encode()
    req = urllib.request.Request(
        graphql_url, data=body, method="POST",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/vnd.github+json",
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        print(f"  GraphQL HTTP {e.code}: {e.read().decode()}", file=sys.stderr)
        return None
    except urllib.error.URLError as e:
        print(f"  GraphQL request error: {e}", file=sys.stderr)
        return None

    if result.get("errors"):
        print(f"  GraphQL errors: {result['errors']}", file=sys.stderr)
        return {"__errors__": result["errors"]}
    return result.get("data")


ORG_IP_ALLOWLIST_QUERY = """
query($org: String!, $after: String) {
  organization(login: $org) {
    id
    ipAllowListEnabledSetting
    ipAllowListForInstalledGitHubAppsEnabledSetting
    ipAllowListEntries(first: 100, after: $after) {
      pageInfo { hasNextPage endCursor }
      nodes { id name allowListValue isActive }
    }
  }
}
"""

CREATE_ENTRY_MUTATION = """
mutation($ownerId: ID!, $name: String, $allowListValue: String!, $isActive: Boolean!) {
  createIpAllowListEntry(input: {
    ownerId: $ownerId, name: $name, allowListValue: $allowListValue, isActive: $isActive
  }) {
    ipAllowListEntry { id name allowListValue }
  }
}
"""

UPDATE_ENABLED_SETTING_MUTATION = """
mutation($ownerId: ID!, $setting: IpAllowListEnabledSettingValue!) {
  updateIpAllowListEnabledSetting(input: {ownerId: $ownerId, settingValue: $setting}) {
    organization { id }
  }
}
"""

UPDATE_APPS_ENABLED_SETTING_MUTATION = """
mutation($ownerId: ID!, $setting: IpAllowListForInstalledGitHubAppsEnabledSettingValue!) {
  updateIpAllowListForInstalledGitHubAppsEnabledSetting(input: {ownerId: $ownerId, settingValue: $setting}) {
    organization { id }
  }
}
"""


def get_org_ip_allowlist(org, token, api_url):
    """Return dict: {org_id, enabled_setting, apps_enabled_setting, entries: [...]}"""
    entries = []
    after = None
    org_id = None
    enabled_setting = None
    apps_enabled_setting = None
    while True:
        data = graphql_query(api_url, token, ORG_IP_ALLOWLIST_QUERY, {"org": org, "after": after})
        if not data or not data.get("organization"):
            break
        node = data["organization"]
        org_id = node["id"]
        enabled_setting = node.get("ipAllowListEnabledSetting")
        apps_enabled_setting = node.get("ipAllowListForInstalledGitHubAppsEnabledSetting")
        conn = node["ipAllowListEntries"]
        entries.extend(conn["nodes"])
        if not conn["pageInfo"]["hasNextPage"]:
            break
        after = conn["pageInfo"]["endCursor"]
    return {
        "org_id": org_id,
        "enabled_setting": enabled_setting,
        "apps_enabled_setting": apps_enabled_setting,
        "entries": entries,
    }


def migrate_ip_allowlist(source_org, source_token, source_api_url,
                          dest_org, dest_token, dest_api_url, dry_run=False):
    """
    Copy IP allow list entries + the two enabled-settings toggles from
    source_org to dest_org via GraphQL.
    Returns {"success": [...], "failed": [(entry_name, err)]}
    """
    results = {"success": [], "failed": []}

    source_state = get_org_ip_allowlist(source_org, source_token, source_api_url)
    if not source_state["org_id"]:
        results["failed"].append((source_org, "could not read source org IP allow list (not Enterprise Cloud, or insufficient scope)"))
        return results

    dest_state = get_org_ip_allowlist(dest_org, dest_token, dest_api_url)
    if not dest_state["org_id"]:
        results["failed"].append((dest_org, "could not resolve destination org id via GraphQL (not Enterprise Cloud, or insufficient scope)"))
        return results
    dest_owner_id = dest_state["org_id"]

    print(f"  Source has {len(source_state['entries'])} IP allow list entrie(s)")

    for entry in source_state["entries"]:
        name = entry.get("name") or entry["allowListValue"]
        if dry_run:
            results["success"].append(name)
            print(f"    [DRY RUN] Would create entry: {name} ({entry['allowListValue']})")
            continue

        created = graphql_query(dest_api_url, dest_token, CREATE_ENTRY_MUTATION, {
            "ownerId": dest_owner_id,
            "name": entry.get("name"),
            "allowListValue": entry["allowListValue"],
            "isActive": entry.get("isActive", True),
        })
        if created and created.get("createIpAllowListEntry"):
            print(f"    [OK]   {name} ({entry['allowListValue']})")
            results["success"].append(name)
        else:
            err = created.get("__errors__") if created else "unknown error"
            print(f"    [FAIL] {name}: {err}")
            results["failed"].append((name, str(err)))

    # Copy the two org-wide enabled-settings toggles (best-effort, non-fatal)
    if not dry_run:
        if source_state["enabled_setting"]:
            graphql_query(dest_api_url, dest_token, UPDATE_ENABLED_SETTING_MUTATION, {
                "ownerId": dest_owner_id, "setting": source_state["enabled_setting"],
            })
        if source_state["apps_enabled_setting"]:
            graphql_query(dest_api_url, dest_token, UPDATE_APPS_ENABLED_SETTING_MUTATION, {
                "ownerId": dest_owner_id, "setting": source_state["apps_enabled_setting"],
            })

    return results


def main():
    parser = argparse.ArgumentParser(description="Migrate IP allow list entries between orgs via GraphQL")
    parser.add_argument("--source-org", required=True)
    parser.add_argument("--source-token", required=True, help="Needs admin:org scope")
    parser.add_argument("--source-api-url", default="https://api.github.com")
    parser.add_argument("--dest-org", required=True)
    parser.add_argument("--dest-token", required=True, help="Needs admin:org scope")
    parser.add_argument("--dest-api-url", default="https://api.github.com")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    results = migrate_ip_allowlist(
        args.source_org, args.source_token, args.source_api_url.rstrip("/"),
        args.dest_org, args.dest_token, args.dest_api_url.rstrip("/"),
        dry_run=args.dry_run,
    )

    print("\n" + "=" * 60)
    print(f"IP ALLOW LIST SUMMARY  OK: {len(results['success'])}  Failed: {len(results['failed'])}")
    if results["failed"]:
        print("\nFailed:")
        for name, msg in results["failed"]:
            print(f"  [FAIL] {name}: {msg}")
    print("=" * 60)


if __name__ == "__main__":
    main()
