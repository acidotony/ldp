#!/usr/bin/env python3
"""
Migrates repo-level deploy keys from a source org to a destination org.

IMPORTANT — deploy keys cannot be copied:
    GitHub's API never returns a deploy key's private half (write-only,
    public-key-only), so an existing deploy key CANNOT be duplicated as-is.
    This script instead REGENERATES each deploy key:

      1. Reads deploy key metadata from the source repo (title, read_only).
      2. Generates a brand-new ed25519 keypair locally for each one.
      3. Adds the new PUBLIC key to the destination repo with the same
         title and read_only flag.
      4. The new PRIVATE key is either:
           - stored in CyberArk (if --cyberark-* args are supplied), using
             the naming convention GH-{DEST_ORG}-{REPO}-DEPLOYKEY-{TITLE}, or
           - written to local files under --output-dir (default:
             ./deploy_keys_output/{repo}/{title}.pem) — NOT committed to git,
             must be distributed to whatever system consumed the old key.

    Whichever system used the old private key (CI server, external service,
    etc.) MUST be reconfigured with the new private key — that hand-off is
    manual and outside the scope of the GitHub API.

Requirements:
    pip install requests cryptography

Usage:
    python migrate-deploy-keys.py \
        --source-org <SOURCE_ORG> \
        --source-token <SOURCE_TOKEN> \
        --dest-org <DEST_ORG> \
        --dest-token <DEST_TOKEN> \
        [--api-url <SOURCE_API_URL>] \
        [--dest-api-url <DEST_API_URL>] \
        [--filter-repo <REPO>] \
        [--output-dir <DIR>] \
        [--cyberark-url <URL> --cyberark-username <USER> --cyberark-password <PASS> --cyberark-safe <SAFE>] \
        [--include-archived] \
        [--dry-run]
"""

import argparse
import pathlib
import sys

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests cryptography", file=sys.stderr)
    sys.exit(1)

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
except ImportError:
    print("ERROR: 'cryptography' is required. Run: pip install requests cryptography", file=sys.stderr)
    sys.exit(1)


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_request(method, url, token, body=None):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    resp = requests.request(method, url, headers=headers, json=body)
    try:
        data = resp.json() if resp.content else {}
    except ValueError:
        data = {}
    return resp.status_code, data


def gh_paginate(url, token):
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        status, data = gh_request("GET", f"{url}{sep}per_page=100&page={page}", token)
        if status in (403, 404):
            return results
        if status != 200:
            msg = data.get("message", "") if isinstance(data, dict) else ""
            print(f"  Warning: GET {url} -> HTTP {status}: {msg}", file=sys.stderr)
            return results
        if not isinstance(data, list) or not data:
            return results
        results.extend(data)
        if len(data) < 100:
            return results
        page += 1


def get_all_repos(org, token, api_url, include_archived=False):
    repos = gh_paginate(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_repo_deploy_keys(org, repo, token, api_url):
    """Return list of deploy key metadata dicts for a repo."""
    keys = gh_paginate(f"{api_url}/repos/{org}/{repo}/keys", token)
    return [
        {
            "id": k.get("id"),
            "title": k.get("title", ""),
            "read_only": k.get("read_only", True),
        }
        for k in keys
    ]


def get_existing_deploy_key_titles(org, repo, token, api_url):
    keys = gh_paginate(f"{api_url}/repos/{org}/{repo}/keys", token)
    return {k.get("title", "") for k in keys}


def create_deploy_key(org, repo, token, api_url, title, public_key, read_only=True):
    """Add a public key as a deploy key on the destination repo. Returns (ok, msg)."""
    body = {"title": title, "key": public_key, "read_only": read_only}
    status, data = gh_request("POST", f"{api_url}/repos/{org}/{repo}/keys", token, body)
    ok = status == 201
    msg = data.get("message", "") if isinstance(data, dict) else ""
    return ok, msg


def generate_ed25519_keypair():
    """Generate a new ed25519 keypair. Returns (private_pem_str, public_openssh_str)."""
    private_key = Ed25519PrivateKey.generate()
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.OpenSSH,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    public_openssh = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    ).decode("utf-8")
    return private_pem, public_openssh


# ─────────────────────────────────────────────
# CyberArk helpers (optional private-key storage)
# ─────────────────────────────────────────────

def cyberark_logon(base_url, username, password):
    resp = requests.post(
        f"{base_url}/PasswordVault/API/auth/CyberArk/Logon",
        json={"username": username, "password": password},
        verify=True,
    )
    resp.raise_for_status()
    return resp.json().strip('"')


def cyberark_logoff(base_url, token):
    try:
        requests.post(f"{base_url}/PasswordVault/API/Auth/Logoff", headers={"Authorization": token})
    except Exception:
        pass


def cyberark_store_private_key(base_url, token, safe, account_name, private_key_pem):
    """Create (or note conflict with) a CyberArk account holding a deploy key private key."""
    payload = {
        "safeName": safe,
        "name": account_name,
        "address": "github.com",
        "userName": account_name,
        "secret": private_key_pem,
        "secretType": "password",
        "platformId": "WinServerLocal",
        "platformAccountProperties": {},
    }
    resp = requests.post(
        f"{base_url}/PasswordVault/API/Accounts",
        headers={"Authorization": token},
        json=payload,
        verify=True,
    )
    ok = resp.status_code == 201
    msg = "" if ok else f"HTTP {resp.status_code}: {resp.text[:200]}"
    return ok, msg


# ─────────────────────────────────────────────
# Migration
# ─────────────────────────────────────────────

def _safe_filename(title, key_id):
    name = title.strip() or f"key-{key_id}"
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in name)


def migrate_repo_deploy_keys(
    source_org, dest_org, repo, source_token, dest_token,
    source_api_url="https://api.github.com", dest_api_url="https://api.github.com",
    output_dir=None, cyberark=None, dry_run=False,
):
    """
    Regenerate all deploy keys for a single repo from source to dest.
    Returns list of (title, ok, msg).
    """
    keys = get_repo_deploy_keys(source_org, repo, source_token, source_api_url)

    existing_titles = set()
    if not dry_run and keys:
        existing_titles = get_existing_deploy_key_titles(dest_org, repo, dest_token, dest_api_url)

    results = []
    ca_token = None
    if cyberark and not dry_run:
        try:
            ca_token = cyberark_logon(cyberark["url"], cyberark["username"], cyberark["password"])
        except Exception as e:
            print(f"  Warning: CyberArk logon failed ({e}); private keys will be written to output-dir instead",
                  file=sys.stderr)
            ca_token = None

    try:
        for key in keys:
            title = key["title"] or f"key-{key['id']}"
            if title in existing_titles:
                results.append((title, True, "skipped: already exists in destination"))
                continue
            if dry_run:
                results.append((title, True, "dry-run: would generate new keypair and add to destination"))
                continue

            private_pem, public_openssh = generate_ed25519_keypair()
            ok, msg = create_deploy_key(
                dest_org, repo, dest_token, dest_api_url, title, public_openssh, key["read_only"]
            )
            if not ok:
                results.append((title, False, msg or "failed to add deploy key"))
                continue

            stored_note = "private key NOT stored - lost"
            if ca_token:
                account_name = f"GH-{dest_org}-{repo}-DEPLOYKEY-{_safe_filename(title, key['id'])}"
                stored, store_msg = cyberark_store_private_key(
                    cyberark["url"], ca_token, cyberark["safe"], account_name, private_pem
                )
                stored_note = f"private key stored in CyberArk ({account_name})" if stored else \
                    f"private key NOT stored in CyberArk ({store_msg}) - falling back to output-dir"
                if not stored:
                    ca_token = None  # stop retrying cyberark for remaining keys this run

            if not ca_token:
                out_dir = pathlib.Path(output_dir or "deploy_keys_output") / dest_org / repo
                out_dir.mkdir(parents=True, exist_ok=True)
                key_path = out_dir / f"{_safe_filename(title, key['id'])}.pem"
                key_path.write_text(private_pem, encoding="utf-8")
                try:
                    key_path.chmod(0o600)
                except OSError:
                    pass
                stored_note = f"private key written to {key_path}"

            results.append((title, True, f"added (read_only={key['read_only']}); {stored_note}"))
    finally:
        if ca_token:
            cyberark_logoff(cyberark["url"], ca_token)

    return results


def migrate_all(args):
    """
    Migrate repo-level deploy keys for every repo in the source org (or a
    single repo if args.filter_repo is set).
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    source_api_url = args.api_url.rstrip("/")
    dest_api_url = args.dest_api_url.rstrip("/")

    cyberark = None
    if getattr(args, "cyberark_url", None) and getattr(args, "cyberark_username", None) \
            and getattr(args, "cyberark_password", None) and getattr(args, "cyberark_safe", None):
        cyberark = {
            "url": args.cyberark_url,
            "username": args.cyberark_username,
            "password": args.cyberark_password,
            "safe": args.cyberark_safe,
        }

    if args.filter_repo:
        repos = [args.filter_repo]
    else:
        repos = get_all_repos(args.source_org, args.source_token, source_api_url, args.include_archived)

    print(f"Migrating deploy keys for {len(repos)} repo(s): {args.source_org} -> {args.dest_org}")
    if not cyberark:
        print(f"  No CyberArk config supplied - private keys will be written under "
              f"'{args.output_dir or 'deploy_keys_output'}/'")

    success, failed, skipped = [], [], []

    for repo in repos:
        key_results = migrate_repo_deploy_keys(
            args.source_org, args.dest_org, repo,
            args.source_token, args.dest_token,
            source_api_url, dest_api_url,
            output_dir=args.output_dir, cyberark=cyberark, dry_run=args.dry_run,
        )
        for title, ok, msg in key_results:
            label = f"{repo} [{title}]"
            if ok and msg.startswith("skipped"):
                skipped.append((label, msg))
                print(f"  {label}: {msg}")
            elif ok:
                success.append((label, msg))
                print(f"  {label}: {msg}")
            else:
                failed.append((label, msg))
                print(f"  {label}: FAILED - {msg}", file=sys.stderr)

    return {"success": success, "failed": failed, "skipped": skipped}


def build_parser():
    parser = argparse.ArgumentParser(description="Migrate (regenerate) repo deploy keys from source org to destination org")
    parser.add_argument("--source-org", required=True)
    parser.add_argument("--source-token", required=True)
    parser.add_argument("--dest-org", required=True)
    parser.add_argument("--dest-token", required=True)
    parser.add_argument("--api-url", default="https://api.github.com", help="Source API URL")
    parser.add_argument("--dest-api-url", default="https://api.github.com", help="Destination API URL")
    parser.add_argument("--filter-repo", default=None)
    parser.add_argument("--output-dir", default=None,
                        help="Directory to write generated private keys (default: ./deploy_keys_output)")
    parser.add_argument("--cyberark-url", default=None)
    parser.add_argument("--cyberark-username", default=None)
    parser.add_argument("--cyberark-password", default=None)
    parser.add_argument("--cyberark-safe", default=None)
    parser.add_argument("--include-archived", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    migrate_all(args)


if __name__ == "__main__":
    main()
