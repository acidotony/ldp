#!/usr/bin/env python3
"""
List all repositories in a GitHub organization that have repo-level deploy
keys configured.

Deploy key private keys are never returned by the GitHub API (write-only),
so only the public, non-sensitive metadata is reported: id, title,
read_only flag, and key fingerprint prefix.

Usage:
    python list-repos-with-deploy-keys.py --org <ORG> --token <TOKEN> \
        [--api-url <URL>] [--output <FILE>] [--include-archived]
"""

import argparse
import csv
import json
import sys

import urllib.request
import urllib.error


def github_get(url, token, api_url):
    """Paginate through a GitHub API endpoint and return all results."""
    results = []
    page = 1
    while True:
        paginated = f"{url}{'&' if '?' in url else '?'}per_page=100&page={page}"
        req = urllib.request.Request(
            paginated,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            if e.code not in (403, 404):
                print(f"  HTTP {e.code} for {paginated}: {body}", file=sys.stderr)
            return results
        except urllib.error.URLError as e:
            print(f"  Request error for {paginated}: {e}", file=sys.stderr)
            return results

        if isinstance(data, list):
            if not data:
                break
            results.extend(data)
            if len(data) < 100:
                break
        else:
            break

        page += 1

    return results


def get_all_repos(org, token, api_url, include_archived=False):
    """Return list of repo names in the org."""
    repos = github_get(f"{api_url}/orgs/{org}/repos?type=all", token, api_url)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_repo_deploy_keys(org, repo, token, api_url):
    """Return (repo_name, key_count, keys list of metadata dicts)."""
    keys = github_get(f"{api_url}/repos/{org}/{repo}/keys", token, api_url)
    rows = []
    for key in keys:
        rows.append({
            "id": key.get("id"),
            "title": key.get("title", ""),
            "key": key.get("key", ""),
            "read_only": key.get("read_only", True),
            "verified": key.get("verified", False),
        })
    return repo, len(rows), rows


def main():
    parser = argparse.ArgumentParser(description="List repos with deploy keys")
    parser.add_argument("--org", required=True, help="GitHub organization name")
    parser.add_argument("--token", required=True, help="GitHub PAT")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="GitHub API base URL (default: https://api.github.com)")
    parser.add_argument("--output", default="repos_with_deploy_keys.csv",
                        help="Output CSV file (default: repos_with_deploy_keys.csv)")
    parser.add_argument("--include-archived", action="store_true",
                        help="Include archived repositories")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")

    print(f"Fetching repos for org: {args.org}")
    repos = get_all_repos(args.org, args.token, api_url, args.include_archived)
    print(f"Found {len(repos)} repos. Checking for deploy keys...")

    results = []
    for i, repo in enumerate(repos, 1):
        repo_name, count, rows = get_repo_deploy_keys(args.org, repo, args.token, api_url)
        if count > 0:
            titles = ",".join(r["title"] or f"key-{r['id']}" for r in rows)
            results.append((repo_name, count, titles))
            print(f"  [{i}/{len(repos)}] {repo_name}: {count} deploy key(s)")
        else:
            print(f"  [{i}/{len(repos)}] {repo_name}: no deploy keys", end="\r")

    print(f"\n\nRepositories with deploy keys: {len(results)} / {len(repos)}")

    results.sort(key=lambda x: x[0])

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["repository", "deploy_key_count", "titles"])
        for repo, count, titles in results:
            writer.writerow([repo, count, titles])

    print(f"Results saved to: {args.output}")

    print(f"\n{'Repository':<50} {'Keys':>5}  Titles")
    print("-" * 80)
    for repo, count, titles in results:
        print(f"{repo:<50} {count:>5}  {titles}")


if __name__ == "__main__":
    main()
