"""
deploy_keys — Repo-level GitHub deploy key migration utilities.

Deploy key private halves are write-only in the GitHub API and can never be
read back, so migration REGENERATES each deploy key as a brand-new ed25519
keypair: the public half is added to the destination repo (same title and
read_only flag), and the private half is stored in CyberArk (if configured)
or written to local files for manual hand-off to whatever system consumed
the original key.

Exposed functions:
    list_repos_with_deploy_keys(api_url, org, token, include_archived) -> list[dict]
    migrate_repo_deploy_keys(args) -> dict {success, failed, skipped}
"""

import importlib.util
import pathlib
from types import SimpleNamespace

_HERE = pathlib.Path(__file__).parent


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, _HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def list_repos_with_deploy_keys(api_url, org, token, include_archived=False):
    """
    Scan all repos in an org and return those that have repo-level deploy keys.
    Returns list of dicts: {repo, deploy_key_count, titles}
    """
    mod = _load("list-repos-with-deploy-keys.py")
    repos = mod.get_all_repos(org, token, api_url, include_archived)

    results = []
    for repo in repos:
        repo_name, count, rows = mod.get_repo_deploy_keys(org, repo, token, api_url)
        if count > 0:
            results.append({
                "repo": repo_name,
                "deploy_key_count": count,
                "titles": [r["title"] or f"key-{r['id']}" for r in rows],
            })

    results.sort(key=lambda r: r["repo"])
    return results


def migrate_repo_deploy_keys(
    source_org, dest_org, source_token, dest_token,
    api_url="https://api.github.com", dest_api_url="https://api.github.com",
    filter_repo=None, output_dir=None,
    cyberark_url=None, cyberark_username=None, cyberark_password=None, cyberark_safe=None,
    include_archived=False, dry_run=False,
):
    """
    Migrate (regenerate) repo-level deploy keys from source org to destination org.
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    mod = _load("migrate-deploy-keys.py")

    args = SimpleNamespace(
        source_org=source_org,
        dest_org=dest_org,
        source_token=source_token,
        dest_token=dest_token,
        api_url=api_url,
        dest_api_url=dest_api_url,
        filter_repo=filter_repo,
        output_dir=output_dir,
        cyberark_url=cyberark_url,
        cyberark_username=cyberark_username,
        cyberark_password=cyberark_password,
        cyberark_safe=cyberark_safe,
        include_archived=include_archived,
        dry_run=dry_run,
    )

    return mod.migrate_all(args)
