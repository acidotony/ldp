#!/usr/bin/env python3
"""
List all repositories in a GitHub organization that have GitHub App
installations with repo-level access, and which apps are installed on them.

How it works:
    1. GET /orgs/{org}/installations       -> all GitHub App installations on the org
    2. For each installation with repository_selection == "selected":
       GET /user/installations/{id}/repositories -> repos that installation can access
       (installations with repository_selection == "all" implicitly cover every repo)

Requirements:
    - Token must be a PAT belonging to an org owner/admin (org installations
      and per-installation repository lists are not accessible with a plain
      fine-grained token unless it has the right permissions).
    pip install requests

Usage:
    python list-repos-with-github-apps.py --org <ORG> --token <TOKEN> \
        [--api-url <URL>] [--output <FILE>] [--include-archived]
"""

import argparse
import csv
import sys

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


def gh_get(url, token, api_url):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    resp = requests.get(url, headers=headers)
    if resp.status_code not in (200,):
        msg = ""
        try:
            msg = resp.json().get("message", "")
        except ValueError:
            pass
        print(f"  Warning: GET {url} -> HTTP {resp.status_code}: {msg}", file=sys.stderr)
        return None
    return resp.json()


def gh_paginate(url, token, list_key=None):
    """Paginate a GitHub API endpoint. list_key is used when the response is
    an object with a nested array (e.g. {"installations": [...]})."""
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        data = gh_get(f"{url}{sep}per_page=100&page={page}", token, url)
        if data is None:
            return results
        items = data.get(list_key, []) if list_key else data
        if not items:
            return results
        results.extend(items)
        if len(items) < 100:
            return results
        page += 1


def get_org_installations(org, token, api_url):
    """Return list of installation dicts for the org."""
    return gh_paginate(f"{api_url}/orgs/{org}/installations", token, list_key="installations")


def get_installation_repos(installation_id, token, api_url):
    """Return list of repo full_names accessible to a 'selected' installation."""
    repos = gh_paginate(
        f"{api_url}/user/installations/{installation_id}/repositories", token, list_key="repositories"
    )
    return [r["name"] for r in repos]


def get_all_repos(org, token, api_url, include_archived=False):
    repos = gh_paginate(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def build_repo_app_map(org, token, api_url, include_archived=False):
    """
    Return dict: {repo_name: [{"app_slug", "app_id", "installation_id"}, ...]}
    """
    installations = get_org_installations(org, token, api_url)
    all_repos = set(get_all_repos(org, token, api_url, include_archived))

    repo_map = {repo: [] for repo in all_repos}

    for inst in installations:
        app_info = {
            "app_slug": inst.get("app_slug", ""),
            "app_id": inst.get("app_id"),
            "installation_id": inst.get("id"),
        }
        selection = inst.get("repository_selection", "selected")
        if selection == "all":
            target_repos = all_repos
        else:
            target_repos = [r for r in get_installation_repos(inst["id"], token, api_url) if r in all_repos]

        for repo in target_repos:
            repo_map[repo].append(app_info)

    return repo_map


def main():
    parser = argparse.ArgumentParser(description="List repos with GitHub App installations")
    parser.add_argument("--org", required=True, help="GitHub organization name")
    parser.add_argument("--token", required=True, help="GitHub PAT (org owner/admin)")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="GitHub API base URL (default: https://api.github.com)")
    parser.add_argument("--output", default="repos_with_github_apps.csv",
                        help="Output CSV file (default: repos_with_github_apps.csv)")
    parser.add_argument("--include-archived", action="store_true",
                        help="Include archived repositories")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")

    print(f"Fetching GitHub App installations for org: {args.org}")
    repo_map = build_repo_app_map(args.org, args.token, api_url, args.include_archived)

    results = [(repo, apps) for repo, apps in repo_map.items() if apps]
    results.sort(key=lambda x: x[0])

    print(f"\nRepositories with GitHub Apps installed: {len(results)} / {len(repo_map)}")

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["repository", "app_count", "app_slugs"])
        for repo, apps in results:
            slugs = ",".join(a["app_slug"] for a in apps)
            writer.writerow([repo, len(apps), slugs])

    print(f"Results saved to: {args.output}")

    print(f"\n{'Repository':<50} {'Apps':>5}  Slugs")
    print("-" * 80)
    for repo, apps in results:
        slugs = ",".join(a["app_slug"] for a in apps)
        print(f"{repo:<50} {len(apps):>5}  {slugs}")


if __name__ == "__main__":
    main()
