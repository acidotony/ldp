"""
github-apps — Per-repo GitHub App installation migration utilities.

GitHub Apps cannot be installed on an org via the REST API, so this module
does NOT install apps on the destination org. It assumes the same apps are
already installed there (matched by app slug) and grants each migrated repo
access to the matching destination installation.

Exposed functions:
    list_repos_with_github_apps(api_url, org, token, include_archived) -> dict {repo: [apps]}
    migrate_github_apps(args) -> dict {success, failed, skipped, missing_apps}
"""

import importlib.util
import pathlib
from types import SimpleNamespace

_HERE = pathlib.Path(__file__).parent


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, _HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def list_repos_with_github_apps(api_url, org, token, include_archived=False):
    """
    Scan all repos in an org and return those with GitHub App installations.
    Returns dict: {repo_name: [{"app_slug", "app_id", "installation_id"}, ...]}
    """
    mod = _load("list-repos-with-github-apps.py")
    return mod.build_repo_app_map(org, token, api_url, include_archived)


def migrate_repo_github_apps(
    source_org, dest_org, source_token, dest_token,
    api_url="https://api.github.com", dest_api_url="https://api.github.com",
    filter_repo=None, repo_list=None, include_archived=False, dry_run=False,
):
    """
    Grant migrated repos access to matching GitHub App installations on the
    destination org (apps must already be installed there; matched by app slug).
    Returns dict: {success, failed, skipped, missing_apps}
    """
    mod = _load("migrate-github-apps.py")

    args = SimpleNamespace(
        source_org=source_org,
        dest_org=dest_org,
        source_token=source_token,
        dest_token=dest_token,
        api_url=api_url,
        dest_api_url=dest_api_url,
        filter_repo=filter_repo,
        repo_list=repo_list,
        include_archived=include_archived,
        dry_run=dry_run,
    )

    return mod.migrate_all(args)
