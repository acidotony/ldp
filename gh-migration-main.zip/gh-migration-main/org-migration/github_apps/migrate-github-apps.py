#!/usr/bin/env python3
"""
Migrates GitHub App installations from a source org to a destination org, on
a per-repo basis, for the repos that were just migrated.

IMPORTANT:
    GitHub Apps cannot be "installed" on an org via the REST API — that
    requires the interactive install flow (or the app owner installing it
    ahead of time). This script therefore assumes the same apps are ALREADY
    installed on the destination org (matched by app slug) and simply grants
    each migrated repo access to the matching destination installation:

        PUT /user/installations/{installation_id}/repositories/{repository_id}

    Apps installed on the source org but NOT installed on the destination
    org are reported so they can be installed manually first.

Requirements:
    - Destination token must belong to an org owner/admin.
    - The GitHub Apps must already be installed on the destination org
      (any repository selection mode); this script only attaches repos.
    pip install requests

Usage:
    python migrate-github-apps.py \
        --source-org <SOURCE_ORG> \
        --source-token <SOURCE_TOKEN> \
        --dest-org <DEST_ORG> \
        --dest-token <DEST_TOKEN> \
        [--api-url <SOURCE_API_URL>] \
        [--dest-api-url <DEST_API_URL>] \
        [--filter-repo <REPO>] \
        [--repo-list <FILE with "src_repo dest_repo ..." lines, e.g. migration_successes.txt>] \
        [--include-archived] \
        [--dry-run]
"""

import argparse
import sys

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_request(method, url, token, body=None):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    resp = requests.request(method, url, headers=headers, json=body)
    try:
        data = resp.json() if resp.content else {}
    except ValueError:
        data = {}
    return resp.status_code, data


def gh_paginate(url, token, list_key=None):
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        status, data = gh_request("GET", f"{url}{sep}per_page=100&page={page}", token)
        if status != 200:
            msg = data.get("message", "") if isinstance(data, dict) else ""
            print(f"  Warning: GET {url} -> HTTP {status}: {msg}", file=sys.stderr)
            return results
        items = data.get(list_key, []) if list_key else data
        if not items:
            return results
        results.extend(items)
        if len(items) < 100:
            return results
        page += 1


def get_org_installations(org, token, api_url):
    return gh_paginate(f"{api_url}/orgs/{org}/installations", token, list_key="installations")


def get_installation_repos(installation_id, token, api_url):
    repos = gh_paginate(
        f"{api_url}/user/installations/{installation_id}/repositories", token, list_key="repositories"
    )
    return {r["name"] for r in repos}


def get_repo_apps(org, repo, token, api_url, installations, installation_repo_cache):
    """Return list of installation dicts (source org) that have access to `repo`."""
    apps = []
    for inst in installations:
        selection = inst.get("repository_selection", "selected")
        if selection == "all":
            apps.append(inst)
            continue
        inst_id = inst["id"]
        if inst_id not in installation_repo_cache:
            installation_repo_cache[inst_id] = get_installation_repos(inst_id, token, api_url)
        if repo in installation_repo_cache[inst_id]:
            apps.append(inst)
    return apps


def get_repo_id(org, repo, token, api_url):
    status, data = gh_request("GET", f"{api_url}/repos/{org}/{repo}", token)
    if status != 200:
        return None
    return data.get("id")


def add_repo_to_installation(installation_id, repo_id, token, api_url):
    status, data = gh_request(
        "PUT", f"{api_url}/user/installations/{installation_id}/repositories/{repo_id}", token
    )
    ok = status in (204, 200)
    msg = data.get("message", "") if isinstance(data, dict) else ""
    return ok, msg


# ─────────────────────────────────────────────
# Migration
# ─────────────────────────────────────────────

def build_dest_installation_index(dest_org, dest_token, dest_api_url):
    """Return dict: {app_slug: installation_id} for the destination org."""
    installations = get_org_installations(dest_org, dest_token, dest_api_url)
    return {inst.get("app_slug", ""): inst["id"] for inst in installations}, installations


def migrate_repo_apps(
    source_org, dest_org, src_repo, dest_repo,
    source_token, dest_token, source_api_url, dest_api_url,
    source_installations, installation_repo_cache, dest_index, dry_run=False,
):
    """Attach dest_repo to every destination installation matching an app
    installed on src_repo in the source org. Returns list of (app_slug, ok, msg)."""
    apps = get_repo_apps(
        source_org, src_repo, source_token, source_api_url,
        source_installations, installation_repo_cache,
    )
    if not apps:
        return []

    results = []
    dest_repo_id = None
    if not dry_run:
        dest_repo_id = get_repo_id(dest_org, dest_repo, dest_token, dest_api_url)

    for app in apps:
        slug = app.get("app_slug", "")
        dest_installation_id = dest_index.get(slug)
        if dest_installation_id is None:
            results.append((slug, False, "app not installed on destination org - install manually"))
            continue
        if dry_run:
            results.append((slug, True, "dry-run: would add repo to destination installation"))
            continue
        if dest_repo_id is None:
            results.append((slug, False, f"destination repo {dest_repo} not found"))
            continue
        ok, msg = add_repo_to_installation(dest_installation_id, dest_repo_id, dest_token, dest_api_url)
        results.append((slug, ok, msg or ("added" if ok else "failed")))

    return results


def get_all_repos(org, token, api_url, include_archived=False):
    repos = gh_paginate(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def load_repo_pairs(path, source_org, dest_org):
    """Parse a repo list file (same format as migration_successes.txt:
    'src_repo dest_repo src_org dest_org'). Returns list of (src_repo, dest_repo)."""
    pairs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            src_repo = parts[0]
            dest_repo = parts[1] if len(parts) > 1 else parts[0]
            pairs.append((src_repo, dest_repo))
    return pairs


def migrate_all(args):
    source_api_url = args.api_url.rstrip("/")
    dest_api_url = args.dest_api_url.rstrip("/")

    if args.repo_list:
        repo_pairs = load_repo_pairs(args.repo_list, args.source_org, args.dest_org)
    elif args.filter_repo:
        repo_pairs = [(args.filter_repo, args.filter_repo)]
    else:
        repos = get_all_repos(args.source_org, args.source_token, source_api_url, args.include_archived)
        repo_pairs = [(r, r) for r in repos]

    print(f"Migrating GitHub App access for {len(repo_pairs)} repo(s): "
          f"{args.source_org} -> {args.dest_org}")

    print("Fetching source org installations...")
    source_installations = get_org_installations(args.source_org, args.source_token, source_api_url)
    print(f"  Found {len(source_installations)} installation(s) on source org")

    print("Fetching destination org installations...")
    dest_index, _ = build_dest_installation_index(args.dest_org, args.dest_token, dest_api_url)
    print(f"  Found {len(dest_index)} installation(s) on destination org")

    installation_repo_cache = {}
    success, failed, skipped, missing_apps = [], [], [], []

    for src_repo, dest_repo in repo_pairs:
        app_results = migrate_repo_apps(
            args.source_org, args.dest_org, src_repo, dest_repo,
            args.source_token, args.dest_token, source_api_url, dest_api_url,
            source_installations, installation_repo_cache, dest_index, args.dry_run,
        )
        if not app_results:
            skipped.append((src_repo, "no GitHub Apps installed on source repo"))
            print(f"  {src_repo}: no GitHub Apps installed")
            continue

        for slug, ok, msg in app_results:
            label = f"{dest_repo} [{slug}]"
            if ok:
                success.append((label, msg))
                print(f"  {label}: {msg}")
            elif "not installed on destination org" in msg:
                missing_apps.append((label, msg))
                print(f"  {label}: {msg}", file=sys.stderr)
            else:
                failed.append((label, msg))
                print(f"  {label}: FAILED - {msg}", file=sys.stderr)

    print(f"\n{'=' * 60}")
    print(f"GITHUB APPS SUMMARY  OK: {len(success)}  Failed: {len(failed)}  "
          f"Missing on dest: {len(missing_apps)}  Skipped: {len(skipped)}")
    if missing_apps:
        print("\nApps that must be installed manually on the destination org:")
        for label, msg in missing_apps:
            print(f"  [MISSING] {label}: {msg}")
    if failed:
        print("\nFailed:")
        for label, msg in failed:
            print(f"  [FAIL] {label}: {msg}")
    print("=" * 60)

    return {"success": success, "failed": failed, "skipped": skipped, "missing_apps": missing_apps}


def build_parser():
    parser = argparse.ArgumentParser(description="Migrate GitHub App repo access from source org to destination org")
    parser.add_argument("--source-org", required=True)
    parser.add_argument("--source-token", required=True)
    parser.add_argument("--dest-org", required=True)
    parser.add_argument("--dest-token", required=True)
    parser.add_argument("--api-url", default="https://api.github.com", help="Source API URL")
    parser.add_argument("--dest-api-url", default="https://api.github.com", help="Destination API URL")
    parser.add_argument("--filter-repo", default=None, help="Restrict to a single repo (name same on both orgs)")
    parser.add_argument("--repo-list", default=None,
                        help="Path to a repo list file (format: 'src_repo dest_repo ...' per line)")
    parser.add_argument("--include-archived", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    migrate_all(args)


if __name__ == "__main__":
    main()
