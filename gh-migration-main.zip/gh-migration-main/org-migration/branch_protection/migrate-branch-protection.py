#!/usr/bin/env python3
"""
Migrates legacy branch protection rules (GET/PUT
/repos/{owner}/{repo}/branches/{branch}/protection) from a source org to a
destination org.

Copies, per protected branch:
    - Required status checks (strict flag + contexts)
    - Required pull request reviews (approving review count, dismiss stale
      reviews, require code owner reviews, require last push approval)
    - Enforce admins
    - Required linear history / allow force pushes / allow deletions
    - Required conversation resolution
    - Restrictions (users/teams/apps allowed to push), resolved by
      login/slug on the destination — unresolved entries are reported so
      they can be added manually.

NOTE: This targets the classic per-branch protection API. Newer repository
rulesets are a separate feature and are out of scope (see tasks.md).

Requirements:
    pip install requests

Usage:
    python migrate-branch-protection.py \
        --source-org <SOURCE_ORG> \
        --source-token <SOURCE_TOKEN> \
        --dest-org <DEST_ORG> \
        --dest-token <DEST_TOKEN> \
        [--api-url <SOURCE_API_URL>] \
        [--dest-api-url <DEST_API_URL>] \
        [--filter-repo <REPO>] \
        [--concurrency <N>] \
        [--include-archived] \
        [--dry-run]
"""

import argparse
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_request(method, url, token, body=None):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    resp = requests.request(method, url, headers=headers, json=body)
    try:
        data = resp.json() if resp.content else {}
    except ValueError:
        data = {}
    return resp.status_code, data


def gh_paginate(url, token, list_key=None):
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        status, data = gh_request("GET", f"{url}{sep}per_page=100&page={page}", token)
        if status in (403, 404):
            return results
        if status != 200:
            msg = data.get("message", "") if isinstance(data, dict) else ""
            print(f"  Warning: GET {url} -> HTTP {status}: {msg}", file=sys.stderr)
            return results
        batch = data.get(list_key, []) if list_key else data
        if not batch:
            return results
        results.extend(batch)
        if len(batch) < 100:
            return results
        page += 1


def get_all_repos(org, token, api_url, include_archived=False):
    repos = gh_paginate(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_protected_branch_names(org, repo, token, api_url):
    branches = gh_paginate(f"{api_url}/repos/{org}/{repo}/branches?protected=true", token)
    return [b["name"] for b in branches]


def get_branch_protection(org, repo, branch, token, api_url):
    status, data = gh_request(
        "GET", f"{api_url}/repos/{org}/{repo}/branches/{branch}/protection", token
    )
    if status != 200:
        return None
    return data


def resolve_restriction_entities(restrictions, dest_org, dest_token, dest_api_url):
    """Resolve users/teams/apps in restrictions to logins/slugs that exist on dest."""
    if not restrictions:
        return None, []

    users, teams, apps, unresolved = [], [], [], []

    for u in restrictions.get("users", []):
        login = u.get("login")
        status, _ = gh_request("GET", f"{dest_api_url}/users/{login}", dest_token)
        if status == 200:
            users.append(login)
        else:
            unresolved.append(f"user:{login}")

    for t in restrictions.get("teams", []):
        slug = t.get("slug")
        status, _ = gh_request("GET", f"{dest_api_url}/orgs/{dest_org}/teams/{slug}", dest_token)
        if status == 200:
            teams.append(slug)
        else:
            unresolved.append(f"team:{slug}")

    for a in restrictions.get("apps", []):
        slug = a.get("slug")
        apps.append(slug)  # apps installed org-wide; can't verify without extra call, pass through

    payload = {"users": users, "teams": teams, "apps": apps}
    return payload, unresolved


def build_protection_payload(protection, restrictions_payload):
    """Convert a GET protection response into a PUT request body."""
    required_status_checks = protection.get("required_status_checks")
    rsc_payload = None
    if required_status_checks:
        rsc_payload = {
            "strict": required_status_checks.get("strict", False),
            "contexts": required_status_checks.get("contexts", []),
        }
        checks = required_status_checks.get("checks")
        if checks:
            rsc_payload["checks"] = [{"context": c["context"], "app_id": c.get("app_id")} for c in checks]

    reviews = protection.get("required_pull_request_reviews")
    reviews_payload = None
    if reviews:
        reviews_payload = {
            "dismiss_stale_reviews": reviews.get("dismiss_stale_reviews", False),
            "require_code_owner_reviews": reviews.get("require_code_owner_reviews", False),
            "required_approving_review_count": reviews.get("required_approving_review_count", 0),
            "require_last_push_approval": reviews.get("require_last_push_approval", False),
        }

    return {
        "required_status_checks": rsc_payload,
        "enforce_admins": (protection.get("enforce_admins") or {}).get("enabled", False),
        "required_pull_request_reviews": reviews_payload,
        "restrictions": restrictions_payload,
        "required_linear_history": (protection.get("required_linear_history") or {}).get("enabled", False),
        "allow_force_pushes": (protection.get("allow_force_pushes") or {}).get("enabled", False),
        "allow_deletions": (protection.get("allow_deletions") or {}).get("enabled", False),
        "required_conversation_resolution": (protection.get("required_conversation_resolution") or {}).get("enabled", False),
        "lock_branch": (protection.get("lock_branch") or {}).get("enabled", False),
        "allow_fork_syncing": (protection.get("allow_fork_syncing") or {}).get("enabled", False),
    }


def apply_branch_protection(org, repo, branch, token, api_url, payload):
    status, data = gh_request(
        "PUT", f"{api_url}/repos/{org}/{repo}/branches/{branch}/protection", token, payload
    )
    ok = status in (200, 201)
    msg = data.get("message", "") if isinstance(data, dict) else ""
    return ok, msg


# ─────────────────────────────────────────────
# Migration
# ─────────────────────────────────────────────

def migrate_repo_branch_protection(
    source_org, dest_org, repo, source_token, dest_token,
    source_api_url="https://api.github.com", dest_api_url="https://api.github.com",
    dry_run=False,
):
    """
    Copy all legacy branch protection rules for a single repo from source to dest.
    Returns list of (branch_name, ok, msg).
    """
    branch_names = get_protected_branch_names(source_org, repo, source_token, source_api_url)
    results = []

    for branch in branch_names:
        protection = get_branch_protection(source_org, repo, branch, source_token, source_api_url)
        if not protection:
            continue

        if dry_run:
            results.append((branch, True, "dry-run: would apply branch protection"))
            continue

        restrictions_payload, unresolved = resolve_restriction_entities(
            protection.get("restrictions"), dest_org, dest_token, dest_api_url
        )
        payload = build_protection_payload(protection, restrictions_payload)

        ok, msg = apply_branch_protection(dest_org, repo, branch, dest_token, dest_api_url, payload)
        if not ok:
            results.append((branch, False, msg or "failed to apply branch protection"))
            continue

        note = "applied"
        if unresolved:
            note += f" (unresolved restriction entries: {', '.join(unresolved)} - add manually)"
        results.append((branch, True, note))

    return results


def migrate_all(args):
    """
    Migrate legacy branch protection rules for every repo in the source org
    (or a single repo if args.filter_repo is set).
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    source_api_url = args.api_url.rstrip("/")
    dest_api_url = args.dest_api_url.rstrip("/")

    if args.filter_repo:
        repos = [args.filter_repo]
    else:
        repos = get_all_repos(args.source_org, args.source_token, source_api_url, args.include_archived)

    print(f"Migrating legacy branch protection rules for {len(repos)} repo(s): "
          f"{args.source_org} -> {args.dest_org}")

    success, failed, skipped = [], [], []

    def _process(repo):
        branch_results = migrate_repo_branch_protection(
            args.source_org, args.dest_org, repo,
            args.source_token, args.dest_token,
            source_api_url, dest_api_url, args.dry_run,
        )
        if not branch_results:
            return repo, "skipped", []
        return repo, "done", branch_results

    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {executor.submit(_process, repo): repo for repo in repos}
        for future in as_completed(futures):
            repo, status, branch_results = future.result()
            if status == "skipped":
                skipped.append(repo)
                continue
            all_ok = all(ok for _, ok, _ in branch_results)
            for branch, ok, msg in branch_results:
                label = f"{repo}:{branch}"
                if ok:
                    print(f"  [OK]   {label} - {msg}")
                    success.append(label)
                else:
                    print(f"  [FAIL] {label} - {msg}")
                    failed.append((label, msg))

    return {"success": success, "failed": failed, "skipped": skipped}


def main():
    parser = argparse.ArgumentParser(description="Migrate legacy branch protection rules between orgs")
    parser.add_argument("--source-org", required=True, help="Source GitHub organization name")
    parser.add_argument("--source-token", required=True, help="Source GitHub PAT")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="Source API base URL (default: https://api.github.com)")
    parser.add_argument("--dest-org", required=True, help="Destination GitHub organization name")
    parser.add_argument("--dest-token", required=True, help="Destination GitHub PAT")
    parser.add_argument("--dest-api-url", default="https://api.github.com",
                        help="Destination API base URL (default: https://api.github.com)")
    parser.add_argument("--filter-repo", default=None, help="Restrict to a single repo")
    parser.add_argument("--concurrency", type=int, default=10, help="Parallel operations (default: 10)")
    parser.add_argument("--include-archived", action="store_true", help="Include archived repositories")
    parser.add_argument("--dry-run", action="store_true", help="Simulate without making changes")
    args = parser.parse_args()

    results = migrate_all(args)

    print("\n" + "=" * 60)
    print(f"BRANCH PROTECTION SUMMARY  OK: {len(results['success'])}  "
          f"Failed: {len(results['failed'])}  Skipped: {len(results['skipped'])}")
    if results["failed"]:
        print("\nFailed:")
        for item, msg in results["failed"]:
            print(f"  [FAIL] {item}: {msg}")
    print("=" * 60)


if __name__ == "__main__":
    main()
