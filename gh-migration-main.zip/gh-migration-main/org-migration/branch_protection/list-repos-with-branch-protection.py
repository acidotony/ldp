#!/usr/bin/env python3
"""
List all repositories in a GitHub organization that have legacy branch
protection rules configured (GET /repos/{owner}/{repo}/branches/{branch}/protection),
along with a summary of what each protected branch enforces.

NOTE: "Legacy" here means the classic per-branch protection API, as opposed
to the newer repository rulesets feature (rulesets are a separate, out of
scope feature per tasks.md).

Usage:
    python list-repos-with-branch-protection.py --org <ORG> --token <TOKEN> \
        [--api-url <URL>] [--output <FILE>] [--include-archived]
"""

import argparse
import csv
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import urllib.request
import urllib.error


def github_get(url, token):
    """GET a single GitHub API resource. Returns parsed JSON, or None on 403/404."""
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        if e.code not in (403, 404):
            body = e.read().decode()
            print(f"  HTTP {e.code} for {url}: {body}", file=sys.stderr)
        return None
    except urllib.error.URLError as e:
        print(f"  Request error for {url}: {e}", file=sys.stderr)
        return None


def github_list(url, token, list_key=None):
    """Paginate through a GitHub API list endpoint."""
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        data = github_get(f"{url}{sep}per_page=100&page={page}", token)
        if not data:
            return results
        batch = data.get(list_key, []) if list_key else data
        if not batch:
            return results
        results.extend(batch)
        if len(batch) < 100:
            return results
        page += 1


def get_all_repos(org, token, api_url, include_archived=False):
    repos = github_list(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_repo_branches(org, repo, token, api_url):
    return github_list(f"{api_url}/repos/{org}/{repo}/branches?protected=true", token)


def get_branch_protection(org, repo, branch, token, api_url):
    return github_get(f"{api_url}/repos/{org}/{repo}/branches/{branch}/protection", token)


def get_repo_branch_protections(org, repo, token, api_url):
    """Return (repo_name, list of {branch, summary dict}) for protected branches."""
    branches = get_repo_branches(org, repo, token, api_url)
    rows = []
    for b in branches:
        branch_name = b["name"]
        protection = get_branch_protection(org, repo, branch_name, token, api_url)
        if not protection:
            continue
        required_checks = (protection.get("required_status_checks") or {}).get("contexts", [])
        required_reviews = protection.get("required_pull_request_reviews") or {}
        rows.append({
            "branch": branch_name,
            "required_status_checks": len(required_checks),
            "required_reviewers": required_reviews.get("required_approving_review_count", 0),
            "enforce_admins": (protection.get("enforce_admins") or {}).get("enabled", False),
            "restrictions": bool(protection.get("restrictions")),
        })
    return repo, rows


def main():
    parser = argparse.ArgumentParser(description="List repos with legacy branch protection rules")
    parser.add_argument("--org", required=True, help="GitHub organization name")
    parser.add_argument("--token", required=True, help="GitHub PAT (needs repo/admin:repo_hook scope)")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="GitHub API base URL (default: https://api.github.com)")
    parser.add_argument("--output", default="repos_with_branch_protection.csv",
                        help="Output CSV file (default: repos_with_branch_protection.csv)")
    parser.add_argument("--concurrency", type=int, default=10, help="Parallel requests (default: 10)")
    parser.add_argument("--include-archived", action="store_true", help="Include archived repositories")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")

    print(f"Fetching repos for org: {args.org}")
    repos = get_all_repos(args.org, args.token, api_url, args.include_archived)
    print(f"Found {len(repos)} repos. Checking for branch protection rules...")

    results = []
    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {
            executor.submit(get_repo_branch_protections, args.org, repo, args.token, api_url): repo
            for repo in repos
        }
        for future in as_completed(futures):
            repo, rows = future.result()
            if rows:
                results.append({"repo": repo, "branches": rows})
                print(f"  {repo}: {len(rows)} protected branch(es)")

    results.sort(key=lambda r: r["repo"])

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["repo", "branch", "required_status_checks", "required_reviewers", "enforce_admins", "restrictions"])
        for r in results:
            for b in r["branches"]:
                writer.writerow([
                    r["repo"], b["branch"], b["required_status_checks"],
                    b["required_reviewers"], b["enforce_admins"], b["restrictions"],
                ])

    total_branches = sum(len(r["branches"]) for r in results)
    print(f"\nFound {len(results)} repo(s) with {total_branches} protected branch(es) total.")
    print(f"Results saved to: {args.output}")


if __name__ == "__main__":
    main()
