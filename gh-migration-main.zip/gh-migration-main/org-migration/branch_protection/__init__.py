"""
branch_protection — Legacy branch protection rules migration utilities.

Copies legacy per-branch protection settings (required status checks,
required PR reviews, enforce admins, restrictions, etc.) from a source org
to a destination org using the classic REST API
(GET/PUT /repos/{owner}/{repo}/branches/{branch}/protection).

NOTE: Newer repository rulesets are a different feature and are out of
scope for this module.

Exposed functions:
    list_repos_with_branch_protection(api_url, org, token, include_archived, concurrency) -> list[dict]
    migrate_repo_branch_protection(...) -> dict {success, failed, skipped}
"""

import importlib.util
import pathlib
from types import SimpleNamespace

_HERE = pathlib.Path(__file__).parent


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, _HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def list_repos_with_branch_protection(
    api_url, org, token, include_archived=False, concurrency=10
):
    """
    Scan all repos in an org and return those that have protected branches.
    Returns list of dicts: {repo, branch_count, branches}
    """
    mod = _load("list-repos-with-branch-protection.py")
    repos = mod.get_all_repos(org, token, api_url, include_archived)

    import concurrent.futures
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as ex:
        futures = {
            ex.submit(mod.get_repo_branch_protections, org, repo, token, api_url): repo
            for repo in repos
        }
        for future in concurrent.futures.as_completed(futures):
            repo_name, rows = future.result()
            if rows:
                results.append({
                    "repo": repo_name,
                    "branch_count": len(rows),
                    "branches": [r["branch"] for r in rows],
                })

    results.sort(key=lambda r: r["repo"])
    return results


def migrate_repo_branch_protection(
    source_org, dest_org, source_token, dest_token,
    api_url="https://api.github.com", dest_api_url="https://api.github.com",
    filter_repo=None, concurrency=10, include_archived=False, dry_run=False,
):
    """
    Migrate legacy branch protection rules from source org to destination org.
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    mod = _load("migrate-branch-protection.py")

    args = SimpleNamespace(
        source_org=source_org,
        dest_org=dest_org,
        source_token=source_token,
        dest_token=dest_token,
        api_url=api_url,
        dest_api_url=dest_api_url,
        filter_repo=filter_repo,
        concurrency=concurrency,
        include_archived=include_archived,
        dry_run=dry_run,
    )
    return mod.migrate_all(args)
