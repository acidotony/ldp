#!/usr/bin/env python3
"""
main.py — Migration orchestrator for org-migration toolkit.

Subcommands:
  audit       Scan source org and report what needs to be migrated
  secrets     Full secrets pipeline (list -> CyberArk import -> restore to dest)
  packages    Migrate all packages (containers + ecosystems)
  all         Run the full pipeline in order

Usage:
  # Recommended — config file drives everything
  python main.py --config config.yml all

  # Or with individual subcommands
  python main.py --config config.yml audit
  python main.py --config config.yml secrets
  python main.py --config config.yml packages

  # CLI flags still work and override config file values
  python main.py --config config.yml all --dry-run --filter-repo my-repo

Copy config.example.yml to config.yml and fill in the values before running.
Sensitive values can also be set via env vars: SOURCE_TOKEN, DEST_TOKEN, CYBERARK_PASSWORD
"""

import argparse
import sys
import os

# Add org-migration dir to path so packages/ and secrets/ are importable
sys.path.insert(0, os.path.dirname(__file__))

from packages import (
    list_packages,
    migrate_container_packages,
    migrate_ecosystem_packages,
)
from secrets import (
    list_repos_with_secrets,
    deploy_cyberark_importer,
    restore_from_cyberark,
)


# ─────────────────────────────────────────────
# Config file loader
# ─────────────────────────────────────────────

def load_config(path):
    """Load YAML config file. Returns flat namespace dict."""
    try:
        import yaml
    except ImportError:
        print("ERROR: 'pyyaml' is required for config file support. Run: pip install -r requirements.txt",
              file=sys.stderr)
        sys.exit(1)

    with open(path) as f:
        cfg = yaml.safe_load(f)

    src  = cfg.get("source", {})
    dst  = cfg.get("dest", {})
    ca   = cfg.get("cyberark", {})
    pkgs = cfg.get("packages", {})
    opts = cfg.get("options", {})

    # Sensitive values come exclusively from environment variables
    source_token    = os.environ.get("SOURCE_TOKEN", "")
    dest_token      = os.environ.get("DEST_TOKEN", "")
    cyberark_pass   = os.environ.get("CYBERARK_PASSWORD", "")

    return {
        "source_org":         src.get("org", ""),
        "source_token":       source_token,
        "source_api_url":     src.get("api_url", "https://api.github.com"),
        "dest_org":           dst.get("org", ""),
        "dest_token":         dest_token,
        "dest_api_url":       dst.get("api_url", "https://api.github.com"),
        "cyberark_url":       ca.get("url", ""),
        "cyberark_username":  ca.get("username", ""),
        "cyberark_password":  cyberark_pass,
        "cyberark_safe":      ca.get("safe", ""),
        "registry":           pkgs.get("registry", "ghcr.io"),
        "package_type":       pkgs.get("package_type", "all"),
        "work_dir":           pkgs.get("work_dir"),
        "dry_run":            opts.get("dry_run", False),
        "include_archived":   opts.get("include_archived", False),
        "concurrency":        opts.get("concurrency", 10),
        "filter_repo":        opts.get("filter_repo"),
        "filter_package":     opts.get("filter_package"),
        "skip_cleanup":       opts.get("skip_cleanup", False),
    }


def validate_config(cfg, command):
    """Check required fields are set for the given command."""
    errors = []

    if not cfg.get("source_org"):
        errors.append("  config.yml: source.org is not set")
    if not cfg.get("source_token"):
        errors.append("  env var SOURCE_TOKEN is not set")

    if command in ("secrets", "packages", "all"):
        if not cfg.get("dest_org"):
            errors.append("  config.yml: dest.org is not set")
        if not cfg.get("dest_token"):
            errors.append("  env var DEST_TOKEN is not set")

    if command in ("secrets", "all"):
        if not cfg.get("cyberark_url"):
            errors.append("  config.yml: cyberark.url is not set")
        if not cfg.get("cyberark_username"):
            errors.append("  config.yml: cyberark.username is not set")
        if not cfg.get("cyberark_password"):
            errors.append("  env var CYBERARK_PASSWORD is not set")
        if not cfg.get("cyberark_safe"):
            errors.append("  config.yml: cyberark.safe is not set")

    if errors:
        print("ERROR: Missing required values:", file=sys.stderr)
        for e in errors:
            print(e, file=sys.stderr)
        sys.exit(1)


def merge_args(cfg, cli_args):
    """
    Merge config file values with CLI overrides.
    CLI flags take precedence when explicitly provided.
    Returns a SimpleNamespace usable throughout the app.
    """
    from types import SimpleNamespace

    merged = dict(cfg)

    # CLI flags that override config when set
    overridable = [
        "dry_run", "include_archived", "concurrency",
        "filter_repo", "filter_package", "skip_cleanup",
        "package_type", "registry", "work_dir",
    ]
    for key in overridable:
        cli_val = getattr(cli_args, key, None)
        if cli_val is not None and cli_val is not False:
            merged[key] = cli_val

    # Boolean flags: if set on CLI, always override
    for key in ("dry_run", "include_archived", "skip_cleanup"):
        if getattr(cli_args, key, False):
            merged[key] = True

    return SimpleNamespace(**merged)


# ─────────────────────────────────────────────
# Shared argument groups
# ─────────────────────────────────────────────

def add_common_args(p):
    p.add_argument("--dry-run", action="store_true", default=False,
                   help="Simulate without making changes (overrides config)")
    p.add_argument("--concurrency", type=int, default=None,
                   help="Parallel operations (overrides config)")
    p.add_argument("--include-archived", action="store_true", default=False,
                   help="Include archived repos (overrides config)")
    p.add_argument("--filter-repo", default=None,
                   help="Restrict to a single repo (overrides config)")


# ─────────────────────────────────────────────
# audit
# ─────────────────────────────────────────────

def cmd_audit(args):
    print("=" * 60)
    print(f"AUDIT: {args.source_org}")
    print("=" * 60)

    # Secrets
    print("\n[1/2] Scanning for secrets...")
    repos_with_secrets = list_repos_with_secrets(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived, args.concurrency,
    )
    total_secrets = sum(r["secret_count"] for r in repos_with_secrets)
    print(f"      Repos with secrets : {len(repos_with_secrets)}")
    print(f"      Total secrets      : {total_secrets}")

    # Packages
    print("\n[2/2] Scanning for packages...")
    pkgs = list_packages(args.source_api_url, args.source_org, args.source_token,
                         filter_repo=args.filter_repo)
    by_type = {}
    for p in pkgs:
        by_type.setdefault(p["package_type"], 0)
        by_type[p["package_type"]] += 1
    print(f"      Total packages     : {len(pkgs)}")
    for ptype, count in sorted(by_type.items()):
        print(f"        {ptype:<14}: {count}")

    print("\n" + "=" * 60)
    print("AUDIT SUMMARY")
    print(f"  Repos with secrets : {len(repos_with_secrets)}")
    print(f"  Total secrets      : {total_secrets}")
    print(f"  Total packages     : {len(pkgs)}")
    print("=" * 60)

    if repos_with_secrets:
        print("\nRepos with secrets:")
        for r in repos_with_secrets:
            print(f"  {r['repo']:<50} {r['secret_count']:>3} secret(s): {', '.join(r['secret_names'])}")


# ─────────────────────────────────────────────
# secrets
# ─────────────────────────────────────────────

def cmd_secrets(args):
    print("=" * 60)
    print(f"SECRETS MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    # ── Step 1: Deploy importer workflows to source repos ─────────────────
    print("\n[1/3] Deploying CyberArk importer workflow to source repos...")
    success, failed = deploy_cyberark_importer(
        org=args.source_org,
        token=args.source_token,
        api_url=args.source_api_url,
        concurrency=args.concurrency,
        dry_run=args.dry_run,
        include_archived=args.include_archived,
    )
    print(f"      Deployed: {len(success)}  Failed: {len(failed)}")
    if failed:
        for repo, msg in failed:
            print(f"      [FAIL] {repo}: {msg}")

    if args.dry_run:
        print("\n[DRY RUN] Skipping steps 2 and 3.")
        return

    # ── Step 2: Trigger importer workflows via gh CLI (no interaction) ────
    print("\n[2/3] Triggering CyberArk importer workflows in all source repos...")
    import subprocess, shutil
    if shutil.which("gh"):
        trigger_cmd = (
            f"gh api /orgs/{args.source_org}/repos --paginate -q '.[].name' | "
            f"xargs -P 5 -I {{}} gh workflow run import-to-cyberark.yml "
            f"--repo {args.source_org}/{{}} "
            f"--field cyberark_safe={args.cyberark_safe}"
        )
        print(f"      Running: {trigger_cmd}")
        result = subprocess.run(trigger_cmd, shell=True)
        if result.returncode != 0:
            print("      WARNING: some workflow triggers may have failed — check GitHub Actions UI",
                  file=sys.stderr)

        # Wait for all workflow runs to complete
        print("      Waiting for all workflow runs to finish...")
        wait_cmd = (
            f"gh api /orgs/{args.source_org}/repos --paginate -q '.[].name' | "
            f"xargs -P 5 -I {{}} sh -c "
            f"'gh run list --repo {args.source_org}/{{}} "
            f"--workflow import-to-cyberark.yml --limit 1 --json status -q \'.[0].status\' | "
            f"grep -q completed || gh run watch --repo {args.source_org}/{{}} "
            f"$(gh run list --repo {args.source_org}/{{}} "
            f"--workflow import-to-cyberark.yml --limit 1 --json databaseId -q \'.[0].databaseId\')'"
        )
        subprocess.run(wait_cmd, shell=True)
        print("      All workflow runs completed.")
    else:
        print("      WARNING: 'gh' CLI not found — skipping automatic workflow trigger.")
        print(f"      Manually trigger 'import-to-cyberark.yml' in all repos of {args.source_org}")
        print(f"      then re-run: python main.py --config <config> secrets")
        sys.exit(1)

    # ── Step 3: Restore from CyberArk to destination ──────────────────────
    print("\n[3/3] Restoring secrets from CyberArk to destination org...")
    results = restore_from_cyberark(
        cyberark_url=args.cyberark_url,
        cyberark_username=args.cyberark_username,
        cyberark_password=args.cyberark_password,
        cyberark_safe=args.cyberark_safe,
        source_org=args.source_org,
        dest_org=args.dest_org,
        dest_token=args.dest_token,
        api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        dry_run=args.dry_run,
    )

    print(f"\n      OK      : {len(results['success'])}")
    print(f"      Failed  : {len(results['failed'])}")
    print(f"      Skipped : {len(results['skipped'])}")

    # ── Cleanup: remove importer workflows ────────────────────────────────
    if not args.skip_cleanup:
        print("\n[cleanup] Removing importer workflows from source repos...")
        deploy_cyberark_importer(
            org=args.source_org,
            token=args.source_token,
            api_url=args.source_api_url,
            concurrency=args.concurrency,
            dry_run=args.dry_run,
            cleanup=True,
        )
        print("      Done.")

    _print_section_summary("SECRETS", results["success"], results["failed"])


# ─────────────────────────────────────────────
# packages
# ─────────────────────────────────────────────

def cmd_packages(args):
    print("=" * 60)
    print(f"PACKAGE MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    all_success, all_failed = [], []

    # ── Containers ────────────────────────────────────────────────────────
    print("\n[1/2] Migrating container images (Podman)...")
    success, failed = migrate_container_packages(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        registry=args.registry,
        filter_repo=args.filter_repo,
        filter_package=args.filter_package,
        concurrency=args.concurrency,
        dry_run=args.dry_run,
    )
    all_success.extend(success)
    all_failed.extend(failed)
    print(f"      OK: {len(success)}  Failed: {len(failed)}")

    # ── Ecosystem packages ────────────────────────────────────────────────
    print("\n[2/2] Migrating ecosystem packages (npm/maven/gradle/nuget/rubygems)...")
    success, failed = migrate_ecosystem_packages(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        package_type=args.package_type,
        filter_package=args.filter_package,
        work_dir=args.work_dir,
        dry_run=args.dry_run,
    )
    all_success.extend(success)
    all_failed.extend(failed)
    print(f"      OK: {len(success)}  Failed: {len(failed)}")

    _print_section_summary("PACKAGES", all_success, all_failed)


# ─────────────────────────────────────────────
# all
# ─────────────────────────────────────────────

def cmd_all(args):
    print("=" * 60)
    print(f"FULL MIGRATION PIPELINE: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    print("\n--- Phase 1: Audit ---")
    cmd_audit(args)

    print("\n--- Phase 2: Secrets ---")
    cmd_secrets(args)

    print("\n--- Phase 3: Packages ---")
    cmd_packages(args)

    print("\n" + "=" * 60)
    print("PIPELINE COMPLETE")
    print("=" * 60)


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def _print_section_summary(label, success, failed):
    print(f"\n{'=' * 60}")
    print(f"{label} SUMMARY  OK: {len(success)}  Failed: {len(failed)}")
    if failed:
        print("\nFailed:")
        for item, msg in failed:
            print(f"  [FAIL] {item}: {msg}")
    print("=" * 60)


# ─────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────

COMMANDS = {
    "audit":    cmd_audit,
    "secrets":  cmd_secrets,
    "packages": cmd_packages,
    "all":      cmd_all,
}


def build_parser():
    parser = argparse.ArgumentParser(
        prog="main.py",
        description="GitHub org migration orchestrator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python main.py --config config.yml all\n"
            "  python main.py --config config.yml audit\n"
            "  python main.py --config config.yml all --dry-run\n"
            "  python main.py --config config.yml all --filter-repo my-repo\n"
        ),
    )
    parser.add_argument(
        "--config", default="config.yml",
        help="Path to config YAML file (default: config.yml)",
    )
    parser.add_argument(
        "command",
        choices=list(COMMANDS.keys()),
        help="Subcommand to run",
    )
    add_common_args(parser)
    parser.add_argument("--skip-cleanup", action="store_true", default=False,
                        help="Do not remove importer workflows after secrets restore")
    parser.add_argument("--filter-package", default=None,
                        help="Restrict package migration to a specific package name")
    return parser


def main():
    parser = build_parser()
    cli_args = parser.parse_args()

    if not os.path.isfile(cli_args.config):
        print(f"ERROR: Config file not found: {cli_args.config}", file=sys.stderr)
        print("Copy config.example.yml to config.yml and fill in your values.", file=sys.stderr)
        sys.exit(1)

    cfg = load_config(cli_args.config)
    validate_config(cfg, cli_args.command)
    args = merge_args(cfg, cli_args)

    print(f"Config : {cli_args.config}")
    print(f"Command: {cli_args.command}")
    if args.dry_run:
        print("Mode   : DRY RUN")
    print()

    COMMANDS[cli_args.command](args)


if __name__ == "__main__":
    main()
