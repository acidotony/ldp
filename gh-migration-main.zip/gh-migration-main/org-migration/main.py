#!/usr/bin/env python3
"""
main.py — Migration orchestrator for org-migration toolkit.

Subcommands:
  audit       Scan source org and report what needs to be migrated
  secrets     Full secrets pipeline (list -> CyberArk import -> restore to dest)
  packages    Migrate all packages (containers + ecosystems)
  webhooks    Migrate repo-level webhooks
  variables   Migrate repo-level Actions variables
  github-apps Grant migrated repos access to matching GitHub App installations
  deploy-keys Regenerate repo-level deploy keys on the destination org
  environments Migrate repo-level deployment environments
  autolinks   Migrate repo-level autolink references
  pages       Migrate GitHub Pages configuration
  org-level   Report org-level settings needing manual migration (apps, OAuth restrictions, IP allow list, audit log)
  security    Report code scanning alerts and verify security policy (SECURITY.md) migration
  projects    Migrate GitHub Projects v2 (shell, fields, items) via GraphQL - best effort, views/workflows not migrated
  branch-protection Migrate legacy branch protection rules (required checks, reviews, restrictions)
  all         Run the full pipeline in order (secrets, packages, webhooks, variables, github-apps, deploy-keys, environments, autolinks, pages)

Usage:
  # Recommended — config file drives everything
  python main.py --config config.yml all

  # Or with individual subcommands
  python main.py --config config.yml audit
  python main.py --config config.yml secrets
  python main.py --config config.yml packages

  # CLI flags still work and override config file values
  python main.py --config config.yml all --dry-run --filter-repo my-repo

Copy config.example.yml to config.yml and fill in the values before running.
Sensitive values can also be set via env vars: SOURCE_TOKEN, DEST_TOKEN, CYBERARK_PASSWORD
"""

import argparse
import sys
import os

# Add org-migration dir to path so packages/ and secrets/ are importable
sys.path.insert(0, os.path.dirname(__file__))

from packages import (
    list_packages,
    migrate_container_packages,
    migrate_ecosystem_packages,
)
from secrets import (
    list_repos_with_secrets,
    deploy_cyberark_importer,
    restore_from_cyberark,
)
from webhooks import (
    list_repos_with_webhooks,
    migrate_repo_webhooks,
)
from variables import (
    list_repos_with_variables,
    migrate_repo_variables,
)
from github_apps import (
    list_repos_with_github_apps,
    migrate_repo_github_apps,
)
from deploy_keys import (
    list_repos_with_deploy_keys,
    migrate_repo_deploy_keys,
)
from environments import (
    list_repos_with_environments,
    migrate_repo_environments,
)
from autolink_references import (
    list_repos_with_autolinks,
    migrate_repo_autolinks,
)
from github_pages import (
    list_repos_with_pages,
    migrate_repo_pages,
)
from org_level import (
    list_org_level_settings,
    migrate_ip_allowlist,
    export_audit_log_history,
)
from security import (
    list_repos_with_code_scanning_alerts,
    list_repos_with_security_policy,
)
from projects import (
    list_org_projects_v2,
    migrate_org_projects,
)
from branch_protection import (
    list_repos_with_branch_protection,
    migrate_repo_branch_protection,
)


# ─────────────────────────────────────────────
# Config file loader
# ─────────────────────────────────────────────

def load_config(path):
    """Load YAML config file. Returns flat namespace dict."""
    try:
        import yaml
    except ImportError:
        print("ERROR: 'pyyaml' is required for config file support. Run: pip install -r requirements.txt",
              file=sys.stderr)
        sys.exit(1)

    with open(path) as f:
        cfg = yaml.safe_load(f)

    src  = cfg.get("source", {})
    dst  = cfg.get("dest", {})
    ca   = cfg.get("cyberark", {})
    pkgs = cfg.get("packages", {})
    whooks = cfg.get("webhooks", {})
    ghapps = cfg.get("github_apps", {})
    dkeys = cfg.get("deploy_keys", {})
    opts = cfg.get("options", {})

    # Sensitive values come exclusively from environment variables
    source_token    = os.environ.get("SOURCE_TOKEN", "")
    dest_token      = os.environ.get("DEST_TOKEN", "")
    cyberark_pass   = os.environ.get("CYBERARK_PASSWORD", "")

    return {
        "source_org":         src.get("org", ""),
        "source_token":       source_token,
        "source_api_url":     src.get("api_url", "https://api.github.com"),
        "dest_org":           dst.get("org", ""),
        "dest_token":         dest_token,
        "dest_api_url":       dst.get("api_url", "https://api.github.com"),
        "cyberark_url":       ca.get("url", ""),
        "cyberark_username":  ca.get("username", ""),
        "cyberark_password":  cyberark_pass,
        "cyberark_safe":      ca.get("safe", ""),
        "registry":           pkgs.get("registry", "ghcr.io"),
        "package_type":       pkgs.get("package_type", "all"),
        "work_dir":           pkgs.get("work_dir"),
        "default_webhook_secret": whooks.get("default_secret"),
        "skip_inactive_webhooks": whooks.get("skip_inactive", False),
        "repo_list":          ghapps.get("repo_list", "migration_successes.txt"),
        "deploy_keys_output_dir": dkeys.get("output_dir"),
        "dry_run":            opts.get("dry_run", False),
        "include_archived":   opts.get("include_archived", False),
        "concurrency":        opts.get("concurrency", 10),
        "filter_repo":        opts.get("filter_repo"),
        "filter_package":     opts.get("filter_package"),
        "skip_cleanup":       opts.get("skip_cleanup", False),
        "skip_secrets":       opts.get("skip_secrets", False),
        "skip_packages":      opts.get("skip_packages", False),
        "skip_webhooks":      opts.get("skip_webhooks", False),
        "skip_variables":     opts.get("skip_variables", False),
        "skip_github_apps":   opts.get("skip_github_apps", False),
        "skip_deploy_keys":   opts.get("skip_deploy_keys", False),
        "skip_environments":  opts.get("skip_environments", False),
        "skip_autolinks":     opts.get("skip_autolinks", False),
        "skip_pages":         opts.get("skip_pages", False),
        "skip_branch_protection": opts.get("skip_branch_protection", False),
    }


def validate_config(cfg, command):
    """Check required fields are set for the given command.

    For the 'all' command, the secrets and packages phases can each be
    skipped via skip_secrets/skip_packages, in which case their required
    fields are not enforced.
    """
    errors = []

    needs_secrets = command == "secrets" or (command == "all" and not cfg.get("skip_secrets"))
    needs_packages = command == "packages" or (command == "all" and not cfg.get("skip_packages"))
    needs_webhooks = command == "webhooks" or (command == "all" and not cfg.get("skip_webhooks"))
    needs_variables = command == "variables" or (command == "all" and not cfg.get("skip_variables"))
    needs_github_apps = command == "github-apps" or (command == "all" and not cfg.get("skip_github_apps"))
    needs_deploy_keys = command == "deploy-keys" or (command == "all" and not cfg.get("skip_deploy_keys"))
    needs_environments = command == "environments" or (command == "all" and not cfg.get("skip_environments"))
    needs_autolinks = command == "autolinks" or (command == "all" and not cfg.get("skip_autolinks"))
    needs_pages = command == "pages" or (command == "all" and not cfg.get("skip_pages"))
    needs_branch_protection = command == "branch-protection" or (command == "all" and not cfg.get("skip_branch_protection"))
    needs_dest = (
        command == "packages" or needs_secrets or needs_packages
        or needs_webhooks or needs_variables or needs_github_apps or needs_deploy_keys
        or needs_environments or needs_autolinks or needs_pages or needs_branch_protection
    )

    if not cfg.get("source_org"):
        errors.append("  config.yml: source.org is not set")
    if not cfg.get("source_token"):
        errors.append("  env var SOURCE_TOKEN is not set")

    if needs_dest:
        if not cfg.get("dest_org"):
            errors.append("  config.yml: dest.org is not set")
        if not cfg.get("dest_token"):
            errors.append("  env var DEST_TOKEN is not set")

    if needs_secrets:
        if not cfg.get("cyberark_url"):
            errors.append("  config.yml: cyberark.url is not set")
        if not cfg.get("cyberark_username"):
            errors.append("  config.yml: cyberark.username is not set")
        if not cfg.get("cyberark_password"):
            errors.append("  env var CYBERARK_PASSWORD is not set")
        if not cfg.get("cyberark_safe"):
            errors.append("  config.yml: cyberark.safe is not set")

    if errors:
        print("ERROR: Missing required values:", file=sys.stderr)
        for e in errors:
            print(e, file=sys.stderr)
        sys.exit(1)


def merge_args(cfg, cli_args):
    """
    Merge config file values with CLI overrides.
    CLI flags take precedence when explicitly provided.
    Returns a SimpleNamespace usable throughout the app.
    """
    from types import SimpleNamespace

    merged = dict(cfg)

    # CLI flags that override config when set
    overridable = [
        "dry_run", "include_archived", "concurrency",
        "filter_repo", "filter_package", "skip_cleanup",
        "package_type", "registry", "work_dir", "repo_list",
        "deploy_keys_output_dir",
    ]
    for key in overridable:
        cli_val = getattr(cli_args, key, None)
        if cli_val is not None and cli_val is not False:
            merged[key] = cli_val

    # Boolean flags: if set on CLI, always override
    for key in (
        "dry_run", "include_archived", "skip_cleanup",
        "skip_secrets", "skip_packages", "skip_webhooks",
        "skip_variables", "skip_github_apps", "skip_deploy_keys",
        "skip_environments", "skip_autolinks", "skip_pages", "skip_branch_protection",
    ):
        if getattr(cli_args, key, False):
            merged[key] = True

    return SimpleNamespace(**merged)


# ─────────────────────────────────────────────
# Shared argument groups
# ─────────────────────────────────────────────

def add_common_args(p):
    p.add_argument("--dry-run", action="store_true", default=False,
                   help="Simulate without making changes (overrides config)")
    p.add_argument("--concurrency", type=int, default=None,
                   help="Parallel operations (overrides config)")
    p.add_argument("--include-archived", action="store_true", default=False,
                   help="Include archived repos (overrides config)")
    p.add_argument("--filter-repo", default=None,
                   help="Restrict to a single repo (overrides config)")
    p.add_argument("--filter-project", default=None,
                   help="Restrict 'projects' command to a single project number")


# ─────────────────────────────────────────────
# audit
# ─────────────────────────────────────────────

def cmd_audit(args):
    print("=" * 60)
    print(f"AUDIT: {args.source_org}")
    print("=" * 60)

    # Secrets
    print("\n[1/10] Scanning for secrets...")
    repos_with_secrets = list_repos_with_secrets(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived, args.concurrency,
    )
    total_secrets = sum(r["secret_count"] for r in repos_with_secrets)
    print(f"      Repos with secrets : {len(repos_with_secrets)}")
    print(f"      Total secrets      : {total_secrets}")

    # Packages
    print("\n[2/10] Scanning for packages...")
    pkgs = list_packages(args.source_api_url, args.source_org, args.source_token,
                         filter_repo=args.filter_repo)
    by_type = {}
    for p in pkgs:
        by_type.setdefault(p["package_type"], 0)
        by_type[p["package_type"]] += 1
    print(f"      Total packages     : {len(pkgs)}")
    for ptype, count in sorted(by_type.items()):
        print(f"        {ptype:<14}: {count}")

    # Webhooks
    print("\n[3/10] Scanning for repo webhooks...")
    repos_with_webhooks = list_repos_with_webhooks(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived, args.concurrency,
    )
    total_webhooks = sum(r["webhook_count"] for r in repos_with_webhooks)
    print(f"      Repos with webhooks : {len(repos_with_webhooks)}")
    print(f"      Total webhooks      : {total_webhooks}")

    # Variables
    print("\n[4/10] Scanning for repo Actions variables...")
    repos_with_variables = list_repos_with_variables(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived, args.concurrency,
    )
    total_variables = sum(r["variable_count"] for r in repos_with_variables)
    print(f"      Repos with variables : {len(repos_with_variables)}")
    print(f"      Total variables      : {total_variables}")

    # GitHub Apps
    print("\n[5/10] Scanning for GitHub App installations...")
    repo_app_map = list_repos_with_github_apps(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived,
    )
    repos_with_apps = {repo: apps for repo, apps in repo_app_map.items() if apps}
    total_app_links = sum(len(apps) for apps in repos_with_apps.values())
    print(f"      Repos with GitHub Apps : {len(repos_with_apps)}")
    print(f"      Total app link(s)      : {total_app_links}")

    # Deploy keys
    print("\n[6/10] Scanning for repo deploy keys...")
    repos_with_deploy_keys = list_repos_with_deploy_keys(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived,
    )
    total_deploy_keys = sum(r["deploy_key_count"] for r in repos_with_deploy_keys)
    print(f"      Repos with deploy keys : {len(repos_with_deploy_keys)}")
    print(f"      Total deploy keys      : {total_deploy_keys}")

    # Environments
    print("\n[7/10] Scanning for deployment environments...")
    repos_with_environments = list_repos_with_environments(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived, args.concurrency,
    )
    total_environments = sum(r["environment_count"] for r in repos_with_environments)
    print(f"      Repos with environments : {len(repos_with_environments)}")
    print(f"      Total environments      : {total_environments}")

    # Autolink references
    print("\n[8/10] Scanning for autolink references...")
    repos_with_autolinks = list_repos_with_autolinks(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived, args.concurrency,
    )
    total_autolinks = sum(r["autolink_count"] for r in repos_with_autolinks)
    print(f"      Repos with autolinks : {len(repos_with_autolinks)}")
    print(f"      Total autolinks      : {total_autolinks}")

    # GitHub Pages
    print("\n[9/10] Scanning for GitHub Pages configuration...")
    repos_with_pages = list_repos_with_pages(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived, args.concurrency,
    )
    print(f"      Repos with Pages enabled : {len(repos_with_pages)}")

    # Branch protection (legacy)
    print("\n[10/10] Scanning for legacy branch protection rules...")
    repos_with_branch_protection = list_repos_with_branch_protection(
        args.source_api_url, args.source_org, args.source_token,
        args.include_archived, args.concurrency,
    )
    total_protected_branches = sum(r["branch_count"] for r in repos_with_branch_protection)
    print(f"      Repos with branch protection : {len(repos_with_branch_protection)}")
    print(f"      Total protected branches     : {total_protected_branches}")

    # Org-level settings (manual follow-up items)
    print("\n[org-level] Scanning org-level settings requiring manual migration...")
    org_level_report = list_org_level_settings(args.source_api_url, args.source_org, args.source_token)
    print(f"      GitHub App installations on org : {len(org_level_report['app_installations'])}")
    print("      NOTE: OAuth app access restrictions, IP allow list, and audit log history")
    print("            have no REST API support for full migration - see 'org-level' command.")

    # Security (audit-only)
    print("\n[security] Scanning for code scanning alerts and security policies...")
    repos_with_alerts = list_repos_with_code_scanning_alerts(
        args.source_api_url, args.source_org, args.source_token,
        args.concurrency, args.include_archived,
    )
    repos_with_policy = list_repos_with_security_policy(
        args.source_api_url, args.source_org, args.source_token,
        args.concurrency, args.include_archived,
    )
    total_open_alerts = sum(r["open_alert_count"] for r in repos_with_alerts)
    print(f"      Repos with open code scanning alerts : {len(repos_with_alerts)} ({total_open_alerts} total open alerts)")
    print(f"      Repos with a security policy         : {len(repos_with_policy)}")
    print("      NOTE: code scanning alerts cannot be copied via API - see 'security' command.")

    # Projects v2 (best-effort migration available via 'projects' command)
    print("\n[projects] Scanning GitHub Projects v2...")
    org_projects = list_org_projects_v2(args.source_api_url, args.source_org, args.source_token)
    print(f"      Projects v2 found : {len(org_projects)}")
    print("      NOTE: use 'main.py projects' to migrate - views/workflows are not migratable.")
    print("            GitHub Projects (classic) has been sunset by GitHub, nothing to migrate.")

    print("\n" + "=" * 60)
    print("AUDIT SUMMARY")
    print(f"  Repos with secrets     : {len(repos_with_secrets)}")
    print(f"  Total secrets          : {total_secrets}")
    print(f"  Total packages         : {len(pkgs)}")
    print(f"  Repos with webhooks    : {len(repos_with_webhooks)}")
    print(f"  Total webhooks         : {total_webhooks}")
    print(f"  Repos with variables   : {len(repos_with_variables)}")
    print(f"  Total variables        : {total_variables}")
    print(f"  Repos with GitHub Apps : {len(repos_with_apps)}")
    print(f"  Repos with deploy keys : {len(repos_with_deploy_keys)}")
    print(f"  Total deploy keys      : {total_deploy_keys}")
    print(f"  Repos with environments : {len(repos_with_environments)}")
    print(f"  Total environments      : {total_environments}")
    print(f"  Repos with autolinks    : {len(repos_with_autolinks)}")
    print(f"  Total autolinks         : {total_autolinks}")
    print(f"  Repos with Pages enabled : {len(repos_with_pages)}")
    print(f"  Repos with branch protection : {len(repos_with_branch_protection)}")
    print(f"  Total protected branches     : {total_protected_branches}")
    print(f"  GitHub App installations on org : {len(org_level_report['app_installations'])}")
    print(f"  Repos with open code scanning alerts : {len(repos_with_alerts)} ({total_open_alerts} total)")
    print(f"  Repos with a security policy         : {len(repos_with_policy)}")
    print(f"  GitHub Projects v2 found              : {len(org_projects)}")
    print("=" * 60)

    if repos_with_secrets:
        print("\nRepos with secrets:")
        for r in repos_with_secrets:
            print(f"  {r['repo']:<50} {r['secret_count']:>3} secret(s): {', '.join(r['secret_names'])}")


# ─────────────────────────────────────────────
# secrets
# ─────────────────────────────────────────────

def cmd_secrets(args):
    print("=" * 60)
    print(f"SECRETS MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    # ── Step 1: Deploy importer workflows to source repos ─────────────────
    print("\n[1/3] Deploying CyberArk importer workflow to source repos...")
    success, failed = deploy_cyberark_importer(
        org=args.source_org,
        token=args.source_token,
        api_url=args.source_api_url,
        concurrency=args.concurrency,
        dry_run=args.dry_run,
        include_archived=args.include_archived,
    )
    print(f"      Deployed: {len(success)}  Failed: {len(failed)}")
    if failed:
        for repo, msg in failed:
            print(f"      [FAIL] {repo}: {msg}")

    if args.dry_run:
        print("\n[DRY RUN] Skipping steps 2 and 3.")
        return

    # ── Step 2: Trigger importer workflows via gh CLI (no interaction) ────
    print("\n[2/3] Triggering CyberArk importer workflows in all source repos...")
    import subprocess, shutil
    if shutil.which("gh"):
        trigger_cmd = (
            f"gh api /orgs/{args.source_org}/repos --paginate -q '.[].name' | "
            f"xargs -P 5 -I {{}} gh workflow run import-to-cyberark.yml "
            f"--repo {args.source_org}/{{}} "
            f"--field cyberark_safe={args.cyberark_safe}"
        )
        print(f"      Running: {trigger_cmd}")
        result = subprocess.run(trigger_cmd, shell=True)
        if result.returncode != 0:
            print("      WARNING: some workflow triggers may have failed — check GitHub Actions UI",
                  file=sys.stderr)

        # Wait for all workflow runs to complete
        print("      Waiting for all workflow runs to finish...")
        wait_cmd = (
            f"gh api /orgs/{args.source_org}/repos --paginate -q '.[].name' | "
            f"xargs -P 5 -I {{}} sh -c "
            f"'gh run list --repo {args.source_org}/{{}} "
            f"--workflow import-to-cyberark.yml --limit 1 --json status -q \'.[0].status\' | "
            f"grep -q completed || gh run watch --repo {args.source_org}/{{}} "
            f"$(gh run list --repo {args.source_org}/{{}} "
            f"--workflow import-to-cyberark.yml --limit 1 --json databaseId -q \'.[0].databaseId\')'"
        )
        subprocess.run(wait_cmd, shell=True)
        print("      All workflow runs completed.")
    else:
        print("      WARNING: 'gh' CLI not found — skipping automatic workflow trigger.")
        print(f"      Manually trigger 'import-to-cyberark.yml' in all repos of {args.source_org}")
        print(f"      then re-run: python main.py --config <config> secrets")
        sys.exit(1)

    # ── Step 3: Restore from CyberArk to destination ──────────────────────
    print("\n[3/3] Restoring secrets from CyberArk to destination org...")
    results = restore_from_cyberark(
        cyberark_url=args.cyberark_url,
        cyberark_username=args.cyberark_username,
        cyberark_password=args.cyberark_password,
        cyberark_safe=args.cyberark_safe,
        source_org=args.source_org,
        dest_org=args.dest_org,
        dest_token=args.dest_token,
        api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        dry_run=args.dry_run,
    )

    print(f"\n      OK      : {len(results['success'])}")
    print(f"      Failed  : {len(results['failed'])}")
    print(f"      Skipped : {len(results['skipped'])}")

    # ── Cleanup: remove importer workflows ────────────────────────────────
    if not args.skip_cleanup:
        print("\n[cleanup] Removing importer workflows from source repos...")
        deploy_cyberark_importer(
            org=args.source_org,
            token=args.source_token,
            api_url=args.source_api_url,
            concurrency=args.concurrency,
            dry_run=args.dry_run,
            cleanup=True,
        )
        print("      Done.")

    _print_section_summary("SECRETS", results["success"], results["failed"])


# ─────────────────────────────────────────────
# packages
# ─────────────────────────────────────────────

def cmd_packages(args):
    print("=" * 60)
    print(f"PACKAGE MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    all_success, all_failed = [], []

    # ── Containers ────────────────────────────────────────────────────────
    print("\n[1/2] Migrating container images (Podman)...")
    success, failed = migrate_container_packages(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        registry=args.registry,
        filter_repo=args.filter_repo,
        filter_package=args.filter_package,
        concurrency=args.concurrency,
        dry_run=args.dry_run,
    )
    all_success.extend(success)
    all_failed.extend(failed)
    print(f"      OK: {len(success)}  Failed: {len(failed)}")

    # ── Ecosystem packages ────────────────────────────────────────────────
    print("\n[2/2] Migrating ecosystem packages (npm/maven/gradle/nuget/rubygems)...")
    success, failed = migrate_ecosystem_packages(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        package_type=args.package_type,
        filter_package=args.filter_package,
        work_dir=args.work_dir,
        dry_run=args.dry_run,
    )
    all_success.extend(success)
    all_failed.extend(failed)
    print(f"      OK: {len(success)}  Failed: {len(failed)}")

    _print_section_summary("PACKAGES", all_success, all_failed)


# ─────────────────────────────────────────────
# webhooks
# ─────────────────────────────────────────────

def cmd_webhooks(args):
    print("=" * 60)
    print(f"WEBHOOKS MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    results = migrate_repo_webhooks(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        dest_api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        default_secret=getattr(args, "default_webhook_secret", None),
        skip_inactive=getattr(args, "skip_inactive_webhooks", False),
        concurrency=args.concurrency,
        include_archived=args.include_archived,
        dry_run=args.dry_run,
    )

    print(f"\n      OK      : {len(results['success'])}")
    print(f"      Failed  : {len(results['failed'])}")
    print(f"      Skipped : {len(results['skipped'])}")
    if results.get("needs_secret"):
        print(f"      Needs manual secret: {len(results['needs_secret'])}")

    _print_section_summary("WEBHOOKS", results["success"], results["failed"])
    return results


# ─────────────────────────────────────────────
# variables
# ─────────────────────────────────────────────

def cmd_variables(args):
    print("=" * 60)
    print(f"VARIABLES MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    results = migrate_repo_variables(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        dest_api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        concurrency=args.concurrency,
        include_archived=args.include_archived,
        dry_run=args.dry_run,
    )

    print(f"\n      OK      : {len(results['success'])}")
    print(f"      Failed  : {len(results['failed'])}")
    print(f"      Skipped : {len(results['skipped'])}")

    _print_section_summary("VARIABLES", results["success"], results["failed"])
    return results


# ─────────────────────────────────────────────
# github-apps
# ─────────────────────────────────────────────

def cmd_github_apps(args):
    print("=" * 60)
    print(f"GITHUB APPS MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    repo_list = getattr(args, "repo_list", None)
    if repo_list and not os.path.isfile(repo_list):
        print(f"      No repo list found at '{repo_list}' - falling back to all repos in source org")
        repo_list = None

    results = migrate_repo_github_apps(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        dest_api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        repo_list=repo_list,
        include_archived=args.include_archived,
        dry_run=args.dry_run,
    )

    print(f"\n      OK           : {len(results['success'])}")
    print(f"      Failed       : {len(results['failed'])}")
    print(f"      Skipped      : {len(results['skipped'])}")
    print(f"      Missing apps : {len(results['missing_apps'])}")

    _print_section_summary("GITHUB APPS", results["success"], results["failed"])
    return results


# ─────────────────────────────────────────────
# deploy-keys
# ─────────────────────────────────────────────

def cmd_deploy_keys(args):
    print("=" * 60)
    print(f"DEPLOY KEYS MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)
    print("NOTE: private keys cannot be read from the source; new keypairs are")
    print("      generated and must be handed off to whatever system consumed")
    print("      the original key.")

    results = migrate_repo_deploy_keys(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        dest_api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        output_dir=getattr(args, "deploy_keys_output_dir", None),
        cyberark_url=getattr(args, "cyberark_url", None),
        cyberark_username=getattr(args, "cyberark_username", None),
        cyberark_password=getattr(args, "cyberark_password", None),
        cyberark_safe=getattr(args, "cyberark_safe", None),
        include_archived=args.include_archived,
        dry_run=args.dry_run,
    )

    print(f"\n      OK      : {len(results['success'])}")
    print(f"      Failed  : {len(results['failed'])}")
    print(f"      Skipped : {len(results['skipped'])}")

    _print_section_summary("DEPLOY KEYS", results["success"], results["failed"])
    return results


# ─────────────────────────────────────────────
# environments
# ─────────────────────────────────────────────

def cmd_environments(args):
    print("=" * 60)
    print(f"ENVIRONMENTS MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    results = migrate_repo_environments(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        dest_api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        concurrency=args.concurrency,
        include_archived=args.include_archived,
        dry_run=args.dry_run,
    )

    print(f"\n      OK      : {len(results['success'])}")
    print(f"      Failed  : {len(results['failed'])}")
    print(f"      Skipped : {len(results['skipped'])}")

    _print_section_summary("ENVIRONMENTS", results["success"], results["failed"])
    return results


# ─────────────────────────────────────────────
# autolinks
# ─────────────────────────────────────────────

def cmd_autolinks(args):
    print("=" * 60)
    print(f"AUTOLINK REFERENCES MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    results = migrate_repo_autolinks(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        dest_api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        concurrency=args.concurrency,
        include_archived=args.include_archived,
        dry_run=args.dry_run,
    )

    print(f"\n      OK      : {len(results['success'])}")
    print(f"      Failed  : {len(results['failed'])}")
    print(f"      Skipped : {len(results['skipped'])}")

    _print_section_summary("AUTOLINK REFERENCES", results["success"], results["failed"])
    return results


# ─────────────────────────────────────────────
# pages
# ─────────────────────────────────────────────

def cmd_pages(args):
    print("=" * 60)
    print(f"GITHUB PAGES MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)
    print("NOTE: only Pages site configuration is copied; DNS records for")
    print("      custom domains must be reconfigured manually.")

    results = migrate_repo_pages(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        dest_api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        concurrency=args.concurrency,
        include_archived=args.include_archived,
        dry_run=args.dry_run,
    )

    print(f"\n      OK      : {len(results['success'])}")
    print(f"      Failed  : {len(results['failed'])}")
    print(f"      Skipped : {len(results['skipped'])}")

    _print_section_summary("GITHUB PAGES", results["success"], results["failed"])
    return results


# ─────────────────────────────────────────────
# branch-protection (legacy)
# ─────────────────────────────────────────────

def cmd_branch_protection(args):
    print("=" * 60)
    print(f"BRANCH PROTECTION MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)
    print("NOTE: targets legacy per-branch protection rules only. Newer")
    print("      repository rulesets are a separate feature and out of scope.")

    results = migrate_repo_branch_protection(
        source_org=args.source_org,
        dest_org=args.dest_org,
        source_token=args.source_token,
        dest_token=args.dest_token,
        api_url=args.source_api_url,
        dest_api_url=args.dest_api_url,
        filter_repo=args.filter_repo,
        concurrency=args.concurrency,
        include_archived=args.include_archived,
        dry_run=args.dry_run,
    )

    print(f"\n      OK      : {len(results['success'])}")
    print(f"      Failed  : {len(results['failed'])}")
    print(f"      Skipped : {len(results['skipped'])}")

    _print_section_summary("BRANCH PROTECTION", results["success"], results["failed"])
    return results


# ─────────────────────────────────────────────
# org-level (audit-only, no automated migration)
# ─────────────────────────────────────────────

def cmd_org_level(args):
    print("=" * 60)
    print(f"ORG-LEVEL SETTINGS: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    report = list_org_level_settings(args.source_api_url, args.source_org, args.source_token)
    installs = report["app_installations"]

    print(f"\n[1/3] GitHub App installations (audit-only - {len(installs)} found)...")
    for inst in installs:
        perms = ",".join(f"{k}:{v}" for k, v in inst["permissions"].items())
        print(f"        - {inst['app_slug']} (id={inst['app_id']}, selection={inst['repository_selection']}, perms={perms})")
    print("      NOTE: no API to install an app - re-install manually via each app's consent page.")

    print("\n[2/3] IP allow list entries (migrating via GraphQL)...")
    allowlist_results = migrate_ip_allowlist(
        source_api_url=args.source_api_url, source_org=args.source_org, source_token=args.source_token,
        dest_api_url=args.dest_api_url, dest_org=args.dest_org, dest_token=args.dest_token,
        dry_run=args.dry_run,
    )
    print(f"      OK: {len(allowlist_results['success'])}  Failed: {len(allowlist_results['failed'])}")
    if allowlist_results["failed"]:
        print("      NOTE: failures usually mean the org is not on GitHub Enterprise Cloud, or")
        print("            the token lacks admin:org scope. Recreate remaining entries manually.")

    print("\n[3/3] Audit log history (read-only export, cannot be migrated)...")
    audit_events = export_audit_log_history(args.source_api_url, args.source_org, args.source_token)
    print(f"      Exported {len(audit_events)} event(s) to audit_log_export.json")
    print("      NOTE: GitHub generates audit log entries organically - there is no API")
    print("            to write historical entries into the destination org's log. This")
    print("            export is for archival/compliance purposes only.")

    print("\n" + "=" * 60)
    print("MANUAL FOLLOW-UP STILL REQUIRED:")
    print("  - OAuth App access restrictions (Settings > Third-party access)")
    print("    NOTE: GitHub has no REST or GraphQL API for this setting at all.")
    print("    The only way to automate it would be browser automation against the")
    print("    web UI, which we deliberately did NOT build into this toolkit: it")
    print("    would require storing authenticated session credentials, violates")
    print("    GitHub's Terms of Service on automated access, and breaks silently")
    print("    on any UI change. Recreate this setting manually (a few clicks).")
    print("=" * 60)

    return {
        "app_installations": installs,
        "ip_allowlist": allowlist_results,
        "audit_log_event_count": len(audit_events),
    }



# ─────────────────────────────────────────────
# security (audit-only, no automated migration)
# ─────────────────────────────────────────────

def cmd_security(args):
    print("=" * 60)
    print(f"SECURITY AUDIT: {args.source_org}")
    print("=" * 60)
    print("NOTE: code scanning alerts cannot be copied via API - re-enable scanning")
    print("      on the destination and compare against this report. Security policy")
    print("      files (SECURITY.md) are ordinary repo content already copied by GEI;")
    print("      this only verifies presence on both orgs.")

    print("\n[1/2] Code scanning alerts (source org)...")
    repos_with_alerts = list_repos_with_code_scanning_alerts(
        args.source_api_url, args.source_org, args.source_token,
        args.concurrency, args.include_archived,
    )
    total_open_alerts = sum(r["open_alert_count"] for r in repos_with_alerts)
    print(f"      Repos with open alerts : {len(repos_with_alerts)} ({total_open_alerts} total open alerts)")
    for r in repos_with_alerts:
        print(f"        - {r['repo']}: {r['open_alert_count']} open ({r['by_severity']})")

    print("\n[2/2] Security policy (SECURITY.md) presence...")
    source_policy_repos = set(list_repos_with_security_policy(
        args.source_api_url, args.source_org, args.source_token,
        args.concurrency, args.include_archived,
    ))
    print(f"      Repos with a security policy on source : {len(source_policy_repos)}")

    if getattr(args, "dest_org", None) and getattr(args, "dest_token", None):
        dest_policy_repos = set(list_repos_with_security_policy(
            args.dest_api_url, args.dest_org, args.dest_token,
            args.concurrency, args.include_archived,
        ))
        missing = sorted(source_policy_repos - dest_policy_repos)
        if missing:
            print(f"      WARNING: {len(missing)} repo(s) missing SECURITY.md on destination:")
            for repo in missing:
                print(f"        - {repo}")
        else:
            print("      All source security policies verified present on destination.")

    return {
        "repos_with_alerts": repos_with_alerts,
        "repos_with_security_policy": sorted(source_policy_repos),
    }


# ─────────────────────────────────────────────
# projects (GitHub Projects v2 via GraphQL - best effort)
# ─────────────────────────────────────────────

def cmd_projects(args):
    print("=" * 60)
    print(f"PROJECTS (v2) MIGRATION: {args.source_org} -> {args.dest_org}")
    print("=" * 60)
    print("NOTE: best-effort migration via GraphQL. Views, workflows/automations,")
    print("      and item sort order have no public API and must be recreated")
    print("      manually. Destination repos must already be migrated so that")
    print("      issue/PR numbers match (relied on to re-link project items).")
    print("      GitHub Projects (classic) has been sunset by GitHub - nothing")
    print("      to migrate for that feature.")

    results = migrate_org_projects(
        source_api_url=args.source_api_url, source_org=args.source_org, source_token=args.source_token,
        dest_api_url=args.dest_api_url, dest_org=args.dest_org, dest_token=args.dest_token,
        filter_project=getattr(args, "filter_project", None),
        dry_run=args.dry_run,
    )

    _print_section_summary("PROJECTS V2", results["success"], results["failed"])
    return results


# ─────────────────────────────────────────────
# all
# ─────────────────────────────────────────────

def cmd_all(args):
    print("=" * 60)
    print(f"FULL MIGRATION PIPELINE: {args.source_org} -> {args.dest_org}")
    print("=" * 60)

    print("\n--- Phase 1: Audit ---")
    cmd_audit(args)

    if getattr(args, "skip_secrets", False):
        print("\n--- Phase 2: Secrets (skipped via skip_secrets) ---")
    else:
        print("\n--- Phase 2: Secrets ---")
        cmd_secrets(args)

    if getattr(args, "skip_packages", False):
        print("\n--- Phase 3: Packages (skipped via skip_packages) ---")
    else:
        print("\n--- Phase 3: Packages ---")
        cmd_packages(args)

    if getattr(args, "skip_webhooks", False):
        print("\n--- Phase 4: Webhooks (skipped via skip_webhooks) ---")
    else:
        print("\n--- Phase 4: Webhooks ---")
        cmd_webhooks(args)

    if getattr(args, "skip_variables", False):
        print("\n--- Phase 5: Variables (skipped via skip_variables) ---")
    else:
        print("\n--- Phase 5: Variables ---")
        cmd_variables(args)

    if getattr(args, "skip_github_apps", False):
        print("\n--- Phase 6: GitHub Apps (skipped via skip_github_apps) ---")
    else:
        print("\n--- Phase 6: GitHub Apps ---")
        cmd_github_apps(args)

    if getattr(args, "skip_deploy_keys", False):
        print("\n--- Phase 7: Deploy Keys (skipped via skip_deploy_keys) ---")
    else:
        print("\n--- Phase 7: Deploy Keys ---")
        cmd_deploy_keys(args)

    if getattr(args, "skip_environments", False):
        print("\n--- Phase 8: Environments (skipped via skip_environments) ---")
    else:
        print("\n--- Phase 8: Environments ---")
        cmd_environments(args)

    if getattr(args, "skip_autolinks", False):
        print("\n--- Phase 9: Autolink References (skipped via skip_autolinks) ---")
    else:
        print("\n--- Phase 9: Autolink References ---")
        cmd_autolinks(args)

    if getattr(args, "skip_pages", False):
        print("\n--- Phase 10: GitHub Pages (skipped via skip_pages) ---")
    else:
        print("\n--- Phase 10: GitHub Pages ---")
        cmd_pages(args)

    if getattr(args, "skip_branch_protection", False):
        print("\n--- Phase 11: Branch Protection (skipped via skip_branch_protection) ---")
    else:
        print("\n--- Phase 11: Branch Protection ---")
        cmd_branch_protection(args)

    print("\n" + "=" * 60)
    print("PIPELINE COMPLETE")
    print("=" * 60)


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def _print_section_summary(label, success, failed):
    print(f"\n{'=' * 60}")
    print(f"{label} SUMMARY  OK: {len(success)}  Failed: {len(failed)}")
    if failed:
        print("\nFailed:")
        for item, msg in failed:
            print(f"  [FAIL] {item}: {msg}")
    print("=" * 60)


# ─────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────

COMMANDS = {
    "audit":        cmd_audit,
    "secrets":      cmd_secrets,
    "packages":     cmd_packages,
    "webhooks":     cmd_webhooks,
    "variables":    cmd_variables,
    "github-apps":  cmd_github_apps,
    "deploy-keys":  cmd_deploy_keys,
    "environments": cmd_environments,
    "autolinks":    cmd_autolinks,
    "pages":        cmd_pages,
    "branch-protection": cmd_branch_protection,
    "org-level":    cmd_org_level,
    "security":     cmd_security,
    "projects":     cmd_projects,
    "all":          cmd_all,
}


def build_parser():
    parser = argparse.ArgumentParser(
        prog="main.py",
        description="GitHub org migration orchestrator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python main.py --config config.yml all\n"
            "  python main.py --config config.yml audit\n"
            "  python main.py --config config.yml all --dry-run\n"
            "  python main.py --config config.yml all --filter-repo my-repo\n"
        ),
    )
    parser.add_argument(
        "--config", default="config.yml",
        help="Path to config YAML file (default: config.yml)",
    )
    parser.add_argument(
        "command",
        choices=list(COMMANDS.keys()),
        help="Subcommand to run",
    )
    add_common_args(parser)
    parser.add_argument("--skip-cleanup", action="store_true", default=False,
                        help="Do not remove importer workflows after secrets restore")
    parser.add_argument("--filter-package", default=None,
                        help="Restrict package migration to a specific package name")
    parser.add_argument("--repo-list", default=None,
                        help="Path to a repo list file for github-apps (format: 'src_repo dest_repo ...' per line; overrides config)")
    parser.add_argument("--skip-secrets", action="store_true", default=False,
                        help="Skip the secrets phase when running the 'all' command (overrides config)")
    parser.add_argument("--skip-packages", action="store_true", default=False,
                        help="Skip the packages phase when running the 'all' command (overrides config)")
    parser.add_argument("--skip-webhooks", action="store_true", default=False,
                        help="Skip the webhooks phase when running the 'all' command (overrides config)")
    parser.add_argument("--skip-variables", action="store_true", default=False,
                        help="Skip the variables phase when running the 'all' command (overrides config)")
    parser.add_argument("--skip-github-apps", action="store_true", default=False,
                        help="Skip the github-apps phase when running the 'all' command (overrides config)")
    parser.add_argument("--deploy-keys-output-dir", default=None,
                        help="Directory to write regenerated deploy key private keys (overrides config)")
    parser.add_argument("--skip-deploy-keys", action="store_true", default=False,
                        help="Skip the deploy-keys phase when running the 'all' command (overrides config)")
    parser.add_argument("--skip-environments", action="store_true", default=False,
                        help="Skip the environments phase when running the 'all' command (overrides config)")
    parser.add_argument("--skip-autolinks", action="store_true", default=False,
                        help="Skip the autolinks phase when running the 'all' command (overrides config)")
    parser.add_argument("--skip-pages", action="store_true", default=False,
                        help="Skip the GitHub Pages phase when running the 'all' command (overrides config)")
    parser.add_argument("--skip-branch-protection", action="store_true", default=False,
                        help="Skip the branch-protection phase when running the 'all' command (overrides config)")
    return parser


def main():
    parser = build_parser()
    cli_args = parser.parse_args()

    if not os.path.isfile(cli_args.config):
        print(f"ERROR: Config file not found: {cli_args.config}", file=sys.stderr)
        print("Copy config.example.yml to config.yml and fill in your values.", file=sys.stderr)
        sys.exit(1)

    cfg = load_config(cli_args.config)
    args = merge_args(cfg, cli_args)
    validate_config(vars(args), cli_args.command)

    print(f"Config : {cli_args.config}")
    print(f"Command: {cli_args.command}")
    if args.dry_run:
        print("Mode   : DRY RUN")
    print()

    COMMANDS[cli_args.command](args)


if __name__ == "__main__":
    main()
