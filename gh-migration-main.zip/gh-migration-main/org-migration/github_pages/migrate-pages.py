#!/usr/bin/env python3
"""
Migrates GitHub Pages configuration from a source org to a destination org.

Copies, per repo:
    - build_type (legacy branch-based build, or "workflow" for Actions-based)
    - source branch + path (for legacy build_type)
    - custom domain (CNAME) and HTTPS enforcement flag

NOTE: Pages content itself lives in the repo's branch/workflow artifacts and
is migrated along with the repo by GEI — this script only recreates the
Pages *site configuration* so the destination repo starts serving Pages the
same way the source did. DNS records for custom domains are NOT touched.

Requirements:
    pip install requests

Usage:
    python migrate-pages.py \
        --source-org <SOURCE_ORG> \
        --source-token <SOURCE_TOKEN> \
        --dest-org <DEST_ORG> \
        --dest-token <DEST_TOKEN> \
        [--api-url <SOURCE_API_URL>] \
        [--dest-api-url <DEST_API_URL>] \
        [--filter-repo <REPO>] \
        [--concurrency <N>] \
        [--include-archived] \
        [--dry-run]
"""

import argparse
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_request(method, url, token, body=None):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    resp = requests.request(method, url, headers=headers, json=body)
    try:
        data = resp.json() if resp.content else {}
    except ValueError:
        data = {}
    return resp.status_code, data


def gh_paginate(url, token):
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        status, data = gh_request("GET", f"{url}{sep}per_page=100&page={page}", token)
        if status in (403, 404):
            return results
        if status != 200:
            msg = data.get("message", "") if isinstance(data, dict) else ""
            print(f"  Warning: GET {url} -> HTTP {status}: {msg}", file=sys.stderr)
            return results
        if not isinstance(data, list) or not data:
            return results
        results.extend(data)
        if len(data) < 100:
            return results
        page += 1


def get_all_repos(org, token, api_url, include_archived=False):
    repos = gh_paginate(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_repo_pages_config(org, repo, token, api_url):
    """Return Pages config dict for a repo, or None if Pages is not enabled."""
    status, data = gh_request("GET", f"{api_url}/repos/{org}/{repo}/pages", token)
    if status != 200:
        return None
    return {
        "build_type": data.get("build_type", "legacy"),
        "source_branch": (data.get("source") or {}).get("branch", ""),
        "source_path": (data.get("source") or {}).get("path", "/"),
        "cname": data.get("cname"),
        "https_enforced": data.get("https_enforced", False),
    }


def enable_pages(org, repo, token, api_url, config):
    """Create the Pages site on the destination repo. Returns (ok, msg)."""
    body = {"build_type": config["build_type"]}
    if config["build_type"] == "legacy" and config["source_branch"]:
        body["source"] = {"branch": config["source_branch"], "path": config["source_path"] or "/"}

    status, data = gh_request("POST", f"{api_url}/repos/{org}/{repo}/pages", token, body)
    ok = status == 201
    msg = data.get("message", "") if isinstance(data, dict) else ""
    return ok, msg


def update_pages(org, repo, token, api_url, config):
    """Update an existing Pages site (e.g. to set CNAME / https_enforced). Returns (ok, msg)."""
    body = {}
    if config["build_type"] == "legacy" and config["source_branch"]:
        body["source"] = {"branch": config["source_branch"], "path": config["source_path"] or "/"}
    if config["cname"]:
        body["cname"] = config["cname"]
    body["https_enforced"] = config["https_enforced"]

    if not body:
        return True, "nothing to update"
    status, data = gh_request("PUT", f"{api_url}/repos/{org}/{repo}/pages", token, body)
    ok = status == 204
    msg = data.get("message", "") if isinstance(data, dict) else ""
    return ok, msg


def pages_exists(org, repo, token, api_url):
    status, _ = gh_request("GET", f"{api_url}/repos/{org}/{repo}/pages", token)
    return status == 200


# ─────────────────────────────────────────────
# Migration
# ─────────────────────────────────────────────

def migrate_repo_pages(
    source_org, dest_org, repo, source_token, dest_token,
    source_api_url="https://api.github.com", dest_api_url="https://api.github.com",
    dry_run=False,
):
    """
    Copy GitHub Pages configuration for a single repo from source to dest.
    Returns (ok, msg) or None if source repo has no Pages configured.
    """
    config = get_repo_pages_config(source_org, repo, source_token, source_api_url)
    if not config:
        return None

    if dry_run:
        return True, f"dry-run: would configure Pages ({config['build_type']}, branch={config['source_branch']})"

    if pages_exists(dest_org, repo, dest_token, dest_api_url):
        ok, msg = update_pages(dest_org, repo, dest_token, dest_api_url, config)
        return ok, (msg or "updated existing Pages config")

    ok, msg = enable_pages(dest_org, repo, dest_token, dest_api_url, config)
    if not ok:
        return False, msg or "failed to enable Pages"

    # CNAME / https_enforced can only be set via a follow-up PUT
    if config["cname"] or config["https_enforced"]:
        ok2, msg2 = update_pages(dest_org, repo, dest_token, dest_api_url, config)
        if not ok2:
            return False, f"Pages enabled but CNAME/https_enforced update failed: {msg2}"

    note = "enabled"
    if config["cname"]:
        note += f" (CNAME={config['cname']} - verify DNS on destination)"
    return True, note


def migrate_all(args):
    """
    Migrate GitHub Pages configuration for every repo in the source org (or a
    single repo if args.filter_repo is set).
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    source_api_url = args.api_url.rstrip("/")
    dest_api_url = args.dest_api_url.rstrip("/")

    if args.filter_repo:
        repos = [args.filter_repo]
    else:
        repos = get_all_repos(args.source_org, args.source_token, source_api_url, args.include_archived)

    print(f"Migrating GitHub Pages configuration for {len(repos)} repo(s): "
          f"{args.source_org} -> {args.dest_org}")

    success, failed, skipped = [], [], []

    def _process(repo):
        result = migrate_repo_pages(
            args.source_org, args.dest_org, repo,
            args.source_token, args.dest_token,
            source_api_url, dest_api_url, args.dry_run,
        )
        return repo, result

    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {executor.submit(_process, repo): repo for repo in repos}
        for future in as_completed(futures):
            repo, result = future.result()
            if result is None:
                skipped.append(repo)
                print(f"  [skip] {repo}: Pages not enabled on source")
                continue
            ok, msg = result
            if ok:
                success.append((repo, msg))
                print(f"  [ok]   {repo}: {msg}")
            else:
                failed.append((repo, msg))
                print(f"  [FAIL] {repo}: {msg}")

    return {"success": success, "failed": failed, "skipped": skipped}


def build_parser():
    parser = argparse.ArgumentParser(description="Migrate GitHub Pages configuration between GitHub orgs")
    parser.add_argument("--source-org", required=True)
    parser.add_argument("--source-token", required=True)
    parser.add_argument("--dest-org", required=True)
    parser.add_argument("--dest-token", required=True)
    parser.add_argument("--api-url", default="https://api.github.com")
    parser.add_argument("--dest-api-url", default="https://api.github.com")
    parser.add_argument("--filter-repo", default=None)
    parser.add_argument("--concurrency", type=int, default=10)
    parser.add_argument("--include-archived", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    migrate_all(args)


if __name__ == "__main__":
    main()
