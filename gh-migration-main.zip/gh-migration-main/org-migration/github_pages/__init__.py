"""
github_pages — Repo-level GitHub Pages configuration migration utilities.

Recreates the Pages *site configuration* (build type, source branch/path,
custom domain, HTTPS enforcement) on the destination repo. Pages content
itself is migrated with the repo by GEI; DNS records for custom domains are
NOT touched by this module.

Exposed functions:
    list_repos_with_pages(api_url, org, token, include_archived, concurrency) -> list[dict]
    migrate_repo_pages(args) -> dict {success, failed, skipped}
"""

import importlib.util
import pathlib
from types import SimpleNamespace

_HERE = pathlib.Path(__file__).parent


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, _HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def list_repos_with_pages(
    api_url, org, token, include_archived=False, concurrency=10
):
    """
    Scan all repos in an org and return those that have GitHub Pages enabled.
    Returns list of dicts: {repo, build_type, source_branch, cname}
    """
    mod = _load("list-repos-with-pages.py")
    repos = mod.get_all_repos(org, token, api_url, include_archived)

    import concurrent.futures
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as ex:
        futures = {
            ex.submit(mod.get_repo_pages_config, org, repo, token, api_url): repo
            for repo in repos
        }
        for future in concurrent.futures.as_completed(futures):
            repo_name, has_pages, config = future.result()
            if has_pages:
                results.append({
                    "repo": repo_name,
                    "build_type": config["build_type"],
                    "source_branch": config["source_branch"],
                    "cname": config["cname"],
                })

    results.sort(key=lambda r: r["repo"])
    return results


def migrate_repo_pages(
    source_org, dest_org, source_token, dest_token,
    api_url="https://api.github.com", dest_api_url="https://api.github.com",
    filter_repo=None, concurrency=10, include_archived=False, dry_run=False,
):
    """
    Migrate GitHub Pages configuration from source org to destination org.
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    mod = _load("migrate-pages.py")

    args = SimpleNamespace(
        source_org=source_org,
        dest_org=dest_org,
        source_token=source_token,
        dest_token=dest_token,
        api_url=api_url,
        dest_api_url=dest_api_url,
        filter_repo=filter_repo,
        concurrency=concurrency,
        include_archived=include_archived,
        dry_run=dry_run,
    )

    return mod.migrate_all(args)
