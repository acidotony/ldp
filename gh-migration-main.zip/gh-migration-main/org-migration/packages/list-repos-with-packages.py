#!/usr/bin/env python3
"""
Lists all repositories in a GitHub organization that have GitHub Packages.
Supports all package types: container, npm, maven, gradle, rubygems, nuget, docker.

Outputs a CSV with: org, repo, package_name, package_type, version_count, latest_version.

Requirements:
    pip install requests

Usage:
    python list-repos-with-packages.py \
        --org <ORG> \
        --token <TOKEN> \
        [--api-url <URL>] \
        [--package-type container|npm|maven|...] \
        [--output <FILE>] \
        [--concurrency <N>]
"""

import argparse
import csv
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


PACKAGE_TYPES = ["container", "npm", "maven", "gradle", "rubygems", "nuget", "docker"]


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_paginate(url, token, unwrap_key=None):
    results = []
    page = 1
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    while True:
        sep = "&" if "?" in url else "?"
        resp = requests.get(f"{url}{sep}per_page=100&page={page}", headers=headers)
        if resp.status_code == 404:
            return results
        if resp.status_code != 200:
            print(f"  Warning: GET {url} -> HTTP {resp.status_code}: {resp.text[:200]}", file=sys.stderr)
            return results
        data = resp.json()
        if isinstance(data, list):
            results.extend(data)
            if len(data) < 100:
                break
        elif isinstance(data, dict):
            key = unwrap_key or next(
                (k for k in ("packages", "versions", "items") if k in data), None
            )
            if key:
                chunk = data[key]
                results.extend(chunk)
                if len(chunk) < 100:
                    return results
            else:
                results.append(data)
                break
        page += 1
    return results


# ─────────────────────────────────────────────
# Package listing
# ─────────────────────────────────────────────

def get_org_packages(api_url, org, token, package_type):
    """List all packages of a given type in an org."""
    return gh_paginate(
        f"{api_url}/orgs/{org}/packages?package_type={package_type}",
        token,
    )


def get_package_versions(api_url, org, token, package_type, package_name):
    """List all versions of a package."""
    # URL-encode slashes in package name (common in container/maven)
    encoded_name = package_name.replace("/", "%2F")
    return gh_paginate(
        f"{api_url}/orgs/{org}/packages/{package_type}/{encoded_name}/versions",
        token,
    )


def fetch_packages_for_type(api_url, org, token, package_type, include_repo_name):
    """Return list of dicts with package metadata for one package type."""
    packages = get_org_packages(api_url, org, token, package_type)
    rows = []
    for pkg in packages:
        pkg_name = pkg.get("name", "")
        repo_name = None
        repo_info = pkg.get("repository")
        if repo_info:
            repo_name = repo_info.get("name")

        # Apply repo filter if requested
        if include_repo_name and repo_name != include_repo_name:
            continue

        versions = get_package_versions(api_url, org, token, package_type, pkg_name)
        version_count = len(versions)
        latest = versions[0].get("name", "") if versions else ""

        rows.append({
            "org": org,
            "repo": repo_name or "(unlinked)",
            "package_name": pkg_name,
            "package_type": package_type,
            "version_count": version_count,
            "latest_version": latest,
            "package_id": pkg.get("id"),
        })
    return rows


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="List all packages in a GitHub org")
    parser.add_argument("--org", required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--api-url", default="https://api.github.com")
    parser.add_argument(
        "--package-type",
        choices=PACKAGE_TYPES + ["all"],
        default="all",
        help="Package type to list (default: all)",
    )
    parser.add_argument("--output", default="org_packages.csv")
    parser.add_argument("--concurrency", type=int, default=4,
                        help="Parallel requests per package type (default: 4)")
    parser.add_argument("--filter-repo",
                        help="Only list packages linked to a specific repo")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")
    types_to_check = PACKAGE_TYPES if args.package_type == "all" else [args.package_type]

    print(f"Listing packages for org: {args.org}")
    print(f"Package types: {', '.join(types_to_check)}\n")

    all_rows = []

    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {
            executor.submit(
                fetch_packages_for_type, api_url, args.org, args.token, ptype, args.filter_repo
            ): ptype
            for ptype in types_to_check
        }
        for future in as_completed(futures):
            ptype = futures[future]
            rows = future.result()
            if rows:
                print(f"  [{ptype}] {len(rows)} package(s) found")
                all_rows.extend(rows)
            else:
                print(f"  [{ptype}] none")

    all_rows.sort(key=lambda r: (r["repo"], r["package_type"], r["package_name"]))

    # Summary
    by_repo = defaultdict(list)
    for row in all_rows:
        by_repo[row["repo"]].append(row)

    print(f"\nTotal packages : {len(all_rows)}")
    print(f"Repos with packages: {len(by_repo)}")
    print(f"\n{'Repo':<40} {'Type':<12} {'Package':<40} {'Versions':>8}  Latest")
    print("-" * 110)
    for row in all_rows:
        print(
            f"  {row['repo']:<38} {row['package_type']:<12} {row['package_name']:<40} "
            f"{row['version_count']:>8}  {row['latest_version']}"
        )

    # Write CSV
    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["org", "repo", "package_type", "package_name", "version_count", "latest_version", "package_id"],
        )
        writer.writeheader()
        for row in all_rows:
            writer.writerow(row)

    print(f"\nResults saved to: {args.output}")


if __name__ == "__main__":
    main()
