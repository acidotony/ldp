#!/usr/bin/env python3
"""
Migrates GitHub Packages (container images) from a source GitHub org to a
destination GitHub org using Podman. Reads the package list from the GitHub API,
pulls each image/tag from the source registry, retags it for the destination,
and pushes it.

Supports container and docker package types only (Podman handles OCI images).
For npm/maven/nuget/rubygems packages, see the per-ecosystem tooling notes below.

Requirements:
    pip install requests
    podman (must be installed and in PATH, authenticated to both registries)

Podman authentication (run before this script):
    podman login ghcr.io -u <USERNAME> -p <SOURCE_TOKEN>
    podman login ghcr.io -u <USERNAME> -p <DEST_TOKEN>
    (if source and dest are on the same registry, one login suffices with a token
     that has read:packages on source and write:packages on dest)

Usage:
    python migrate-packages.py \
        --source-org <ORG> \
        --dest-org <ORG> \
        --source-token <TOKEN> \
        [--dest-token <TOKEN>]  \
        [--api-url <URL>] \
        [--registry <REGISTRY>] \
        [--filter-repo <REPO>] \
        [--filter-package <NAME>] \
        [--concurrency <N>] \
        [--dry-run]

For non-container packages (npm, maven, nuget, rubygems, gradle) use:
    migrate-packages-ecosystem.py
"""

import argparse
import subprocess
import sys
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


SUPPORTED_TYPES = ("container", "docker")


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_paginate(url, token):
    results = []
    page = 1
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    while True:
        sep = "&" if "?" in url else "?"
        resp = requests.get(f"{url}{sep}per_page=100&page={page}", headers=headers)
        if resp.status_code == 404:
            return results
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, list):
            results.extend(data)
            if len(data) < 100:
                break
        page += 1
    return results


def get_container_packages(api_url, org, token):
    """Return all container + docker packages in the org."""
    packages = []
    for ptype in SUPPORTED_TYPES:
        batch = gh_paginate(f"{api_url}/orgs/{org}/packages?package_type={ptype}", token)
        for pkg in batch:
            pkg["_type"] = ptype
        packages.extend(batch)
    return packages


def get_package_versions(api_url, org, token, package_type, package_name):
    encoded = package_name.replace("/", "%2F")
    return gh_paginate(
        f"{api_url}/orgs/{org}/packages/{package_type}/{encoded}/versions",
        token,
    )


def get_version_tags(version):
    """Extract image tags from a version metadata dict."""
    tags = version.get("metadata", {}).get("container", {}).get("tags", [])
    # Also check docker metadata
    if not tags:
        tags = version.get("metadata", {}).get("docker", {}).get("tags", [])
    return tags


# ─────────────────────────────────────────────
# Podman helpers
# ─────────────────────────────────────────────

def run_podman(cmd, dry_run=False):
    """Run a podman command. Returns (success, output)."""
    full_cmd = ["podman"] + cmd
    if dry_run:
        return True, f"[DRY RUN] {' '.join(full_cmd)}"
    try:
        result = subprocess.run(
            full_cmd,
            capture_output=True,
            text=True,
            timeout=600,  # 10 min per operation
        )
        output = result.stdout.strip() + result.stderr.strip()
        return result.returncode == 0, output
    except subprocess.TimeoutExpired:
        return False, "ERROR: podman command timed out after 600s"
    except FileNotFoundError:
        print("ERROR: 'podman' not found in PATH. Install podman and try again.", file=sys.stderr)
        sys.exit(1)


def migrate_image_tag(source_ref, dest_ref, dry_run):
    """Pull, retag, push a single image tag. Returns (success, message)."""
    # Pull
    ok, out = run_podman(["pull", source_ref], dry_run)
    if not ok:
        return False, f"pull failed: {out}"

    # Tag
    ok, out = run_podman(["tag", source_ref, dest_ref], dry_run)
    if not ok:
        return False, f"tag failed: {out}"

    # Push
    ok, out = run_podman(["push", dest_ref], dry_run)
    if not ok:
        return False, f"push failed: {out}"

    # Cleanup local image to save disk space
    run_podman(["rmi", source_ref, dest_ref], dry_run)

    return True, "OK"


# ─────────────────────────────────────────────
# Per-package migration
# ─────────────────────────────────────────────

def migrate_package(source_org, dest_org, registry, package, source_token, dest_token, api_url, dry_run):
    """
    Migrate all tagged versions of a single package.
    Returns list of (tag_ref, success, message).
    """
    pkg_name = package["name"]
    pkg_type = package["_type"]
    token = source_token

    versions = get_package_versions(api_url, source_org, token, pkg_type, pkg_name)

    tag_results = []
    migrated_tags = set()

    for version in versions:
        tags = get_version_tags(version)
        if not tags:
            # Untagged digest — skip (not pullable by tag)
            continue

        for tag in tags:
            if tag in migrated_tags:
                continue
            migrated_tags.add(tag)

            source_ref = f"{registry}/{source_org}/{pkg_name}:{tag}"
            dest_ref   = f"{registry}/{dest_org}/{pkg_name}:{tag}"

            ok, msg = migrate_image_tag(source_ref, dest_ref, dry_run)
            tag_results.append((f"{pkg_name}:{tag}", ok, msg))

    return tag_results


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Migrate container packages between GitHub orgs using Podman")
    parser.add_argument("--source-org", required=True)
    parser.add_argument("--dest-org", required=True)
    parser.add_argument("--source-token", required=True,
                        help="GitHub PAT for source org (read:packages)")
    parser.add_argument("--dest-token",
                        help="GitHub PAT for dest org (write:packages). Defaults to source-token if omitted.")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="GitHub API base URL (default: https://api.github.com)")
    parser.add_argument("--registry", default="ghcr.io",
                        help="Container registry hostname (default: ghcr.io)")
    parser.add_argument("--filter-repo",
                        help="Only migrate packages linked to a specific repo")
    parser.add_argument("--filter-package",
                        help="Only migrate a specific package name")
    parser.add_argument("--concurrency", type=int, default=3,
                        help="Parallel package migrations (default: 3 — each pull/push is I/O heavy)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print podman commands without executing them")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")
    dest_token = args.dest_token or args.source_token

    # Verify podman is available
    if not args.dry_run and not shutil.which("podman"):
        print("ERROR: 'podman' not found in PATH.", file=sys.stderr)
        sys.exit(1)

    print(f"Migration plan")
    print(f"  Source : {args.registry}/{args.source_org}")
    print(f"  Dest   : {args.registry}/{args.dest_org}")
    print(f"  Dry run: {args.dry_run}\n")

    # Fetch packages
    print(f"Fetching container packages from: {args.source_org}")
    packages = get_container_packages(api_url, args.source_org, args.source_token)

    # Apply filters
    if args.filter_repo:
        packages = [
            p for p in packages
            if p.get("repository", {}) and p["repository"].get("name") == args.filter_repo
        ]
    if args.filter_package:
        packages = [p for p in packages if p["name"] == args.filter_package]

    print(f"Found {len(packages)} package(s) to migrate.\n")

    if not packages:
        print("Nothing to migrate.")
        return

    results_success = []
    results_failed  = []

    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {
            executor.submit(
                migrate_package,
                args.source_org, args.dest_org, args.registry,
                pkg, args.source_token, dest_token, api_url, args.dry_run,
            ): pkg["name"]
            for pkg in packages
        }

        done = 0
        for future in as_completed(futures):
            pkg_name = futures[future]
            done += 1
            print(f"[{done}/{len(packages)}] {pkg_name}")
            try:
                tag_results = future.result()
                if not tag_results:
                    print(f"  (no tagged versions — skipped)")
                    continue
                for tag_ref, ok, msg in tag_results:
                    if ok:
                        print(f"  [OK]   {tag_ref}")
                        results_success.append(tag_ref)
                    else:
                        print(f"  [FAIL] {tag_ref}: {msg}")
                        results_failed.append((tag_ref, msg))
            except Exception as e:
                print(f"  [ERROR] {pkg_name}: {e}")
                results_failed.append((pkg_name, str(e)))

    print(f"\n{'='*60}")
    print(f"SUMMARY  Tags migrated: {len(results_success)}  Failed: {len(results_failed)}")

    if results_failed:
        print("\nFailed:")
        for ref, msg in results_failed:
            print(f"  [FAIL] {ref}: {msg}")
        sys.exit(1)

    if not args.dry_run:
        print(f"""
Next steps:
  1. Verify packages are visible at: https://github.com/orgs/{args.dest_org}/packages
  2. Update any references to {args.registry}/{args.source_org}/ in Dockerfiles,
     Helm charts, and workflow files to point to {args.registry}/{args.dest_org}/
  3. Archive or delete source packages once migration is verified
""")


if __name__ == "__main__":
    main()
