"""
packages — GitHub Packages migration utilities.

Exposed functions:
    list_packages(api_url, org, token, package_type, filter_repo) -> list[dict]
    migrate_container_packages(args) -> (success, failed)
    migrate_ecosystem_packages(args) -> (success, failed)
"""

import importlib.util
import pathlib

_HERE = pathlib.Path(__file__).parent


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, _HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def list_packages(api_url, org, token, package_type="all", filter_repo=None):
    """
    List all packages in a GitHub org.
    Returns list of dicts: {org, repo, package_type, package_name, version_count, latest_version}
    """
    mod = _load("list-repos-with-packages.py")
    from types import SimpleNamespace

    PACKAGE_TYPES = mod.PACKAGE_TYPES
    types_to_check = PACKAGE_TYPES if package_type == "all" else [package_type]

    all_rows = []
    for ptype in types_to_check:
        rows = mod.fetch_packages_for_type(api_url, org, token, ptype, filter_repo)
        all_rows.extend(rows)

    all_rows.sort(key=lambda r: (r["repo"], r["package_type"], r["package_name"]))
    return all_rows


def migrate_container_packages(
    source_org, dest_org, source_token, dest_token=None,
    api_url="https://api.github.com", registry="ghcr.io",
    filter_repo=None, filter_package=None, concurrency=3, dry_run=False,
):
    """
    Migrate container/docker images using Podman.
    Returns (success_list, failed_list).
    """
    mod = _load("migrate-packages.py")
    from types import SimpleNamespace

    packages = mod.get_container_packages(api_url, source_org, source_token)
    if filter_repo:
        packages = [
            p for p in packages
            if p.get("repository", {}) and p["repository"].get("name") == filter_repo
        ]
    if filter_package:
        packages = [p for p in packages if p["name"] == filter_package]

    success, failed = [], []
    for pkg in packages:
        results = mod.migrate_package(
            source_org, dest_org, registry, pkg,
            source_token, dest_token or source_token,
            api_url, dry_run,
        )
        for tag_ref, ok, msg in results:
            (success if ok else failed).append((tag_ref, msg))

    return success, failed


def migrate_ecosystem_packages(
    source_org, dest_org, source_token, dest_token,
    api_url="https://api.github.com", package_type="all",
    filter_package=None, work_dir=None, dry_run=False,
):
    """
    Migrate npm/maven/gradle/nuget/rubygems packages.
    Returns (success_list, failed_list).
    """
    import pathlib, tempfile, shutil
    mod = _load("migrate-packages-ecosystem.py")
    from types import SimpleNamespace

    if work_dir:
        wd = pathlib.Path(work_dir)
        wd.mkdir(parents=True, exist_ok=True)
        cleanup = False
    else:
        wd = pathlib.Path(tempfile.mkdtemp(prefix="gh-pkg-migration-"))
        cleanup = True

    args = SimpleNamespace(
        source_org=source_org,
        dest_org=dest_org,
        source_token=source_token,
        dest_token=dest_token,
        api_url=api_url,
        package_type=package_type,
        filter_package=filter_package,
        dry_run=dry_run,
    )

    try:
        success, failed = mod.migrate_all(args, wd)
    finally:
        if cleanup:
            shutil.rmtree(wd, ignore_errors=True)

    return success, failed
