#!/usr/bin/env python3
"""
Migrates non-container GitHub Packages (npm, maven, gradle, nuget, rubygems)
from a source org to a destination org.

Strategy per ecosystem:
  npm      - download .tgz via registry API, npm publish to dest
  maven    - download .jar + .pom via registry API, mvn deploy:deploy-file to dest
  gradle   - same as maven
  nuget    - download .nupkg via registry API, dotnet nuget push to dest
  rubygems - download .gem via registry API, gem push to dest

All steps:
  1. List packages + versions via GitHub API
  2. Download each asset to a temp directory
  3. Re-publish to the destination org's GitHub Packages registry

Requirements:
    pip install requests
    npm        (for npm packages)
    mvn        (for maven/gradle packages)
    dotnet     (for nuget packages)
    gem        (for rubygems packages)
    -- only the tools needed for the package types you are migrating

Usage:
    python migrate-packages-ecosystem.py \
        --source-org <ORG> \
        --dest-org <ORG> \
        --source-token <TOKEN> \
        --dest-token <TOKEN> \
        [--package-type npm|maven|gradle|nuget|rubygems|all] \
        [--filter-package <NAME>] \
        [--work-dir /tmp/pkg-migration] \
        [--api-url <URL>] \
        [--dry-run]
"""

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


ECOSYSTEM_TYPES = ["npm", "maven", "gradle", "nuget", "rubygems"]


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_headers(token):
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }


def gh_paginate(url, token):
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        resp = requests.get(f"{url}{sep}per_page=100&page={page}", headers=gh_headers(token))
        if resp.status_code == 404:
            return results
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, list):
            results.extend(data)
            if len(data) < 100:
                break
        page += 1
    return results


def get_packages(api_url, org, token, package_type):
    return gh_paginate(f"{api_url}/orgs/{org}/packages?package_type={package_type}", token)


def get_versions(api_url, org, token, package_type, package_name):
    encoded = package_name.replace("/", "%2F")
    return gh_paginate(
        f"{api_url}/orgs/{org}/packages/{package_type}/{encoded}/versions",
        token,
    )


# ─────────────────────────────────────────────
# Download helpers
# ─────────────────────────────────────────────

def download_file(url, dest_path, token):
    """Download a file from a URL with GitHub auth."""
    resp = requests.get(url, headers=gh_headers(token), stream=True)
    resp.raise_for_status()
    with open(dest_path, "wb") as f:
        for chunk in resp.iter_content(chunk_size=8192):
            f.write(chunk)


def run_cmd(cmd, cwd=None, env=None, dry_run=False):
    """Run a shell command. Returns (success, output)."""
    if dry_run:
        return True, f"[DRY RUN] {' '.join(str(c) for c in cmd)}"
    try:
        result = subprocess.run(
            [str(c) for c in cmd],
            capture_output=True,
            text=True,
            cwd=str(cwd) if cwd else None,
            env=env,
            timeout=300,
        )
        out = (result.stdout + result.stderr).strip()
        return result.returncode == 0, out
    except FileNotFoundError as e:
        return False, f"Tool not found: {e}"
    except subprocess.TimeoutExpired:
        return False, "Command timed out after 300s"


# ─────────────────────────────────────────────
# npm
# ─────────────────────────────────────────────

def migrate_npm_package(source_org, dest_org, pkg_name, versions, source_token, dest_token, work_dir, dry_run):
    """
    npm packages: download tarball via registry HTTP API, npm publish to dest.
    Package name format: @scope/name or name
    """
    results = []
    pkg_dir = work_dir / "npm" / pkg_name.replace("/", "__").replace("@", "")
    pkg_dir.mkdir(parents=True, exist_ok=True)

    for version in versions:
        ver = version.get("name", "")
        if not ver:
            continue

        # GitHub npm registry download URL
        # Format: https://npm.pkg.github.com/download/@scope/name/-/name-version.tgz
        pkg_basename = pkg_name.lstrip("@").replace("/", "-")
        tgz_name = f"{pkg_basename}-{ver}.tgz"
        download_url = f"https://npm.pkg.github.com/download/{pkg_name}/-/{tgz_name}"
        tgz_path = pkg_dir / tgz_name

        label = f"npm/{pkg_name}@{ver}"

        if not dry_run:
            try:
                download_file(download_url, tgz_path, source_token)
            except Exception as e:
                results.append((label, False, f"download failed: {e}"))
                continue

        # npm publish
        dest_registry = f"https://npm.pkg.github.com/"
        env = os.environ.copy()
        env["NODE_AUTH_TOKEN"] = dest_token
        ok, out = run_cmd(
            ["npm", "publish", str(tgz_path),
             "--registry", dest_registry,
             "--access", "restricted"],
            env=env,
            dry_run=dry_run,
        )
        results.append((label, ok, out if not ok else "OK"))

    return results


# ─────────────────────────────────────────────
# Maven / Gradle
# ─────────────────────────────────────────────

def _write_maven_settings(settings_path, dest_org, dest_token):
    """Write a Maven settings.xml with GitHub Packages credentials."""
    settings = f"""<?xml version="1.0" encoding="UTF-8"?>
<settings>
  <servers>
    <server>
      <id>github-dest</id>
      <username>x-access-token</username>
      <password>{dest_token}</password>
    </server>
  </servers>
</settings>"""
    settings_path.write_text(settings)


def migrate_maven_package(source_org, dest_org, pkg_name, versions, source_token, dest_token, work_dir, dry_run):
    """
    Maven/Gradle packages: download .jar + .pom via GitHub API asset URLs,
    re-deploy with mvn deploy:deploy-file.

    pkg_name format: groupId.artifactId (GitHub uses this as the package name)
    """
    results = []
    pkg_dir = work_dir / "maven" / pkg_name.replace(".", "_").replace("/", "__")
    pkg_dir.mkdir(parents=True, exist_ok=True)

    settings_path = pkg_dir / "settings.xml"
    if not dry_run:
        _write_maven_settings(settings_path, dest_org, dest_token)

    dest_repo_url = f"https://maven.pkg.github.com/{dest_org}/{pkg_name.split('.')[-1]}"

    for version in versions:
        ver = version.get("name", "")
        if not ver:
            continue

        label = f"maven/{pkg_name}:{ver}"
        version_dir = pkg_dir / ver
        version_dir.mkdir(exist_ok=True)

        # Maven version assets come from the GitHub Packages Maven registry
        # Reconstruct group/artifact from package name heuristic:
        #   GitHub stores maven packages as "groupId.artifactId"
        parts = pkg_name.rsplit(".", 1)
        group_id = parts[0] if len(parts) == 2 else pkg_name
        artifact_id = parts[-1]
        group_path = group_id.replace(".", "/")

        base_url = (
            f"https://maven.pkg.github.com/{source_org}/"
            f"{artifact_id}/{group_path}/{artifact_id}/{ver}"
        )

        jar_name  = f"{artifact_id}-{ver}.jar"
        pom_name  = f"{artifact_id}-{ver}.pom"
        jar_path  = version_dir / jar_name
        pom_path  = version_dir / pom_name

        if not dry_run:
            try:
                download_file(f"{base_url}/{jar_name}", jar_path, source_token)
            except Exception as e:
                # Some packages are pom-only (no jar)
                jar_path = None

            try:
                download_file(f"{base_url}/{pom_name}", pom_path, source_token)
            except Exception as e:
                results.append((label, False, f"pom download failed: {e}"))
                continue

        cmd = [
            "mvn", "deploy:deploy-file",
            f"-DgroupId={group_id}",
            f"-DartifactId={artifact_id}",
            f"-Dversion={ver}",
            f"-DrepositoryId=github-dest",
            f"-Durl={dest_repo_url}",
            f"-DpomFile={pom_path}",
            f"--settings={settings_path}",
        ]
        if jar_path and (dry_run or jar_path.exists()):
            cmd.append(f"-Dfile={jar_path}")
        else:
            cmd.append("-Dpackaging=pom")
            cmd.append(f"-Dfile={pom_path}")

        ok, out = run_cmd(cmd, dry_run=dry_run)
        results.append((label, ok, out if not ok else "OK"))

    return results


# ─────────────────────────────────────────────
# NuGet
# ─────────────────────────────────────────────

def migrate_nuget_package(source_org, dest_org, pkg_name, versions, source_token, dest_token, work_dir, dry_run):
    """
    NuGet: download .nupkg from GitHub Packages, push with dotnet nuget push.
    """
    results = []
    pkg_dir = work_dir / "nuget" / pkg_name
    pkg_dir.mkdir(parents=True, exist_ok=True)

    dest_source = f"https://nuget.pkg.github.com/{dest_org}/index.json"

    for version in versions:
        ver = version.get("name", "")
        if not ver:
            continue

        label = f"nuget/{pkg_name}.{ver}"
        nupkg_name = f"{pkg_name}.{ver}.nupkg"
        nupkg_path = pkg_dir / nupkg_name

        download_url = (
            f"https://nuget.pkg.github.com/{source_org}/download/"
            f"{pkg_name.lower()}/{ver}/{nupkg_name}"
        )

        if not dry_run:
            try:
                download_file(download_url, nupkg_path, source_token)
            except Exception as e:
                results.append((label, False, f"download failed: {e}"))
                continue

        ok, out = run_cmd(
            ["dotnet", "nuget", "push", str(nupkg_path),
             "--api-key", dest_token,
             "--source", dest_source,
             "--skip-duplicate"],
            dry_run=dry_run,
        )
        results.append((label, ok, out if not ok else "OK"))

    return results


# ─────────────────────────────────────────────
# RubyGems
# ─────────────────────────────────────────────

def migrate_rubygems_package(source_org, dest_org, pkg_name, versions, source_token, dest_token, work_dir, dry_run):
    """
    RubyGems: download .gem from GitHub Packages, gem push to dest.
    """
    results = []
    pkg_dir = work_dir / "rubygems" / pkg_name
    pkg_dir.mkdir(parents=True, exist_ok=True)

    dest_host = f"https://rubygems.pkg.github.com/{dest_org}"

    for version in versions:
        ver = version.get("name", "")
        if not ver:
            continue

        label = f"gem/{pkg_name}-{ver}"
        gem_name = f"{pkg_name}-{ver}.gem"
        gem_path = pkg_dir / gem_name

        download_url = (
            f"https://rubygems.pkg.github.com/{source_org}/gems/{gem_name}"
        )

        if not dry_run:
            try:
                download_file(download_url, gem_path, source_token)
            except Exception as e:
                results.append((label, False, f"download failed: {e}"))
                continue

        env = os.environ.copy()
        env["GEM_HOST_API_KEY"] = dest_token
        ok, out = run_cmd(
            ["gem", "push", str(gem_path), "--host", dest_host],
            env=env,
            dry_run=dry_run,
        )
        results.append((label, ok, out if not ok else "OK"))

    return results


# ─────────────────────────────────────────────
# Dispatcher
# ─────────────────────────────────────────────

MIGRATORS = {
    "npm":      migrate_npm_package,
    "maven":    migrate_maven_package,
    "gradle":   migrate_maven_package,   # gradle uses maven registry
    "nuget":    migrate_nuget_package,
    "rubygems": migrate_rubygems_package,
}


def migrate_all(args, work_dir):
    api_url = args.api_url.rstrip("/")
    types = ECOSYSTEM_TYPES if args.package_type == "all" else [args.package_type]

    all_success = []
    all_failed  = []

    for pkg_type in types:
        print(f"\n--- {pkg_type.upper()} ---")
        packages = get_packages(api_url, args.source_org, args.source_token, pkg_type)

        if args.filter_package:
            packages = [p for p in packages if p["name"] == args.filter_package]

        if not packages:
            print(f"  No {pkg_type} packages found.")
            continue

        print(f"  Found {len(packages)} package(s).")

        for pkg in packages:
            pkg_name = pkg["name"]
            print(f"\n  Package: {pkg_name}")

            versions = get_versions(api_url, args.source_org, args.source_token, pkg_type, pkg_name)
            print(f"  Versions: {len(versions)}")

            migrator = MIGRATORS[pkg_type]
            results = migrator(
                args.source_org, args.dest_org,
                pkg_name, versions,
                args.source_token, args.dest_token,
                work_dir, args.dry_run,
            )

            for label, ok, msg in results:
                if ok:
                    print(f"    [OK]   {label}")
                    all_success.append(label)
                else:
                    print(f"    [FAIL] {label}: {msg}")
                    all_failed.append((label, msg))

    return all_success, all_failed


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Migrate npm/maven/gradle/nuget/rubygems packages between GitHub orgs"
    )
    parser.add_argument("--source-org", required=True)
    parser.add_argument("--dest-org", required=True)
    parser.add_argument("--source-token", required=True,
                        help="GitHub PAT for source org (read:packages)")
    parser.add_argument("--dest-token", required=True,
                        help="GitHub PAT for dest org (write:packages)")
    parser.add_argument("--api-url", default="https://api.github.com")
    parser.add_argument(
        "--package-type",
        choices=ECOSYSTEM_TYPES + ["all"],
        default="all",
    )
    parser.add_argument("--filter-package",
                        help="Migrate only a specific package name")
    parser.add_argument("--work-dir", default=None,
                        help="Directory for downloaded assets (default: system temp)")
    parser.add_argument("--keep-work-dir", action="store_true",
                        help="Do not delete the work directory after migration")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    print(f"Ecosystem package migration")
    print(f"  Source : {args.source_org}")
    print(f"  Dest   : {args.dest_org}")
    print(f"  Types  : {args.package_type}")
    print(f"  Dry run: {args.dry_run}")

    # Work directory for downloaded assets
    if args.work_dir:
        work_dir = Path(args.work_dir)
        work_dir.mkdir(parents=True, exist_ok=True)
        cleanup = False
    else:
        tmp = tempfile.mkdtemp(prefix="gh-pkg-migration-")
        work_dir = Path(tmp)
        cleanup = not args.keep_work_dir

    print(f"  Work dir: {work_dir}\n")

    try:
        all_success, all_failed = migrate_all(args, work_dir)
    finally:
        if cleanup and work_dir.exists():
            shutil.rmtree(work_dir, ignore_errors=True)
            print(f"\nCleaned up work dir: {work_dir}")

    print(f"\n{'='*60}")
    print(f"SUMMARY  Migrated: {len(all_success)}  Failed: {len(all_failed)}")

    if all_failed:
        print("\nFailed:")
        for label, msg in all_failed:
            print(f"  [FAIL] {label}: {msg}")
        sys.exit(1)


if __name__ == "__main__":
    main()
