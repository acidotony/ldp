#!/usr/bin/env python3
"""
List all repositories in a GitHub organization that have deployment
environments configured (reviewers, wait timers, deployment branch policies).

Usage:
    python list-repos-with-environments.py --org <ORG> --token <TOKEN> \
        [--api-url <URL>] [--output <FILE>] [--include-archived]
"""

import argparse
import csv
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import urllib.request
import urllib.error


def github_get(url, token, api_url):
    """Paginate through a GitHub API endpoint and return all results."""
    results = []
    page = 1
    while True:
        paginated = f"{url}{'&' if '?' in url else '?'}per_page=100&page={page}"
        req = urllib.request.Request(
            paginated,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            if e.code not in (403, 404):
                print(f"  HTTP {e.code} for {paginated}: {body}", file=sys.stderr)
            return results
        except urllib.error.URLError as e:
            print(f"  Request error for {paginated}: {e}", file=sys.stderr)
            return results

        if isinstance(data, dict) and "environments" in data:
            batch = data["environments"]
        elif isinstance(data, list):
            batch = data
        else:
            batch = []

        if not batch:
            break
        results.extend(batch)
        if len(batch) < 100:
            break
        page += 1

    return results


def get_all_repos(org, token, api_url, include_archived=False):
    """Return list of repo names in the org."""
    repos = github_get(f"{api_url}/orgs/{org}/repos?type=all", token, api_url)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_repo_environments(org, repo, token, api_url):
    """Return (repo_name, env_count, environments list of summary dicts)."""
    envs = github_get(f"{api_url}/repos/{org}/{repo}/environments", token, api_url)
    rows = []
    for env in envs:
        protection_rules = env.get("protection_rules", [])
        reviewer_count = sum(
            len(r.get("reviewers", [])) for r in protection_rules if r.get("type") == "required_reviewers"
        )
        wait_timer = next(
            (r.get("wait_timer", 0) for r in protection_rules if r.get("type") == "wait_timer"), 0
        )
        branch_policy = env.get("deployment_branch_policy")
        rows.append({
            "name": env.get("name", ""),
            "reviewer_count": reviewer_count,
            "wait_timer": wait_timer,
            "has_branch_policy": bool(branch_policy),
            "protected_branches": (branch_policy or {}).get("protected_branches", False),
            "custom_branch_policies": (branch_policy or {}).get("custom_branch_policies", False),
        })
    return repo, len(rows), rows


def main():
    parser = argparse.ArgumentParser(description="List repos with deployment environments")
    parser.add_argument("--org", required=True, help="GitHub organization name")
    parser.add_argument("--token", required=True, help="GitHub PAT")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="GitHub API base URL (default: https://api.github.com)")
    parser.add_argument("--output", default="repos_with_environments.csv",
                        help="Output CSV file (default: repos_with_environments.csv)")
    parser.add_argument("--concurrency", type=int, default=10,
                        help="Parallel requests (default: 10)")
    parser.add_argument("--include-archived", action="store_true",
                        help="Include archived repositories")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")

    print(f"Fetching repos for org: {args.org}")
    repos = get_all_repos(args.org, args.token, api_url, args.include_archived)
    print(f"Found {len(repos)} repos. Checking for environments...")

    results = []
    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {
            executor.submit(get_repo_environments, args.org, repo, args.token, api_url): repo
            for repo in repos
        }
        done = 0
        for future in as_completed(futures):
            done += 1
            repo_name, count, rows = future.result()
            if count > 0:
                names = ",".join(r["name"] for r in rows)
                results.append((repo_name, count, names))
                print(f"  [{done}/{len(repos)}] {repo_name}: {count} environment(s)")
            else:
                print(f"  [{done}/{len(repos)}] {repo_name}: no environments", end="\r")

    print(f"\n\nRepositories with environments: {len(results)} / {len(repos)}")

    results.sort(key=lambda x: x[0])

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["repository", "environment_count", "environment_names"])
        for repo, count, names in results:
            writer.writerow([repo, count, names])

    print(f"Results saved to: {args.output}")

    print(f"\n{'Repository':<50} {'Envs':>5}  Names")
    print("-" * 80)
    for repo, count, names in results:
        print(f"{repo:<50} {count:>5}  {names}")


if __name__ == "__main__":
    main()
