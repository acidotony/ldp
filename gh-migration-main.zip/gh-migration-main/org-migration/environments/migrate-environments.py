#!/usr/bin/env python3
"""
Migrates repo-level deployment environments from a source org to a destination org.

Copies, per environment:
    - Required reviewers (users and teams, matched by login/slug on destination)
    - Wait timer
    - Deployment branch policies (protected_branches flag, custom branch/tag
      name patterns)
    - Prevent self-review flag

NOTE: Environment secrets and variables are NOT handled here (see the
`secrets` and `variables` modules — environment-scoped secrets already flow
through the CyberArk secrets pipeline).

Requirements:
    pip install requests

Usage:
    python migrate-environments.py \
        --source-org <SOURCE_ORG> \
        --source-token <SOURCE_TOKEN> \
        --dest-org <DEST_ORG> \
        --dest-token <DEST_TOKEN> \
        [--api-url <SOURCE_API_URL>] \
        [--dest-api-url <DEST_API_URL>] \
        [--filter-repo <REPO>] \
        [--concurrency <N>] \
        [--include-archived] \
        [--dry-run]
"""

import argparse
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests", file=sys.stderr)
    sys.exit(1)


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_request(method, url, token, body=None):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    resp = requests.request(method, url, headers=headers, json=body)
    try:
        data = resp.json() if resp.content else {}
    except ValueError:
        data = {}
    return resp.status_code, data


def gh_paginate(url, token, list_key=None):
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        status, data = gh_request("GET", f"{url}{sep}per_page=100&page={page}", token)
        if status in (403, 404):
            return results
        if status != 200:
            msg = data.get("message", "") if isinstance(data, dict) else ""
            print(f"  Warning: GET {url} -> HTTP {status}: {msg}", file=sys.stderr)
            return results
        batch = data.get(list_key, []) if list_key else data
        if not batch:
            return results
        results.extend(batch)
        if len(batch) < 100:
            return results
        page += 1


def get_all_repos(org, token, api_url, include_archived=False):
    repos = gh_paginate(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_repo_environments(org, repo, token, api_url):
    """Return list of full environment dicts for a repo."""
    return gh_paginate(f"{api_url}/repos/{org}/{repo}/environments", token, list_key="environments")


def get_environment_branch_policies(org, repo, env_name, token, api_url):
    return gh_paginate(
        f"{api_url}/repos/{org}/{repo}/environments/{env_name}/deployment-branch-policies",
        token, list_key="branch_policies",
    )


def build_reviewer_payload(protection_rules, dest_org, dest_token, dest_api_url):
    """
    Convert source protection_rules reviewers into destination create/update
    payload reviewers, resolving user/team ids on the destination.
    Skips reviewers that can't be resolved on the destination (e.g. user not
    migrated / team not created yet) and reports them.
    """
    reviewers = []
    unresolved = []
    for rule in protection_rules:
        if rule.get("type") != "required_reviewers":
            continue
        for reviewer in rule.get("reviewers", []):
            r_type = reviewer.get("type")
            entity = reviewer.get("reviewer", {})
            if r_type == "User":
                login = entity.get("login")
                status, data = gh_request("GET", f"{dest_api_url}/users/{login}", dest_token)
                if status == 200:
                    reviewers.append({"type": "User", "id": data["id"]})
                else:
                    unresolved.append(f"user:{login}")
            elif r_type == "Team":
                slug = entity.get("slug")
                status, data = gh_request(
                    "GET", f"{dest_api_url}/orgs/{dest_org}/teams/{slug}", dest_token
                )
                if status == 200:
                    reviewers.append({"type": "Team", "id": data["id"]})
                else:
                    unresolved.append(f"team:{slug}")
    return reviewers, unresolved


def create_or_update_environment(org, repo, token, api_url, env_name, wait_timer, reviewers, prevent_self_review):
    """PUT the environment config (creates it if missing). Returns (ok, msg)."""
    body = {
        "prevent_self_review": prevent_self_review,
        "reviewers": [{"type": r["type"], "id": r["id"]} for r in reviewers] or None,
        "wait_timer": wait_timer or 0,
    }
    status, data = gh_request(
        "PUT", f"{api_url}/repos/{org}/{repo}/environments/{env_name}", token, body
    )
    ok = status in (200, 201)
    msg = data.get("message", "") if isinstance(data, dict) else ""
    return ok, msg


def set_deployment_branch_policy(org, repo, token, api_url, env_name, branch_policy):
    """Set protected_branches / custom_branch_policies on the destination environment."""
    if not branch_policy:
        return True, "no branch policy"
    body = {
        "protected_branches": branch_policy.get("protected_branches", False),
        "custom_branch_policies": branch_policy.get("custom_branch_policies", False),
    }
    status, data = gh_request(
        "PUT", f"{api_url}/repos/{org}/{repo}/environments/{env_name}", token,
        {"deployment_branch_policy": body},
    )
    ok = status in (200, 201)
    msg = data.get("message", "") if isinstance(data, dict) else ""
    return ok, msg


def copy_branch_policy_rules(source_org, repo, env_name, source_token, source_api_url,
                              dest_org, dest_token, dest_api_url):
    """Copy custom branch/tag name patterns from source to destination environment."""
    rules = get_environment_branch_policies(source_org, repo, env_name, source_token, source_api_url)
    results = []
    for rule in rules:
        body = {"name": rule["name"], "type": rule.get("type", "branch")}
        status, data = gh_request(
            "POST",
            f"{dest_api_url}/repos/{dest_org}/{repo}/environments/{env_name}/deployment-branch-policies",
            dest_token, body,
        )
        ok = status == 200
        msg = data.get("message", "") if isinstance(data, dict) else ""
        results.append((rule["name"], ok, msg))
    return results


# ─────────────────────────────────────────────
# Migration
# ─────────────────────────────────────────────

def migrate_repo_environments(
    source_org, dest_org, repo, source_token, dest_token,
    source_api_url="https://api.github.com", dest_api_url="https://api.github.com",
    dry_run=False,
):
    """
    Copy all environments for a single repo from source to dest.
    Returns list of (env_name, ok, msg).
    """
    envs = get_repo_environments(source_org, repo, source_token, source_api_url)
    results = []

    for env in envs:
        env_name = env.get("name", "")
        protection_rules = env.get("protection_rules", [])
        wait_timer = next(
            (r.get("wait_timer", 0) for r in protection_rules if r.get("type") == "wait_timer"), 0
        )
        prevent_self_review = env.get("can_admins_bypass", True) is False

        if dry_run:
            results.append((env_name, True, "dry-run: would create/update environment"))
            continue

        reviewers, unresolved = build_reviewer_payload(protection_rules, dest_org, dest_token, dest_api_url)
        ok, msg = create_or_update_environment(
            dest_org, repo, dest_token, dest_api_url, env_name, wait_timer, reviewers, prevent_self_review
        )
        if not ok:
            results.append((env_name, False, msg or "failed to create/update environment"))
            continue

        branch_ok, branch_msg = set_deployment_branch_policy(
            dest_org, repo, dest_token, dest_api_url, env_name, env.get("deployment_branch_policy")
        )
        if not branch_ok:
            results.append((env_name, False, f"created but branch policy failed: {branch_msg}"))
            continue

        if (env.get("deployment_branch_policy") or {}).get("custom_branch_policies"):
            rule_results = copy_branch_policy_rules(
                source_org, repo, env_name, source_token, source_api_url,
                dest_org, dest_token, dest_api_url,
            )
            failed_rules = [r for r in rule_results if not r[1]]
            if failed_rules:
                results.append((env_name, False, f"branch rules failed: {failed_rules}"))
                continue

        note = "created/updated"
        if unresolved:
            note += f" (unresolved reviewers: {', '.join(unresolved)} - assign manually)"
        results.append((env_name, True, note))

    return results


def migrate_all(args):
    """
    Migrate repo-level environments for every repo in the source org (or a
    single repo if args.filter_repo is set).
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    source_api_url = args.api_url.rstrip("/")
    dest_api_url = args.dest_api_url.rstrip("/")

    if args.filter_repo:
        repos = [args.filter_repo]
    else:
        repos = get_all_repos(args.source_org, args.source_token, source_api_url, args.include_archived)

    print(f"Migrating repo-level environments for {len(repos)} repo(s): "
          f"{args.source_org} -> {args.dest_org}")

    success, failed, skipped = [], [], []

    def _process(repo):
        env_results = migrate_repo_environments(
            args.source_org, args.dest_org, repo,
            args.source_token, args.dest_token,
            source_api_url, dest_api_url, args.dry_run,
        )
        if not env_results:
            return repo, "skipped", []
        return repo, "done", env_results

    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {executor.submit(_process, repo): repo for repo in repos}
        for future in as_completed(futures):
            repo, status, env_results = future.result()
            if status == "skipped":
                skipped.append(repo)
                print(f"  [skip] {repo}: no environments")
                continue
            for name, ok, msg in env_results:
                label = f"{repo}:{name}"
                if ok:
                    success.append((label, msg))
                    print(f"  [ok]   {label}: {msg}")
                else:
                    failed.append((label, msg))
                    print(f"  [FAIL] {label}: {msg}")

    return {"success": success, "failed": failed, "skipped": skipped}


def build_parser():
    parser = argparse.ArgumentParser(description="Migrate repo-level deployment environments between GitHub orgs")
    parser.add_argument("--source-org", required=True)
    parser.add_argument("--source-token", required=True)
    parser.add_argument("--dest-org", required=True)
    parser.add_argument("--dest-token", required=True)
    parser.add_argument("--api-url", default="https://api.github.com")
    parser.add_argument("--dest-api-url", default="https://api.github.com")
    parser.add_argument("--filter-repo", default=None)
    parser.add_argument("--concurrency", type=int, default=10)
    parser.add_argument("--include-archived", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    migrate_all(args)


if __name__ == "__main__":
    main()
