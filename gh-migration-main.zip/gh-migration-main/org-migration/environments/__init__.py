"""
environments — Repo-level deployment environment migration utilities.

Copies environment configuration (required reviewers, wait timer,
deployment branch policies) from a source org to a destination org.
Environment secrets/variables are handled by the `secrets`/`variables`
modules, not here.

Exposed functions:
    list_repos_with_environments(api_url, org, token, include_archived, concurrency) -> list[dict]
    migrate_repo_environments(args) -> dict {success, failed, skipped}
"""

import importlib.util
import pathlib
from types import SimpleNamespace

_HERE = pathlib.Path(__file__).parent


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, _HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def list_repos_with_environments(
    api_url, org, token, include_archived=False, concurrency=10
):
    """
    Scan all repos in an org and return those that have deployment environments.
    Returns list of dicts: {repo, environment_count, environment_names}
    """
    mod = _load("list-repos-with-environments.py")
    repos = mod.get_all_repos(org, token, api_url, include_archived)

    import concurrent.futures
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as ex:
        futures = {
            ex.submit(mod.get_repo_environments, org, repo, token, api_url): repo
            for repo in repos
        }
        for future in concurrent.futures.as_completed(futures):
            repo_name, count, rows = future.result()
            if count > 0:
                results.append({
                    "repo": repo_name,
                    "environment_count": count,
                    "environment_names": [r["name"] for r in rows],
                })

    results.sort(key=lambda r: r["repo"])
    return results


def migrate_repo_environments(
    source_org, dest_org, source_token, dest_token,
    api_url="https://api.github.com", dest_api_url="https://api.github.com",
    filter_repo=None, concurrency=10, include_archived=False, dry_run=False,
):
    """
    Migrate repo-level deployment environments from source org to destination org.
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    mod = _load("migrate-environments.py")

    args = SimpleNamespace(
        source_org=source_org,
        dest_org=dest_org,
        source_token=source_token,
        dest_token=dest_token,
        api_url=api_url,
        dest_api_url=dest_api_url,
        filter_repo=filter_repo,
        concurrency=concurrency,
        include_archived=include_archived,
        dry_run=dry_run,
    )

    return mod.migrate_all(args)
