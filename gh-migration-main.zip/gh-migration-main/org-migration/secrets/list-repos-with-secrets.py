#!/usr/bin/env python3
"""
List all repositories in a GitHub organization that have Actions secrets.
Usage:
    python list-repos-with-secrets.py --org <ORG> --token <TOKEN> [--api-url <URL>] [--output <FILE>]

Arguments:
    --org       Organization name
    --token     GitHub PAT with repo and admin:org scopes
    --api-url   GitHub API base URL (default: https://api.github.com)
                For GHES: https://ghe.example.com/api/v3
    --output    Output CSV file path (default: repos_with_secrets.csv)
    --concurrency  Number of parallel requests (default: 10)
"""

import argparse
import csv
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import urllib.request
import urllib.error


def github_get(url, token, api_url):
    """Paginate through a GitHub API endpoint and return all results."""
    results = []
    page = 1
    while True:
        paginated = f"{url}{'&' if '?' in url else '?'}per_page=100&page={page}"
        req = urllib.request.Request(
            paginated,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            print(f"  HTTP {e.code} for {paginated}: {body}", file=sys.stderr)
            return results
        except urllib.error.URLError as e:
            print(f"  Request error for {paginated}: {e}", file=sys.stderr)
            return results

        if isinstance(data, list):
            if not data:
                break
            results.extend(data)
            if len(data) < 100:
                break
        elif isinstance(data, dict):
            # Wrapped response (e.g. secrets endpoint returns {total_count, secrets: []})
            for key in ("secrets", "variables", "repositories"):
                if key in data:
                    items = data[key]
                    results.extend(items)
                    if len(items) < 100:
                        return results
                    break
            else:
                results.append(data)
                break

        page += 1

    return results


def get_all_repos(org, token, api_url, include_archived=False):
    """Return list of repo names in the org."""
    repos = github_get(f"{api_url}/orgs/{org}/repos?type=all", token, api_url)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_repo_secret_count(org, repo, token, api_url):
    """Return (repo_name, secret_count, secret_names) for a single repo."""
    secrets = github_get(f"{api_url}/repos/{org}/{repo}/actions/secrets", token, api_url)
    names = [s["name"] for s in secrets]
    return repo, len(names), names


def main():
    parser = argparse.ArgumentParser(description="List repos with Actions secrets")
    parser.add_argument("--org", required=True, help="GitHub organization name")
    parser.add_argument("--token", required=True, help="GitHub PAT")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="GitHub API base URL (default: https://api.github.com)")
    parser.add_argument("--output", default="repos_with_secrets.csv",
                        help="Output CSV file (default: repos_with_secrets.csv)")
    parser.add_argument("--concurrency", type=int, default=10,
                        help="Parallel requests (default: 10)")
    parser.add_argument("--include-archived", action="store_true",
                        help="Include archived repositories")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")

    print(f"Fetching repos for org: {args.org}")
    repos = get_all_repos(args.org, args.token, api_url, args.include_archived)
    print(f"Found {len(repos)} repos. Checking for secrets...")

    results = []
    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {
            executor.submit(get_repo_secret_count, args.org, repo, args.token, api_url): repo
            for repo in repos
        }
        done = 0
        for future in as_completed(futures):
            done += 1
            repo_name, count, names = future.result()
            if count > 0:
                results.append((repo_name, count, ",".join(names)))
                print(f"  [{done}/{len(repos)}] {repo_name}: {count} secret(s)")
            else:
                print(f"  [{done}/{len(repos)}] {repo_name}: no secrets", end="\r")

    print(f"\n\nRepositories with secrets: {len(results)} / {len(repos)}")

    # Sort by repo name
    results.sort(key=lambda x: x[0])

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["repository", "secret_count", "secret_names"])
        for repo, count, names in results:
            writer.writerow([repo, count, names])

    print(f"Results saved to: {args.output}")

    # Print summary table to stdout
    print(f"\n{'Repository':<50} {'Secrets':>7}  Names")
    print("-" * 80)
    for repo, count, names in results:
        print(f"{repo:<50} {count:>7}  {names}")


if __name__ == "__main__":
    main()
