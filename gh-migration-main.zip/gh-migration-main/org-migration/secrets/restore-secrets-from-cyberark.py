#!/usr/bin/env python3
"""
Reads GitHub secrets from CyberArk and recreates them in a destination GitHub org.

Uses the structured account naming convention created by deploy-cyberark-importer.py:
  GH-{ORG}-ORG-{SECRET_NAME}              -> org-level secret
  GH-{ORG}-{REPO}-REPO-{SECRET_NAME}      -> repo-level secret
  GH-{ORG}-{REPO}-ENV-{ENV_NAME}-{SECRET_NAME} -> environment secret

Handles all three GitHub secret scopes automatically based on the account name.

Requirements:
    pip install PyNaCl requests

Usage:
    python restore-secrets-from-cyberark.py \
        --cyberark-url https://cyberark.example.com \
        --cyberark-username admin \
        --cyberark-password secret \
        --cyberark-safe MY_SAFE \
        --source-org source-org-name \
        --dest-org dest-org-name \
        --dest-token ghp_xxxxx \
        [--api-url https://api.github.com] \
        [--dry-run] \
        [--filter-repo my-repo]
"""

import argparse
import base64
import json
import sys
import re
from collections import defaultdict

try:
    import requests
except ImportError:
    print("ERROR: 'requests' is required. Run: pip install requests PyNaCl", file=sys.stderr)
    sys.exit(1)

try:
    from nacl import encoding, public
except ImportError:
    print("ERROR: 'PyNaCl' is required. Run: pip install requests PyNaCl", file=sys.stderr)
    sys.exit(1)


# ─────────────────────────────────────────────
# CyberArk helpers
# ─────────────────────────────────────────────

def cyberark_logon(base_url, username, password):
    """Authenticate to CyberArk PVWA. Returns session token."""
    url = f"{base_url}/PasswordVault/API/auth/CyberArk/Logon"
    resp = requests.post(url, json={"username": username, "password": password}, verify=True)
    resp.raise_for_status()
    return resp.json().strip('"')


def cyberark_logoff(base_url, token):
    try:
        requests.post(
            f"{base_url}/PasswordVault/API/Auth/Logoff",
            headers={"Authorization": token},
        )
    except Exception:
        pass


def cyberark_search_accounts(base_url, token, safe, search_prefix):
    """Return all accounts in a safe matching the search prefix."""
    accounts = []
    offset = 0
    limit = 100
    while True:
        resp = requests.get(
            f"{base_url}/PasswordVault/API/Accounts",
            headers={"Authorization": token},
            params={
                "safeName": safe,
                "search": search_prefix,
                "searchType": "startswith",
                "offset": offset,
                "limit": limit,
            },
            verify=True,
        )
        resp.raise_for_status()
        data = resp.json()
        batch = data.get("value", [])
        accounts.extend(batch)
        if len(batch) < limit:
            break
        offset += limit
    return accounts


def cyberark_get_password(base_url, token, account_id):
    """Retrieve the password value for an account."""
    resp = requests.post(
        f"{base_url}/PasswordVault/API/Accounts/{account_id}/Password/Retrieve",
        headers={"Authorization": token},
        json={},
        verify=True,
    )
    resp.raise_for_status()
    return resp.json().strip('"')


# ─────────────────────────────────────────────
# Naming convention parser
# ─────────────────────────────────────────────

def parse_account_name(account_name, source_org):
    """
    Parse a CyberArk account name into its components.

    Patterns (all case-sensitive):
      GH-{ORG}-ORG-{SECRET_NAME}
      GH-{ORG}-{REPO}-REPO-{SECRET_NAME}
      GH-{ORG}-{REPO}-ENV-{ENV_NAME}-{SECRET_NAME}

    Returns dict with keys: type, repo, env_name, secret_name
    Returns None if the name does not match any pattern.
    """
    prefix = f"GH-{source_org}-"
    if not account_name.startswith(prefix):
        return None

    remainder = account_name[len(prefix):]

    # Org secret: ORG-{SECRET_NAME}
    m = re.match(r"^ORG-(.+)$", remainder)
    if m:
        return {"type": "org", "repo": None, "env_name": None, "secret_name": m.group(1)}

    # Repo secret: {REPO}-REPO-{SECRET_NAME}
    m = re.match(r"^(.+?)-REPO-(.+)$", remainder)
    if m:
        return {"type": "repo", "repo": m.group(1), "env_name": None, "secret_name": m.group(2)}

    # Environment secret: {REPO}-ENV-{ENV_NAME}-{SECRET_NAME}
    m = re.match(r"^(.+?)-ENV-(.+?)-(.+)$", remainder)
    if m:
        return {"type": "env", "repo": m.group(1), "env_name": m.group(2), "secret_name": m.group(3)}

    return None


# ─────────────────────────────────────────────
# GitHub secret encryption
# ─────────────────────────────────────────────

def encrypt_secret(public_key_b64, secret_value):
    """Encrypt a secret value with the GitHub repo/org public key (libsodium sealed box)."""
    pub_key = public.PublicKey(public_key_b64.encode(), encoding.Base64Encoder)
    sealed_box = public.SealedBox(pub_key)
    encrypted = sealed_box.encrypt(secret_value.encode())
    return base64.b64encode(encrypted).decode()


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def gh_request(method, url, token, body=None):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    resp = requests.request(method, url, headers=headers, json=body)
    return resp.status_code, resp.json() if resp.content else {}


def get_org_public_key(api_url, org, token):
    status, data = gh_request("GET", f"{api_url}/orgs/{org}/actions/secrets/public-key", token)
    if status != 200:
        raise RuntimeError(f"Failed to get org public key: {data.get('message')}")
    return data["key_id"], data["key"]


def get_repo_public_key(api_url, org, repo, token):
    status, data = gh_request("GET", f"{api_url}/repos/{org}/{repo}/actions/secrets/public-key", token)
    if status != 200:
        raise RuntimeError(f"Failed to get repo public key for {repo}: {data.get('message')}")
    return data["key_id"], data["key"]


def get_env_public_key(api_url, org, repo, env_name, token):
    status, data = gh_request("GET", f"{api_url}/repos/{org}/{repo}/environments/{env_name}/secrets/public-key", token)
    if status != 200:
        raise RuntimeError(f"Failed to get env public key for {repo}/{env_name}: {data.get('message')}")
    return data["key_id"], data["key"]


def ensure_environment_exists(api_url, org, repo, env_name, token):
    """Create the environment if it doesn't exist yet."""
    status, _ = gh_request("GET", f"{api_url}/repos/{org}/{repo}/environments/{env_name}", token)
    if status != 200:
        gh_request("PUT", f"{api_url}/repos/{org}/{repo}/environments/{env_name}", token, {})


def create_or_update_org_secret(api_url, org, token, secret_name, encrypted_value, key_id, visibility="all"):
    body = {
        "encrypted_value": encrypted_value,
        "key_id": key_id,
        "visibility": visibility,
    }
    status, data = gh_request("PUT", f"{api_url}/orgs/{org}/actions/secrets/{secret_name}", token, body)
    return status in (201, 204), data.get("message", "")


def create_or_update_repo_secret(api_url, org, repo, token, secret_name, encrypted_value, key_id):
    body = {"encrypted_value": encrypted_value, "key_id": key_id}
    status, data = gh_request("PUT", f"{api_url}/repos/{org}/{repo}/actions/secrets/{secret_name}", token, body)
    return status in (201, 204), data.get("message", "")


def create_or_update_env_secret(api_url, org, repo, env_name, token, secret_name, encrypted_value, key_id):
    body = {"encrypted_value": encrypted_value, "key_id": key_id}
    status, data = gh_request(
        "PUT",
        f"{api_url}/repos/{org}/{repo}/environments/{env_name}/secrets/{secret_name}",
        token,
        body,
    )
    return status in (201, 204), data.get("message", "")


# ─────────────────────────────────────────────
# Main restoration logic
# ─────────────────────────────────────────────

def restore_secrets(args):
    api_url = args.api_url.rstrip("/")
    results = {"success": [], "failed": [], "skipped": []}

    # ── Step 1: Authenticate to CyberArk ──────────────────────────────────
    print(f"Authenticating to CyberArk: {args.cyberark_url}")
    try:
        ca_token = cyberark_logon(args.cyberark_url, args.cyberark_username, args.cyberark_password)
    except Exception as e:
        print(f"ERROR: CyberArk authentication failed: {e}", file=sys.stderr)
        sys.exit(1)
    print("Authenticated to CyberArk.\n")

    try:
        # ── Step 2: Fetch all matching accounts ───────────────────────────
        search_prefix = f"GH-{args.source_org}"
        print(f"Searching CyberArk safe '{args.cyberark_safe}' for accounts matching: {search_prefix}")
        accounts = cyberark_search_accounts(args.cyberark_url, ca_token, args.cyberark_safe, search_prefix)
        print(f"Found {len(accounts)} account(s).\n")

        if not accounts:
            print("No accounts found. Check the safe name and source org.")
            return results

        # ── Step 3: Parse + group by type ─────────────────────────────────
        parsed = []
        for acc in accounts:
            name = acc.get("name", "")
            components = parse_account_name(name, args.source_org)
            if not components:
                print(f"  [SKIP] Cannot parse account name: {name}")
                results["skipped"].append((name, "unparseable name"))
                continue
            if args.filter_repo and components["repo"] != args.filter_repo:
                continue
            parsed.append((acc["id"], name, components))

        # Summary by type
        by_type = defaultdict(int)
        for _, _, c in parsed:
            by_type[c["type"]] += 1
        print(f"Accounts to restore: org={by_type['org']} repo={by_type['repo']} env={by_type['env']}\n")

        # ── Step 4: Cache public keys to avoid redundant API calls ─────────
        org_pubkey_cache = {}    # org -> (key_id, key)
        repo_pubkey_cache = {}   # repo -> (key_id, key)
        env_pubkey_cache = {}    # (repo, env) -> (key_id, key)

        def get_cached_org_key():
            if args.dest_org not in org_pubkey_cache:
                org_pubkey_cache[args.dest_org] = get_org_public_key(api_url, args.dest_org, args.dest_token)
            return org_pubkey_cache[args.dest_org]

        def get_cached_repo_key(repo):
            if repo not in repo_pubkey_cache:
                repo_pubkey_cache[repo] = get_repo_public_key(api_url, args.dest_org, repo, args.dest_token)
            return repo_pubkey_cache[repo]

        def get_cached_env_key(repo, env_name):
            k = (repo, env_name)
            if k not in env_pubkey_cache:
                env_pubkey_cache[k] = get_env_public_key(api_url, args.dest_org, repo, env_name, args.dest_token)
            return env_pubkey_cache[k]

        # ── Step 5: Restore each secret ───────────────────────────────────
        total = len(parsed)
        for i, (account_id, account_name, components) in enumerate(parsed, 1):
            secret_name = components["secret_name"]
            secret_type = components["type"]
            repo = components["repo"]
            env_name = components["env_name"]

            label = {
                "org":  f"[org]  {args.dest_org} / {secret_name}",
                "repo": f"[repo] {args.dest_org}/{repo} / {secret_name}",
                "env":  f"[env]  {args.dest_org}/{repo} ({env_name}) / {secret_name}",
            }[secret_type]

            print(f"  [{i}/{total}] {label}")

            if args.dry_run:
                print(f"          -> [DRY RUN] would restore from account: {account_name}")
                results["success"].append((account_name, "dry-run"))
                continue

            # Fetch value from CyberArk
            try:
                value = cyberark_get_password(args.cyberark_url, ca_token, account_id)
            except Exception as e:
                print(f"          -> ERROR fetching from CyberArk: {e}")
                results["failed"].append((account_name, f"CyberArk fetch error: {e}"))
                continue

            # Encrypt and push to GitHub
            try:
                if secret_type == "org":
                    key_id, pub_key = get_cached_org_key()
                    encrypted = encrypt_secret(pub_key, value)
                    ok, msg = create_or_update_org_secret(
                        api_url, args.dest_org, args.dest_token, secret_name, encrypted, key_id
                    )
                elif secret_type == "repo":
                    key_id, pub_key = get_cached_repo_key(repo)
                    encrypted = encrypt_secret(pub_key, value)
                    ok, msg = create_or_update_repo_secret(
                        api_url, args.dest_org, repo, args.dest_token, secret_name, encrypted, key_id
                    )
                else:  # env
                    ensure_environment_exists(api_url, args.dest_org, repo, env_name, args.dest_token)
                    key_id, pub_key = get_cached_env_key(repo, env_name)
                    encrypted = encrypt_secret(pub_key, value)
                    ok, msg = create_or_update_env_secret(
                        api_url, args.dest_org, repo, env_name, args.dest_token,
                        secret_name, encrypted, key_id
                    )

                if ok:
                    print(f"          -> OK")
                    results["success"].append((account_name, "created/updated"))
                else:
                    print(f"          -> FAILED: {msg}")
                    results["failed"].append((account_name, msg))

            except Exception as e:
                print(f"          -> ERROR: {e}")
                results["failed"].append((account_name, str(e)))

    finally:
        cyberark_logoff(args.cyberark_url, ca_token)
        print("\nLogged off from CyberArk.")

    return results


def print_summary(results):
    total = len(results["success"]) + len(results["failed"]) + len(results["skipped"])
    print(f"\n{'='*60}")
    print(f"SUMMARY  Total: {total}  |  OK: {len(results['success'])}  |  Failed: {len(results['failed'])}  |  Skipped: {len(results['skipped'])}")

    if results["failed"]:
        print("\nFailed:")
        for name, msg in results["failed"]:
            print(f"  [FAIL] {name}: {msg}")

    if results["skipped"]:
        print("\nSkipped:")
        for name, msg in results["skipped"]:
            print(f"  [SKIP] {name}: {msg}")


def main():
    parser = argparse.ArgumentParser(
        description="Restore GitHub secrets from CyberArk to a destination org"
    )
    # CyberArk
    parser.add_argument("--cyberark-url", required=True,
                        help="CyberArk PVWA base URL (e.g. https://cyberark.example.com)")
    parser.add_argument("--cyberark-username", required=True)
    parser.add_argument("--cyberark-password", required=True)
    parser.add_argument("--cyberark-safe", required=True,
                        help="Safe name where the secrets were imported")
    # GitHub
    parser.add_argument("--source-org", required=True,
                        help="Source org name (used to match account names in CyberArk)")
    parser.add_argument("--dest-org", required=True,
                        help="Destination org name on GitHub.com")
    parser.add_argument("--dest-token", required=True,
                        help="GitHub PAT for the destination org (needs secrets write scope)")
    parser.add_argument("--api-url", default="https://api.github.com",
                        help="GitHub API base URL (default: https://api.github.com)")
    # Filters
    parser.add_argument("--filter-repo",
                        help="Only restore secrets for a specific repo (optional)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Simulate without writing anything to GitHub")

    args = parser.parse_args()

    print(f"""
Secret restoration plan
  Source org   : {args.source_org}
  Dest org     : {args.dest_org}
  CyberArk safe: {args.cyberark_safe}
  API URL      : {args.api_url}
  Dry run      : {args.dry_run}
  Filter repo  : {args.filter_repo or '(all)'}
""")

    results = restore_secrets(args)
    print_summary(results)

    if results["failed"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
