#!/usr/bin/env python3
"""
For each repo in an org, lists ALL three types of GitHub Actions secrets:
  - Org-level secrets
  - Repo-level secrets
  - Environment secrets (per environment in each repo)

Generates a workflow per repo that:
  1. Reads each secret value via env var
  2. Authenticates to CyberArk PVWA
  3. Creates/updates an account in CyberArk with a structured identifier:
       GH-{ORG}-{REPO}-{TYPE}-{SECRET_NAME}
       where TYPE = "org" | "repo" | "env-{ENV_NAME}"

Pushes the workflow to each repo via GitHub API (no git clone needed).

Usage:
    python deploy-cyberark-importer.py --org <ORG> --token <TOKEN> [options]

CyberArk secrets required in each repo (or org-level):
    CYBERARK_URL       - PVWA base URL (e.g. https://cyberark.example.com)
    CYBERARK_USERNAME  - CyberArk auth username
    CYBERARK_PASSWORD  - CyberArk auth password
    CYBERARK_SAFE      - Target safe name in CyberArk
"""

import argparse
import base64
import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib.request
import urllib.error


WORKFLOW_FILENAME = ".github/workflows/import-to-cyberark.yml"
COMMIT_MESSAGE = "chore: add temporary CyberArk secret import workflow"
CLEANUP_MESSAGE = "chore: remove temporary CyberArk secret import workflow"


# ─────────────────────────────────────────────
# GitHub API helpers
# ─────────────────────────────────────────────

def api_request(method, url, token, body=None):
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode())
        except Exception:
            return e.code, {"message": str(e)}


def paginate(url, token, unwrap_key=None):
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        status, data = api_request("GET", f"{url}{sep}per_page=100&page={page}", token)
        if status != 200:
            return results
        if isinstance(data, list):
            results.extend(data)
            if len(data) < 100:
                break
        elif isinstance(data, dict):
            key = unwrap_key or next(
                (k for k in ("secrets", "environments", "repositories") if k in data), None
            )
            if key and key in data:
                chunk = data[key]
                results.extend(chunk)
                if len(chunk) < 100:
                    return results
            else:
                results.append(data)
                break
        page += 1
    return results


def get_repos(org, token, api_url, include_archived):
    repos = paginate(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_org_secret_names(org, token, api_url):
    """Org-level secrets visible to repos."""
    secrets = paginate(f"{api_url}/orgs/{org}/actions/secrets", token, unwrap_key="secrets")
    return [s["name"] for s in secrets]


def get_repo_secret_names(org, repo, token, api_url):
    """Repo-level secrets."""
    secrets = paginate(f"{api_url}/repos/{org}/{repo}/actions/secrets", token, unwrap_key="secrets")
    return [s["name"] for s in secrets]


def get_environments(org, repo, token, api_url):
    """List environment names for a repo."""
    envs = paginate(f"{api_url}/repos/{org}/{repo}/environments", token, unwrap_key="environments")
    return [e["name"] for e in envs]


def get_environment_secret_names(org, repo, env, token, api_url):
    """Environment-level secrets."""
    secrets = paginate(
        f"{api_url}/repos/{org}/{repo}/environments/{env}/secrets",
        token,
        unwrap_key="secrets",
    )
    return [s["name"] for s in secrets]


def collect_all_secrets(org, repo, org_secrets, token, api_url):
    """
    Returns a dict:
    {
      "org":  ["SECRET_A", ...],
      "repo": ["SECRET_B", ...],
      "env":  {"env_name": ["SECRET_C", ...], ...}
    }
    """
    repo_secrets = get_repo_secret_names(org, repo, token, api_url)
    environments = get_environments(org, repo, token, api_url)

    env_secrets = {}
    for env in environments:
        names = get_environment_secret_names(org, repo, env, token, api_url)
        if names:
            env_secrets[env] = names

    return {
        "org": org_secrets,
        "repo": repo_secrets,
        "env": env_secrets,
    }


# ─────────────────────────────────────────────
# Workflow generation
# ─────────────────────────────────────────────

def _env_block(secrets_by_type):
    """Build the `env:` block with all secrets across all types."""
    lines = []

    # Org secrets
    for name in secrets_by_type.get("org", []):
        lines.append(f"      ORG__{name}: ${{{{ secrets.{name} }}}}")

    # Repo secrets
    for name in secrets_by_type.get("repo", []):
        lines.append(f"      REPO__{name}: ${{{{ secrets.{name} }}}}")

    # Environment secrets — must be accessed inside a job with `environment:`
    # We generate a separate job per environment for those.

    return "\n".join(lines)


def _cyberark_push_script(org, repo, secret_type, env_name=None):
    """
    Bash snippet that iterates env vars with a given prefix and pushes to CyberArk.
    secret_type: "org" | "repo" | "env"
    """
    if secret_type == "org":
        prefix = "ORG__"
        ca_type_label = "org"
        ca_identifier_prefix = f"GH-{org}-ORG"
    elif secret_type == "repo":
        prefix = "REPO__"
        ca_type_label = "repo"
        ca_identifier_prefix = f"GH-{org}-{repo}-REPO"
    else:  # env
        prefix = f"ENV__{env_name}__"
        ca_type_label = f"env-{env_name}"
        ca_identifier_prefix = f"GH-{org}-{repo}-ENV-{env_name}"

    return f"""
          echo "--- Pushing {ca_type_label} secrets to CyberArk ---"
          while IFS='=' read -r key value; do
            [[ "$key" != {prefix}* ]] && continue
            [ -z "$value" ] && continue
            SECRET_NAME="${{key#{prefix}}}"
            OBJECT_NAME="{ca_identifier_prefix}-$SECRET_NAME"

            echo "  Creating/updating: $OBJECT_NAME"

            # Check if account already exists
            SEARCH=$(curl -s -X GET \\
              -H "Authorization: $CA_TOKEN" \\
              -H "Content-Type: application/json" \\
              "$CYBERARK_URL/PasswordVault/API/Accounts?search=$OBJECT_NAME&searchType=contains")

            EXISTING_ID=$(echo "$SEARCH" | jq -r '.value[0].id // empty')

            if [ -n "$EXISTING_ID" ]; then
              # Update existing account password
              curl -s -X POST \\
                -H "Authorization: $CA_TOKEN" \\
                -H "Content-Type: application/json" \\
                -d "{\\"NewCredentials\\": \\"$value\\"}" \\
                "$CYBERARK_URL/PasswordVault/API/Accounts/$EXISTING_ID/Password/Update" > /dev/null
              echo "    Updated: $OBJECT_NAME"
            else
              # Create new account
              PAYLOAD=$(jq -n \\
                --arg safe "$CYBERARK_SAFE" \\
                --arg name "$OBJECT_NAME" \\
                --arg addr "github.com" \\
                --arg user "$SECRET_NAME" \\
                --arg pass "$value" \\
                --arg platform "WinServerLocal" \\
                '{{
                  safeName: $safe,
                  name: $name,
                  address: $addr,
                  userName: $user,
                  secret: $pass,
                  secretType: "password",
                  platformId: $platform,
                  platformAccountProperties: {{}}
                }}')

              RESPONSE=$(curl -s -w "\\n%{{http_code}}" -X POST \\
                -H "Authorization: $CA_TOKEN" \\
                -H "Content-Type: application/json" \\
                -d "$PAYLOAD" \\
                "$CYBERARK_URL/PasswordVault/API/Accounts")

              HTTP_CODE=$(echo "$RESPONSE" | tail -1)
              if [ "$HTTP_CODE" = "201" ]; then
                echo "    Created: $OBJECT_NAME"
              else
                echo "    ::warning:: Failed to create $OBJECT_NAME (HTTP $HTTP_CODE)"
              fi
            fi
          done < <(env)"""


def generate_workflow(org, repo, secrets_by_type):
    """Generate the full workflow YAML for a repo."""

    has_org_or_repo = bool(secrets_by_type.get("org") or secrets_by_type.get("repo"))
    env_secrets = secrets_by_type.get("env", {})

    if not has_org_or_repo and not env_secrets:
        return None

    parts = [f"""name: Import Secrets to CyberArk (TEMPORARY - DELETE AFTER USE)
on:
  workflow_dispatch:
    inputs:
      cyberark_safe:
        description: "CyberArk safe name"
        required: true
        type: string

env:
  CYBERARK_URL: ${{{{ secrets.CYBERARK_URL }}}}
  CYBERARK_SAFE: ${{{{ github.event.inputs.cyberark_safe }}}}

jobs:"""]

    # ── Job 1: org + repo secrets ──────────────────────────────────────────
    if has_org_or_repo:
        env_block_lines = []
        for name in secrets_by_type.get("org", []):
            env_block_lines.append(f"      ORG__{name}: ${{{{ secrets.{name} }}}}")
        for name in secrets_by_type.get("repo", []):
            env_block_lines.append(f"      REPO__{name}: ${{{{ secrets.{name} }}}}")

        env_block = "\n".join(env_block_lines)

        org_push = _cyberark_push_script(org, repo, "org")
        repo_push = _cyberark_push_script(org, repo, "repo")

        parts.append(f"""
  import-org-and-repo-secrets:
    runs-on: ubuntu-latest
    env:
      CYBERARK_USERNAME: ${{{{ secrets.CYBERARK_USERNAME }}}}
      CYBERARK_PASSWORD: ${{{{ secrets.CYBERARK_PASSWORD }}}}
{env_block}
    steps:
      - name: Authenticate to CyberArk
        run: |
          CA_TOKEN=$(curl -s -X POST \\
            -H "Content-Type: application/json" \\
            -d '{{\\"username\\":\\"$CYBERARK_USERNAME\\",\\"password\\":\\"$CYBERARK_PASSWORD\\"}}' \\
            "$CYBERARK_URL/PasswordVault/API/auth/CyberArk/Logon" | tr -d '"')
          echo "CA_TOKEN=$CA_TOKEN" >> $GITHUB_ENV

      - name: Push secrets to CyberArk
        run: |{org_push}
{repo_push}

      - name: Logoff CyberArk
        if: always()
        run: |
          curl -s -X POST \\
            -H "Authorization: $CA_TOKEN" \\
            "$CYBERARK_URL/PasswordVault/API/Auth/Logoff" > /dev/null""")

    # ── Job per environment ────────────────────────────────────────────────
    for env_name, secret_names in env_secrets.items():
        safe_job_name = env_name.lower().replace(" ", "-").replace("_", "-")
        env_block_lines = []
        for name in secret_names:
            env_block_lines.append(f"      ENV__{env_name}__{name}: ${{{{ secrets.{name} }}}}")
        env_block = "\n".join(env_block_lines)
        env_push = _cyberark_push_script(org, repo, "env", env_name)

        parts.append(f"""
  import-env-{safe_job_name}-secrets:
    runs-on: ubuntu-latest
    environment: {env_name}
    env:
      CYBERARK_USERNAME: ${{{{ secrets.CYBERARK_USERNAME }}}}
      CYBERARK_PASSWORD: ${{{{ secrets.CYBERARK_PASSWORD }}}}
{env_block}
    steps:
      - name: Authenticate to CyberArk
        run: |
          CA_TOKEN=$(curl -s -X POST \\
            -H "Content-Type: application/json" \\
            -d '{{\\"username\\":\\"$CYBERARK_USERNAME\\",\\"password\\":\\"$CYBERARK_PASSWORD\\"}}' \\
            "$CYBERARK_URL/PasswordVault/API/auth/CyberArk/Logon" | tr -d '"')
          echo "CA_TOKEN=$CA_TOKEN" >> $GITHUB_ENV

      - name: Push environment secrets ({env_name}) to CyberArk
        run: |{env_push}

      - name: Logoff CyberArk
        if: always()
        run: |
          curl -s -X POST \\
            -H "Authorization: $CA_TOKEN" \\
            "$CYBERARK_URL/PasswordVault/API/Auth/Logoff" > /dev/null""")

    return "\n".join(parts) + "\n"


# ─────────────────────────────────────────────
# GitHub file push helpers
# ─────────────────────────────────────────────

def get_file_sha(org, repo, token, api_url, path):
    status, data = api_request("GET", f"{api_url}/repos/{org}/{repo}/contents/{path}", token)
    if status == 200:
        return data.get("sha")
    return None


def push_file(org, repo, token, api_url, path, content_str, message, dry_run):
    if dry_run:
        return True, "dry-run"
    sha = get_file_sha(org, repo, token, api_url, path)
    body = {
        "message": message,
        "content": base64.b64encode(content_str.encode()).decode(),
    }
    if sha:
        body["sha"] = sha
    status, data = api_request("PUT", f"{api_url}/repos/{org}/{repo}/contents/{path}", token, body)
    if status in (200, 201):
        return True, "updated" if sha else "created"
    return False, data.get("message", f"HTTP {status}")


def delete_file(org, repo, token, api_url, path, message, dry_run):
    if dry_run:
        return True, "dry-run"
    sha = get_file_sha(org, repo, token, api_url, path)
    if not sha:
        return True, "not found (skipped)"
    body = {"message": message, "sha": sha}
    status, data = api_request("DELETE", f"{api_url}/repos/{org}/{repo}/contents/{path}", token, body)
    if status == 200:
        return True, "deleted"
    return False, data.get("message", f"HTTP {status}")


# ─────────────────────────────────────────────
# Per-repo pipeline
# ─────────────────────────────────────────────

def process_repo(org, repo, org_secrets, token, api_url, dry_run, cleanup):
    if cleanup:
        ok, msg = delete_file(org, repo, token, api_url, WORKFLOW_FILENAME, CLEANUP_MESSAGE, dry_run)
        return repo, ok, msg

    secrets = collect_all_secrets(org, repo, org_secrets, token, api_url)

    total = len(secrets["org"]) + len(secrets["repo"]) + sum(len(v) for v in secrets["env"].values())
    if total == 0:
        return repo, True, "no secrets (skipped)"

    summary = (
        f"org={len(secrets['org'])} "
        f"repo={len(secrets['repo'])} "
        f"env={sum(len(v) for v in secrets['env'].values())} "
        f"({len(secrets['env'])} environments)"
    )

    workflow_yaml = generate_workflow(org, repo, secrets)
    if not workflow_yaml:
        return repo, True, "no secrets (skipped)"

    ok, msg = push_file(org, repo, token, api_url, WORKFLOW_FILENAME, workflow_yaml, COMMIT_MESSAGE, dry_run)
    return repo, ok, f"{msg} — {summary}"


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Deploy CyberArk secret importer workflow to all repos in a GitHub org"
    )
    parser.add_argument("--org", required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--api-url", default="https://api.github.com")
    parser.add_argument("--concurrency", type=int, default=10)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--include-archived", action="store_true")
    parser.add_argument("--cleanup", action="store_true",
                        help="Remove the workflow from all repos")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")

    print(f"Fetching repos for org: {args.org}")
    repos = get_repos(args.org, args.token, api_url, args.include_archived)
    print(f"Found {len(repos)} repos.\n")

    # Fetch org secrets once (shared across all repos)
    print("Fetching org-level secrets...")
    org_secrets = get_org_secret_names(args.org, args.token, api_url)
    print(f"Org secrets: {len(org_secrets)}\n")

    successes, failures = [], []

    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {
            executor.submit(
                process_repo, args.org, repo, org_secrets, args.token, api_url, args.dry_run, args.cleanup
            ): repo
            for repo in repos
        }
        done = 0
        for future in as_completed(futures):
            done += 1
            repo_name, ok, message = future.result()
            icon = "✓" if ok else "✗"
            print(f"  [{done}/{len(repos)}] {icon} {repo_name}: {message}")
            (successes if ok else failures).append((repo_name, message))

    print(f"\n{'='*60}")
    print(f"Done. Success: {len(successes)}  Failed: {len(failures)}")

    if failures:
        print("\nFailed repos:")
        for repo, msg in failures:
            print(f"  - {repo}: {msg}")

    if not args.cleanup and not args.dry_run:
        print(f"""
Next steps:
  1. Ensure these secrets exist in your org (or each repo):
       CYBERARK_URL, CYBERARK_USERNAME, CYBERARK_PASSWORD

  2. Trigger the workflow in each repo:
       gh api /orgs/{args.org}/repos --paginate -q '.[].name' | \\
         xargs -P 5 -I {{}} gh workflow run import-to-cyberark.yml \\
           --repo {args.org}/{{}} \\
           --field cyberark_safe=YOUR_SAFE_NAME

  3. Verify accounts were created in CyberArk

  4. Cleanup — remove workflows from all repos:
       python {sys.argv[0]} --org {args.org} --token <TOKEN> --cleanup

CyberArk account naming convention:
  Org secrets:  GH-{args.org}-ORG-<SECRET_NAME>
  Repo secrets: GH-{args.org}-<REPO>-REPO-<SECRET_NAME>
  Env secrets:  GH-{args.org}-<REPO>-ENV-<ENV_NAME>-<SECRET_NAME>
""")


if __name__ == "__main__":
    main()
