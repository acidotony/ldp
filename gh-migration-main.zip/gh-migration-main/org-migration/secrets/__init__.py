"""
secrets — GitHub Secrets migration utilities (CyberArk integration).

Exposed functions:
    list_repos_with_secrets(api_url, org, token, include_archived) -> list[dict]
    deploy_cyberark_importer(args)  -> (success, failed)
    restore_secrets(args)           -> dict {success, failed, skipped}
"""

import importlib.util
import pathlib
from types import SimpleNamespace

_HERE = pathlib.Path(__file__).parent


def _load(filename):
    spec = importlib.util.spec_from_file_location(filename, _HERE / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def list_repos_with_secrets(
    api_url, org, token, include_archived=False, concurrency=10
):
    """
    Scan all repos in an org and return those that have secrets.
    Returns list of dicts: {repo, secret_count, secret_names}
    """
    mod = _load("list-repos-with-secrets.py")
    repos = mod.get_all_repos(org, token, api_url, include_archived)

    import concurrent.futures
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as ex:
        futures = {
            ex.submit(mod.get_repo_secret_count, org, repo, token, api_url): repo
            for repo in repos
        }
        for future in concurrent.futures.as_completed(futures):
            repo_name, count, names = future.result()
            if count > 0:
                results.append({
                    "repo": repo_name,
                    "secret_count": count,
                    "secret_names": names,
                })

    results.sort(key=lambda r: r["repo"])
    return results


def deploy_cyberark_importer(
    org, token, cyberark_url=None, cyberark_username=None, cyberark_password=None,
    cyberark_safe=None, api_url="https://api.github.com",
    concurrency=10, dry_run=False, include_archived=False, cleanup=False,
):
    """
    Generate and push the CyberArk importer workflow to every repo in the org.
    Returns (success_list, failed_list).
    """
    mod = _load("deploy-cyberark-importer.py")

    org_secrets = mod.get_org_secret_names(org, token, api_url)
    repos = mod.get_repos(org, token, api_url, include_archived)

    import concurrent.futures
    success, failed = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as ex:
        futures = {
            ex.submit(
                mod.process_repo, org, repo, org_secrets, token, api_url, dry_run, cleanup
            ): repo
            for repo in repos
        }
        for future in concurrent.futures.as_completed(futures):
            repo_name, ok, msg = future.result()
            (success if ok else failed).append((repo_name, msg))

    return success, failed


def restore_from_cyberark(
    cyberark_url, cyberark_username, cyberark_password, cyberark_safe,
    source_org, dest_org, dest_token,
    api_url="https://api.github.com", filter_repo=None, dry_run=False,
):
    """
    Read secrets from CyberArk and recreate them in the destination GitHub org.
    Returns dict: {success: [...], failed: [...], skipped: [...]}
    """
    mod = _load("restore-secrets-from-cyberark.py")

    args = SimpleNamespace(
        cyberark_url=cyberark_url,
        cyberark_username=cyberark_username,
        cyberark_password=cyberark_password,
        cyberark_safe=cyberark_safe,
        source_org=source_org,
        dest_org=dest_org,
        dest_token=dest_token,
        api_url=api_url,
        filter_repo=filter_repo,
        dry_run=dry_run,
    )

    return mod.restore_secrets(args)
