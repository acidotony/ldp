#!/bin/bash

# find-duplicates.sh
#
# Purpose:
#   Identifies duplicate repository names between HCSC-Pilot and HCSC-XP organizations
#   to help detect potential naming conflicts before migration. Both orgs will be 
#   migrated to the same destination org (hcsc-core), so duplicate names must be resolved.
#
# Usage:
#   ./find-duplicates.sh <csv-file>
#
# Arguments:
#   csv-file: Tab-separated file with columns: Organization, Repository
#             Example: HCSC-Pilot\trepo-name
#
# Prerequisites:
#   - Input CSV/TSV file with org and repo columns
#   - awk, grep, sort, uniq utilities (standard on Unix systems)
#
# Output:
#   - Console output listing duplicate repository names
#   - duplicate_repos.csv: Detailed CSV report of duplicates
#   - Temporary files (pilot_repos.tmp, xp_repos.tmp) are cleaned up automatically
#
# Example:
#   ./find-duplicates.sh migration-repos.csv
#

CSV_FILE="$1"

if [[ -z "$CSV_FILE" ]]; then
  echo "Usage: $0 <csv-file>"
  exit 1
fi

echo "Extracting repositories from HCSC-Pilot and HCSC-XP..."

# Extract repositories from HCSC-Pilot
pilot_repos=$(awk -F'\t' '$1 == "HCSC-Pilot" {print $2}' "$CSV_FILE")
echo "Found $(echo "$pilot_repos" | wc -l | tr -d ' ') repositories in HCSC-Pilot"

# Extract repositories from HCSC-XP
xp_repos=$(awk -F'\t' '$1 == "HCSC-XP" {print $2}' "$CSV_FILE")
echo "Found $(echo "$xp_repos" | wc -l | tr -d ' ') repositories in HCSC-XP"

# Create temporary files
echo "$pilot_repos" > pilot_repos.tmp
echo "$xp_repos" > xp_repos.tmp

# Find duplicates
echo -e "\nChecking for duplicate repository names..."
duplicates=$(sort pilot_repos.tmp xp_repos.tmp | uniq -d)

if [[ -z "$duplicates" ]]; then
  echo "No duplicate repository names found between HCSC-Pilot and HCSC-XP."
else
  echo -e "\nFound the following duplicate repository names:"
  echo "$duplicates"
  
  echo -e "\nDetailed information about duplicate repositories:"
  echo "Repository Name,HCSC-Pilot,HCSC-XP" > duplicate_repos.csv
  
  while IFS= read -r repo; do
    pilot_exists=$(grep -q "^HCSC-Pilot[[:space:]]*$repo" "$CSV_FILE" && echo "Yes" || echo "No")
    xp_exists=$(grep -q "^HCSC-XP[[:space:]]*$repo" "$CSV_FILE" && echo "Yes" || echo "No")
    echo "$repo,$pilot_exists,$xp_exists" >> duplicate_repos.csv
  done <<< "$duplicates"
  
  echo "Detailed information saved to duplicate_repos.csv"
fi

# Clean up temporary files
rm -f pilot_repos.tmp xp_repos.tmp

echo -e "\nDone!"