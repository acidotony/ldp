# GitHub Migration Toolkit

This repository provides tools and workflows to help automate the migration of multiple repositories between GitHub organizations, including support for both GitHub Enterprise Server (GHES) and GitHub Enterprise Cloud (GHEC).

> **⚠️ IMPORTANT**: Always run the [Preflight Migration Validation Workflow](#preflight-migration-validation-workflow-githubworkflowspreflight-migration-validationyml) **before** running the [Migration Workflow](#migration-workflow-githubworkflowsmigrate-waveyml). The preflight validation ensures repositories are ready for migration, tokens have proper permissions, and no conflicts exist.

## Table of Contents

- [GitHub Migration Toolkit](#github-migration-toolkit)
  - [Table of Contents](#table-of-contents)
  - [Workflows](#workflows)
    - [Preflight Migration Validation Workflow (`.github/workflows/preflight-migration-validation.yml`)](#preflight-migration-validation-workflow-githubworkflowspreflight-migration-validationyml)
      - [Validation Features](#validation-features)
      - [Validation Inputs](#validation-inputs)
      - [Validation Jobs](#validation-jobs)
      - [Preflight Checks](#preflight-checks)
    - [Migration Workflow with Team Assignment (`.github/workflows/migrate-wave.yml`)](#migration-workflow-with-team-assignment-githubworkflowsmigrate-waveyml)
      - [Features](#features)
      - [Inputs](#inputs)
      - [Migration File Format](#migration-file-format)
      - [Workflow Jobs](#workflow-jobs)
      - [Workflow Usage](#workflow-usage)
      - [Workflow Requirements](#workflow-requirements)
    - [Migration Workflow without Team Assignment (`.github/workflows/migrate-wave-no-teams.yml`)](#migration-workflow-without-team-assignment-githubworkflowsmigrate-wave-no-teamsyml)
      - [Migration-Only Features](#migration-only-features)
      - [Migration-Only Inputs](#migration-only-inputs)
      - [Migration-Only Jobs](#migration-only-jobs)
      - [Migration-Only Usage](#migration-only-usage)
    - [Team Assignment Workflow (`.github/workflows/assign-teams.yml`)](#team-assignment-workflow-githubworkflowsassign-teamsyml)
      - [Team Assignment Features](#team-assignment-features)
      - [Team Assignment Inputs](#team-assignment-inputs)
      - [Team Assignment Jobs](#team-assignment-jobs)
      - [Team Assignment Usage](#team-assignment-usage)
    - [Rollback Workflow (`.github/workflows/migrate-rollback.yml`)](#rollback-workflow-githubworkflowsmigrate-rollbackyml)
      - [Rollback Workflow Features](#rollback-workflow-features)
      - [Rollback Workflow Inputs](#rollback-workflow-inputs)
      - [Rollback Workflow Jobs](#rollback-workflow-jobs)
    - [Reclaim Mannequins Workflow (`.github/workflows/reclaim-mannequins.yml`)](#reclaim-mannequins-workflow-githubworkflowsreclaim-mannequinsyml)
      - [Reclaim Mannequins Features](#reclaim-mannequins-features)
      - [Reclaim Mannequins Inputs](#reclaim-mannequins-inputs)
      - [Reclaim Mannequins Jobs](#reclaim-mannequins-jobs)
      - [Reclaim Mannequins Usage](#reclaim-mannequins-usage)
      - [CSV Format](#csv-format)
      - [Important Notes](#important-notes)
  - [References](#references)

## Workflows

### Preflight Migration Validation Workflow (`.github/workflows/preflight-migration-validation.yml`)

The preflight validation workflow runs comprehensive checks before migration to ensure repositories are ready and tokens have proper permissions.

#### Validation Features

- **Repository file validation**: Verifies the migration file exists and is readable
- **Token scope validation**: Checks that source and destination tokens have required permissions (`repo`, `workflow`, `admin:org`, `read:enterprise`, `delete_repo`)
- **Previous migration check**: Ensures repositories haven't already been migrated to avoid conflicts
- **Secret scanning validation**: Blocks migration of repositories with open secret scanning alerts
- **App ID and team validation**: Extracts App ID tags from repository topics and validates that required role teams exist in destination organizations

#### Validation Inputs

- `source_ghes_api_url`: Source API URL (choice: test GHES, prod GHES, or GitHub.com)
- `destination_api_url`: Destination API URL (optional)
- `repo_file`: Path to migration file (default: `migrate-wave-test.txt`)
- `max_concurrent`: Maximum concurrent operations (default: 10)

#### Validation Jobs

All validation jobs run in parallel except where dependencies exist:

1. **validate-repo-file**: Checks that the migration file exists (runs first)
2. **validate-source-token**: Verifies source token has required scopes
3. **validate-destination-token**: Verifies destination token has required scopes
4. **extract-destination-orgs**: Extracts unique destination organizations from the migration file
5. **validate-repo-list-for-no-prev-migrations**: Ensures repos don't already exist in destination
6. **validate-repo-list-for-no-secrets**: Blocks repos with open secret scanning alerts
7. **validate-source-repos**: Validates source repository names and checks if they are archived
8. **validate-teams-and-app-ids**: Validates App ID tags and checks for required teams in destination organizations

#### Preflight Checks

The preflight validation performs comprehensive checks before migration:

**Repository Validation**

- Verifies migration file exists and is readable
- Validates source repository names exist in source organizations
- Checks if source repositories are already archived
- Ensures target repositories don't already exist in destination organizations

**Token Validation**

- Validates both source and destination tokens have all required scopes:
  - `repo`, `workflow`, `admin:org`, `read:enterprise`, `delete_repo`
- Accepts `admin:enterprise` as alternative to `read:enterprise`
- Works with both GitHub.com and GitHub Enterprise Server

**Security Compliance**

- Scans all source organizations for open secret scanning alerts
- Blocks repositories with open secret scanning alerts from being migrated
- Requires organization admin access to check secret scanning at org level
- Generates detailed CSV reports of findings

**Team Readiness**

- Extracts App ID tags from repository topics in source
- Validates that corresponding role teams exist in destination organizations
- Checks for all four required role types: developer, approver, cicd_maintain, cicd_lead
- Reports which teams are missing and need to be created

All checks must pass before proceeding with migration. The workflow generates detailed job summaries showing:

- Repositories ready for migration
- Previously migrated repositories (if any)
- Security vulnerabilities detected (if any)
- Invalid or archived source repositories (if any)
- Team mapping readiness status

### Migration Workflow with Team Assignment (`.github/workflows/migrate-wave.yml`)

#### Features

- Migrate multiple repositories in parallel (user-defined concurrency)
- Supports GHES → GHEC and GHEC → GHEC migrations
- Reads migration details from a wave file with per-repo source/target orgs and repo names
- Prints per-migration logs and a summary of failures
- Requires Personal Access Tokens (PATs) for both source and destination orgs
- Handles all migration via the [gh-gei](https://github.com/github/gh-gei) CLI extension
- Automatically removes branch protections from successfully migrated repositories
- Automatically validates App ID tags and assigns teams to migrated repositories
- Optionally archives source repositories after successful migration
- Supports both test and production runners with appropriate token selection

#### Inputs

- `source_ghes_api_url`: Source API URL (choice: test GHES, prod GHES, or GitHub.com)
- `destination_api_url`: Destination API URL (optional)
- `runner_type`: Runner type selection (test or prod) - also selects the appropriate token
- `repo_file`: Path to migration file (default: `migration-test-files/migrate-dummy-devops-repos-for-workflows.txt`)
- `max_concurrent`: Maximum concurrent migrations (default: 10, max: 10)
- `archive_source_repos`: Archive source repositories after successful migration (default: true)

**Environment Variables** (configured at workflow level):

- `SOURCE_GITHUB_TOKEN` or `SOURCE_TEST_GITHUB_TOKEN`: Selected automatically based on `runner_type` input
- `DEST_GITHUB_TOKEN`: PAT with admin/write access to destination org

#### Migration File Format

Each line in the file should be space-delimited and contain:

```text
<source-repo> <target-repo> <source-org> <target-org>
```

Example:

```text
migrate-this-repo migrate-this-repo-new Test org-test
migrate-this-repo migrate-this-repo-devops Devops org-test
fake-repo-000 fake-repo-000 Test org-test
```

#### Workflow Jobs

The workflow executes the following jobs in sequence:

1. **validate-repo-file**: Validates that the migration file exists and counts repositories
2. **migrate**: Performs parallel migrations using gh-gei
   - Migrates repositories in parallel (up to max_concurrent)
   - Tracks successes and failures
   - Generates migration results summary with clickable links to migrated repositories
   - Deletes failed migrations from destination
   - Sets successful migrations to internal visibility
   - Uploads migration successes artifact for archiving
3. **remove-branch-protections**: Removes branch protections from successfully migrated repositories
   - Triggers the `remove-branch-protections.yml` workflow in the `hcsc-devops/GHA-CICD-Pipelines-Admin` repository
   - Processes each successfully migrated repository
   - Runs automatically after successful migrations
4. **extract-destination-orgs**: Extracts unique destination organizations from migration file
5. **validate-teams-and-assign**: Validates App ID tags and assigns teams
   - Extracts App ID tags from repository topics
   - Validates that required role teams exist in destination organizations
   - Assigns teams to migrated repositories with appropriate permissions
   - Generates detailed team mapping summary
6. **archive-source-repos**: Archives successfully migrated repositories in source (optional)
   - Only runs if `archive_source_repos` input is true
   - Downloads migration successes artifact
   - Archives repositories in parallel

#### Workflow Usage

1. **⚠️ IMPORTANT**: Run the [Preflight Migration Validation Workflow](#preflight-migration-validation-workflow-githubworkflowspreflight-migration-validationyml) first
2. Add the required secrets (`SOURCE_GITHUB_TOKEN`, `SOURCE_TEST_GITHUB_TOKEN`, `DEST_GITHUB_TOKEN`) to your repository
3. Edit the migration file to list repositories and orgs to migrate
4. Trigger the workflow via workflow_dispatch with desired inputs:
   - Select appropriate `runner_type` (test or prod)
   - Set `archive_source_repos` to true if you want to archive source repos after migration
5. The workflow will:
   - Validate the repo file
   - Run migrations in parallel
   - Generate migration results summary with clickable repository links
   - Delete failed migrations from destination
   - Set successful migrations to internal visibility
   - Remove branch protections from successfully migrated repositories
   - Validate App ID tags and assign teams to repositories
   - Optionally archive source repositories
6. Review the migration results and team mapping summaries in the workflow run summary page

#### Workflow Requirements

- Both PATs must be authorized for SSO if your org enforces SAML
- PATs **must** have `repo`, `workflow`, `admin:org`, `read:enterprise`, and `delete_repo` scopes
- Self-hosted runners require the sparse checkout cleanup step (already included)
- The runner must have internet access and the ability to install the `gh-gei` extension

### Migration Workflow without Team Assignment (`.github/workflows/migrate-wave-no-teams.yml`)

This workflow performs repository migration only, without team assignment. Use this when you want to migrate repositories first and assign teams separately using the dedicated team assignment workflow.

#### Migration-Only Features

- Migrate multiple repositories in parallel (user-defined concurrency)
- Supports GHES → GHEC and GHEC → GHEC migrations
- Reads migration details from a wave file with per-repo source/target orgs and repo names
- Prints per-migration logs and a summary of failures
- Requires Personal Access Tokens (PATs) for both source and destination orgs
- Handles all migration via the [gh-gei](https://github.com/github/gh-gei) CLI extension
- Optionally archives source repositories after successful migration
- Supports both test and production runners with appropriate token selection
- **Does not assign teams** - use `assign-teams.yml` workflow separately for team assignment

#### Migration-Only Inputs

Same as the full migration workflow:

- `source_ghes_api_url`: Source API URL (choice: test GHES, prod GHES, or GitHub.com)
- `destination_api_url`: Destination API URL (optional)
- `runner_type`: Runner type selection (test or prod) - also selects the appropriate token
- `repo_file`: Path to migration file (default: `migration-test-files/migrate-dummy-devops-repos-for-workflows.txt`)
- `max_concurrent`: Maximum concurrent migrations (default: 10, max: 10)
- `archive_source_repos`: Archive source repositories after successful migration (default: true)

#### Migration-Only Jobs

1. **validate-repo-file**: Validates that the migration file exists and counts repositories
2. **migrate**: Performs parallel migrations using gh-gei
   - Migrates repositories in parallel (up to max_concurrent)
   - Tracks successes and failures
   - Generates migration results summary with clickable links to migrated repositories
   - Deletes failed migrations from destination
   - Sets successful migrations to internal visibility
   - Uploads migration successes artifact for archiving
3. **archive-source-repos**: Archives successfully migrated repositories in source (optional)
   - Only runs if `archive_source_repos` input is true
   - Downloads migration successes artifact
   - Archives repositories in parallel

#### Migration-Only Usage

1. **⚠️ IMPORTANT**: Run the [Preflight Migration Validation Workflow](#preflight-migration-validation-workflow-githubworkflowspreflight-migration-validationyml) first
2. Add the required secrets (`SOURCE_GITHUB_TOKEN`, `SOURCE_TEST_GITHUB_TOKEN`, `DEST_GITHUB_TOKEN`) to your repository
3. Edit the migration file to list repositories and orgs to migrate
4. Trigger the workflow via workflow_dispatch with desired inputs
5. After migration completes successfully, run the [Team Assignment Workflow](#team-assignment-workflow-githubworkflowsassign-teamsyml) to assign teams

### Team Assignment Workflow (`.github/workflows/assign-teams.yml`)

This dedicated workflow validates App ID tags and assigns teams to repositories. It can be run independently after migration or re-run to update team assignments.

#### Team Assignment Features

- Validates App ID tags from repository topics in source
- Checks that required role teams exist in destination organizations
- Assigns teams to repositories with appropriate permissions
- Supports all four role types: developer, approver, cicd_maintain, cicd_lead
- Generates detailed team mapping summary
- Can be run multiple times safely (idempotent)
- Works with repositories that are already migrated

#### Team Assignment Inputs

- `runner_type`: Runner type selection (test or prod) - also selects the appropriate token
- `repo_file`: Path to repository file (default: `migration-wave/Wave4/BDS_Repo_List.txt`)
- `source_ghes_api_url`: Source API URL for reading App ID tags (choice: test GHES, prod GHES, or GitHub.com)

**Environment Variables**:

- `SOURCE_GITHUB_TOKEN` or `SOURCE_TEST_GITHUB_TOKEN`: Selected automatically based on `runner_type` input (for reading App IDs from source)
- `DEST_GITHUB_TOKEN`: PAT with admin access to destination org (for assigning teams)

#### Team Assignment Jobs

1. **validate-repo-file**: Validates that the repository file exists and counts repositories
2. **extract-destination-orgs**: Extracts unique destination organizations from repository file
3. **validate-teams-and-assign**: Validates App ID tags and assigns teams
   - Extracts App ID tags from repository topics in source repositories
   - Validates that required role teams exist in destination organizations
   - Assigns teams to migrated repositories with appropriate permissions:
     - `developer` → push permission
     - `approver` → push permission
     - `cicd_maintain` → push permission
     - `cicd_lead` → push permission
   - Generates detailed team mapping summary showing:
     - Successfully assigned teams
     - Failed team assignments
     - Missing teams that need to be created
     - Repositories not yet migrated

#### Team Assignment Usage

1. Ensure repositories have been migrated to destination organizations
2. Ensure App ID tags exist on source repositories (format: `app-id-XXXXX` in repository topics)
3. Ensure required role teams exist in destination organizations (format: `MSAZURE_APP00006416_GITHUB-APPXXXXX_[TeamName]-[role]`)
4. Trigger the workflow via workflow_dispatch with the same repository file used for migration
5. Review the team mapping summary in the workflow run summary page
6. Create any missing teams identified in the summary
7. Re-run the workflow if needed to assign newly created teams

### Rollback Workflow (`.github/workflows/migrate-rollback.yml`)

The rollback workflow automates the process of undoing migrations by deleting repositories from the destination and unarchiving them in the source.

#### Rollback Workflow Features

- Validates the repository file before processing
- Deletes repositories from destination organization in parallel
- Unarchives repositories in source organization in parallel
- Tracks successes and failures for both operations
- Generates detailed logs and artifacts

#### Rollback Workflow Inputs

- `source_ghes_api_url`: Source API URL (choice: test GHES, prod GHES, or GitHub.com)
- `destination_api_url`: Destination API URL (optional)
- `runner_type`: Runner type selection (test or prod) - also selects the appropriate token
- `repo_file`: Path to rollback file (default: `migration-test-files/migrate-dummy-devops-repos-for-workflows.txt`)
- `max_concurrent`: Maximum concurrent operations (default: 10, max: 10)

**Environment Variables** (configured at workflow level):

- `SOURCE_GITHUB_TOKEN` or `SOURCE_TEST_GITHUB_TOKEN`: Selected automatically based on `runner_type` input
- `DEST_GITHUB_TOKEN`: PAT with delete permissions for destination org

#### Rollback Workflow Jobs

The rollback workflow executes the following jobs in sequence:

1. **validate-repo-file**: Validates that the rollback file exists and counts repositories
2. **rollback**: Performs the rollback operation
   - **Delete from destination**: Deletes repositories from destination organizations
     - Processes deletions sequentially
     - Tracks successful and failed deletions
     - Continues even if some deletions fail
   - **Unarchive in source**: Unarchives repositories in source organizations
     - Only unarchives repositories that were successfully deleted
     - Processes unarchiving in parallel (up to max_concurrent)
     - Tracks successful and failed unarchive operations
     - Generates detailed logs for each operation

The workflow can be run multiple times safely. If a repository doesn't exist in the destination, it will still attempt to unarchive it in the source for a complete rollback.

### Reclaim Mannequins Workflow (`.github/workflows/reclaim-mannequins.yml`)

The reclaim mannequins workflow automates the process of reclaiming mannequin users after repository migration. Mannequins are placeholder user accounts created during migration when the source platform user cannot be automatically mapped to a GitHub user.

#### Reclaim Mannequins Features

- Generate mannequin CSV files for destination organizations using `gh gei generate-mannequin-csv`
- Automatically map GHEC users to GHE users by removing `_hcsc` suffix
- Reclaim mannequins in bulk using CSV files via `gh gei reclaim-mannequin`
- Support for manual CSV file input for custom mappings
- Process multiple organizations in parallel (user-defined concurrency)
- Support for Enterprise Managed Users (EMU) with skip-invitation option
- Flexible operation modes: generate CSV only, reclaim from existing CSV, or both

#### Reclaim Mannequins Inputs

- `operation_mode`: Operation mode (choice: generate-csv, reclaim-from-csv, generate-and-reclaim)
- `destination_api_url`: Destination API URL (optional, for GitHub Enterprise)
- `runner_type`: Runner type selection (test or prod) - also selects the appropriate token
- `org_list`: Comma-separated list of destination organizations (required for CSV generation)
- `csv_file`: Path to CSV file for reclaiming mannequins (required for reclaim-from-csv mode)
- `map_users`: Automatically map GHEC users to GHE by removing `_hcsc` suffix (default: true)
- `skip_invitation`: Skip invitation step for EMU organizations (default: false)
- `max_concurrent`: Maximum concurrent operations (default: 5, max: 10)

**Environment Variables**:

- `DEST_GITHUB_TOKEN`: PAT with admin:org scope for destination organizations

#### Reclaim Mannequins Jobs

The workflow executes jobs based on the selected operation mode:

1. **validate-inputs**: Validates input parameters based on operation mode
2. **generate-mannequin-csv**: Generates mannequin CSV files for specified organizations
   - Runs for `generate-csv` and `generate-and-reclaim` modes
   - Uses `gh gei generate-mannequin-csv` to list mannequins
   - Optionally maps users by removing `_hcsc` suffix from usernames
   - Uploads CSV files as workflow artifacts
   - Generates summary with mannequin counts per organization
3. **reclaim-mannequins**: Reclaims mannequins using CSV files
   - Runs for `reclaim-from-csv` and `generate-and-reclaim` modes
   - Uses `gh gei reclaim-mannequin` with CSV input
   - Processes multiple organizations in parallel (up to max_concurrent)
   - Sends attribution invitations to users (unless skip-invitation is enabled)
   - Uploads reclaim logs as artifacts
   - Generates summary with success/failure counts

#### Reclaim Mannequins Usage

**Generate CSV files only:**

1. Trigger the workflow with `operation_mode: generate-csv`
2. Provide comma-separated list of organizations in `org_list`
3. Enable `map_users` to automatically remove `_hcsc` suffix (recommended)
4. Download the generated CSV files from workflow artifacts
5. Review and edit CSV files as needed
6. Use the CSV files with `reclaim-from-csv` mode

**Reclaim from existing CSV:**

1. Prepare a CSV file with columns: `mannequin-user`, `mannequin-id`, `target-user`
2. Commit the CSV file to the repository
3. Trigger the workflow with `operation_mode: reclaim-from-csv`
4. Provide the path to your CSV file in `csv_file`
5. Enable `skip_invitation` if using EMU organizations
6. Review the reclaim summary in the workflow run

**Generate and reclaim in one step:**

1. Trigger the workflow with `operation_mode: generate-and-reclaim`
2. Provide comma-separated list of organizations in `org_list`
3. Enable `map_users` to automatically map users
4. The workflow will generate CSVs and immediately reclaim mannequins
5. Review both summaries in the workflow run

#### CSV Format

The mannequin CSV file should have the following columns:

```csv
mannequin-user,mannequin-id,target-user
ghost-user-123,MDQ6VXNlcjEyMzQ1Njc4OQ==,actual-user
ghost-user-456_hcsc,MDQ6VXNlcjk4NzY1NDMyMQ==,actual-user-456
```

- `mannequin-user`: The mannequin's login name
- `mannequin-id`: The mannequin's unique ID (provided by `generate-mannequin-csv`)
- `target-user`: The GitHub user to receive attribution (must be an organization member)

When `map_users` is enabled, the script automatically removes `_hcsc` suffix from the `target-user` column.

#### Important Notes

- Target users must already be members of the destination organization
- Mannequins should be reclaimed before transferring repositories to other organizations
- For EMU organizations, use `skip_invitation: true` to reclaim without sending invitations
- The `gh gei generate-mannequin-csv` command requires admin:org scope on the PAT
- Review generated CSV files before reclaiming to ensure correct user mappings

## References

- [gh-gei: GitHub Enterprise Importer CLI](https://github.com/github/gh-gei)
- [gh CLI](https://cli.github.com/)
- [GitHub Actions: Migrating repositories](https://docs.github.com/en/enterprise-cloud@latest/admin/github-actions/managing-github-actions-for-your-enterprise/migrating-github-actions-repositories-to-github-enterprise-cloud)
- [GitHub Docs: Secrets](https://docs.github.com/en/actions/security-guides/encrypted-secrets)
- [Reclaiming mannequins for GitHub Enterprise Importer](https://docs.github.com/en/migrations/using-github-enterprise-importer/completing-your-migration-with-github-enterprise-importer/reclaiming-mannequins-for-github-enterprise-importer)
