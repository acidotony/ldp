#!/usr/bin/env node

/**
 * Offline test script using mock XML data
 * This doesn't require access to a real Jenkins instance
 *
 * Usage:
 *   node test-offline.js [apply_changes]
 *
 * Examples:
 *   node test-offline.js                # Test without applying changes
 *   node test-offline.js true           # Test with applying changes
 *
 * Creates a temporary test wave file with mock data
 */

const fs = require('fs');
const path = require('path');

// Sample Jenkins config.xml #1 - WITH organization parameter (tests UPDATE)
const SAMPLE_CONFIG_WITH_ORG = `<?xml version='1.0' encoding='UTF-8'?>
<flow-definition plugin="workflow-job@2.22">
  <actions></actions>
  <description>APP00000000</description>
  <keepDependencies>false</keepDependencies>
  <properties>
    <com.coravy.hudson.plugins.github.GithubProjectProperty plugin="github@1.29.2">
      <projectUrl>https://ghe.fyiblue.com/HCSC-Pilot/tf-devops-tooling</projectUrl>
      <displayName></displayName>
    </com.coravy.hudson.plugins.github.GithubProjectProperty>
    <com.sonyericsson.rebuild.RebuildSettings plugin="rebuild@1.28">
      <autoRebuild>false</autoRebuild>
      <rebuildDisabled>false</rebuildDisabled>
    </com.sonyericsson.rebuild.RebuildSettings>
    <hudson.model.ParametersDefinitionProperty>
      <parameterDefinitions>
        <hudson.model.StringParameterDefinition>
          <name>branchName</name>
          <description></description>
          <defaultValue>develop</defaultValue>
          <trim>true</trim>
        </hudson.model.StringParameterDefinition>
        <hudson.model.StringParameterDefinition>
          <name>buildFileLocation</name>
          <description></description>
          <defaultValue>Build.yml</defaultValue>
          <trim>true</trim>
        </hudson.model.StringParameterDefinition>
        <hudson.model.StringParameterDefinition>
          <name>repository</name>
          <description></description>
          <defaultValue>tf-devops-tooling</defaultValue>
          <trim>true</trim>
        </hudson.model.StringParameterDefinition>
        <hudson.model.StringParameterDefinition>
          <name>organization</name>
          <description></description>
          <defaultValue>HCSC-Pilot</defaultValue>
          <trim>true</trim>
        </hudson.model.StringParameterDefinition>
        <hudson.model.StringParameterDefinition>
          <name>payload</name>
          <description></description>
          <defaultValue>N/A</defaultValue>
          <trim>true</trim>
        </hudson.model.StringParameterDefinition>
        <hudson.model.StringParameterDefinition>
          <name>emailNotify</name>
          <description></description>
          <defaultValue></defaultValue>
          <trim>true</trim>
        </hudson.model.StringParameterDefinition>
        <hudson.model.TextParameterDefinition>
          <name>xmlDetails</name>
          <description></description>
          <defaultValue></defaultValue>
        </hudson.model.TextParameterDefinition>
      </parameterDefinitions>
    </hudson.model.ParametersDefinitionProperty>
    <hudson.plugins.throttleconcurrents.ThrottleJobProperty plugin="throttle-concurrents@2.0.1">
      <maxConcurrentPerNode>0</maxConcurrentPerNode>
      <maxConcurrentTotal>0</maxConcurrentTotal>
      <categories class="java.util.concurrent.CopyOnWriteArrayList"/>
      <throttleEnabled>false</throttleEnabled>
      <throttleOption>project</throttleOption>
      <limitOneJobWithMatchingParams>false</limitOneJobWithMatchingParams>
      <paramsToUseForLimit></paramsToUseForLimit>
    </hudson.plugins.throttleconcurrents.ThrottleJobProperty>
  </properties>
  <definition class="org.jenkinsci.plugins.workflow.cps.CpsScmFlowDefinition" plugin="workflow-cps@2.54">
    <scm class="hudson.plugins.git.GitSCM" plugin="git@3.9.1">
      <configVersion>2</configVersion>
      <userRemoteConfigs>
        <hudson.plugins.git.UserRemoteConfig>
          <url>git@ghe.fyiblue.com:HCSC-Pilot/Open_Source_Jenkins.git</url>
          <credentialsId>5ac7cc5e-abe0-41fe-9764-f11e06fb0cb0</credentialsId>
        </hudson.plugins.git.UserRemoteConfig>
      </userRemoteConfigs>
      <branches>
        <hudson.plugins.git.BranchSpec>
          <name>master</name>
        </hudson.plugins.git.BranchSpec>
      </branches>
      <doGenerateSubmoduleConfigurations>false</doGenerateSubmoduleConfigurations>
      <submoduleCfg class="list"></submoduleCfg>
      <extensions></extensions>
    </scm>
    <scriptPath>.OSJ/Build</scriptPath>
    <lightweight>false</lightweight>
  </definition>
  <triggers></triggers>
  <disabled>false</disabled>
</flow-definition>`;

// Sample Jenkins config.xml #2 - WITHOUT organization parameter (tests ADD)
const SAMPLE_CONFIG_WITHOUT_ORG = `<?xml version='1.0' encoding='UTF-8'?>
<flow-definition plugin="workflow-job@2.22">
  <actions></actions>
  <description>APP99999999 - Config without organization parameter</description>
  <keepDependencies>false</keepDependencies>
  <properties>
    <com.coravy.hudson.plugins.github.GithubProjectProperty plugin="github@1.29.2">
      <projectUrl>https://ghe.fyiblue.com/OldOrg/legacy-repo</projectUrl>
      <displayName></displayName>
    </com.coravy.hudson.plugins.github.GithubProjectProperty>
    <com.sonyericsson.rebuild.RebuildSettings plugin="rebuild@1.28">
      <autoRebuild>false</autoRebuild>
      <rebuildDisabled>false</rebuildDisabled>
    </com.sonyericsson.rebuild.RebuildSettings>
    <hudson.model.ParametersDefinitionProperty>
      <parameterDefinitions>
        <hudson.model.StringParameterDefinition>
          <name>branchName</name>
          <description></description>
          <defaultValue>main</defaultValue>
          <trim>true</trim>
        </hudson.model.StringParameterDefinition>
        <hudson.model.StringParameterDefinition>
          <name>repository</name>
          <description></description>
          <defaultValue>legacy-repo</defaultValue>
          <trim>true</trim>
        </hudson.model.StringParameterDefinition>
        <hudson.model.StringParameterDefinition>
          <name>environment</name>
          <description></description>
          <defaultValue>dev</defaultValue>
          <trim>true</trim>
        </hudson.model.StringParameterDefinition>
      </parameterDefinitions>
    </hudson.model.ParametersDefinitionProperty>
    <hudson.plugins.throttleconcurrents.ThrottleJobProperty plugin="throttle-concurrents@2.0.1">
      <maxConcurrentPerNode>0</maxConcurrentPerNode>
      <maxConcurrentTotal>0</maxConcurrentTotal>
      <categories class="java.util.concurrent.CopyOnWriteArrayList"/>
      <throttleEnabled>false</throttleEnabled>
      <throttleOption>project</throttleOption>
      <limitOneJobWithMatchingParams>false</limitOneJobWithMatchingParams>
      <paramsToUseForLimit></paramsToUseForLimit>
    </hudson.plugins.throttleconcurrents.ThrottleJobProperty>
  </properties>
  <definition class="org.jenkinsci.plugins.workflow.cps.CpsScmFlowDefinition" plugin="workflow-cps@2.54">
    <scm class="hudson.plugins.git.GitSCM" plugin="git@3.9.1">
      <configVersion>2</configVersion>
      <userRemoteConfigs>
        <hudson.plugins.git.UserRemoteConfig>
          <url>git@ghe.fyiblue.com:OldOrg/legacy-repo.git</url>
          <credentialsId>abc123-credential-id</credentialsId>
        </hudson.plugins.git.UserRemoteConfig>
      </userRemoteConfigs>
      <branches>
        <hudson.plugins.git.BranchSpec>
          <name>main</name>
        </hudson.plugins.git.BranchSpec>
      </branches>
      <doGenerateSubmoduleConfigurations>false</doGenerateSubmoduleConfigurations>
      <submoduleCfg class="list"></submoduleCfg>
      <extensions></extensions>
    </scm>
    <scriptPath>Jenkinsfile</scriptPath>
    <lightweight>true</lightweight>
  </definition>
  <triggers></triggers>
  <disabled>false</disabled>
</flow-definition>`;

// Parse command line arguments
const applyChanges = process.argv[2] === 'true';

if (process.argv.includes('--help') || process.argv.includes('-h')) {
  console.error('Usage: node test-offline.js [apply_changes]');
  console.error('');
  console.error('Examples:');
  console.error('  node test-offline.js                # Test without applying changes');
  console.error('  node test-offline.js true           # Test with applying changes');
  console.log('Creates a temporary test wave file with mock data\n');
  process.exit(1);
}

console.log(`Running offline test (apply_changes=${applyChanges})...`);
console.log('This test uses mock XML data and does not require Jenkins access\n');

// Use test case 1 (WITH organization parameter) as default
const SAMPLE_CONFIG = SAMPLE_CONFIG_WITH_ORG;
const testCaseDescription = 'WITH organization parameter (tests UPDATE)';

// Create a temporary wave file for testing
const tempWaveFile = path.join(__dirname, 'test-wave-offline.txt');
const waveContent = `https://jenkins.esp.fyiblue.com/job/TestJob/job/Build hcsc-core my-test-repo
https://jenkins.esp.fyiblue.com/job/AnotherJob/job/Deploy another-org another-repo`;

fs.writeFileSync(tempWaveFile, waveContent);
console.log(`Created temporary wave file: ${tempWaveFile}`);
console.log('Wave file contents:');
console.log(waveContent);
console.log('');

// Mock axios to return our sample config
const axios = require('axios');
const originalGet = axios.get;
axios.get = async function(url, config) {
  console.log(`[MOCK] Intercepted request to: ${url}`);
  return {
    status: 200,
    data: SAMPLE_CONFIG
  };
};

// Mock the @actions/core module for local testing
const mockCore = {
  inputs: {},
  outputs: {},

  getInput(name, options) {
    const value = this.inputs[name];
    if (options?.required && !value) {
      throw new Error(`Input required and not supplied: ${name}`);
    }
    return value || '';
  },

  setOutput(name, value) {
    this.outputs[name] = value;
    console.log(`[OUTPUT] ${name}: ${value}`);
  },

  info(message) {
    console.log(`[INFO] ${message}`);
  },

  warning(message) {
    console.warn(`[WARNING] ${message}`);
  },

  error(message) {
    console.error(`[ERROR] ${message}`);
  },

  setFailed(message) {
    console.error(`[FAILED] ${message}`);
    process.exit(1);
  }
};

// Replace @actions/core with our mock
require.cache[require.resolve('@actions/core')] = {
  exports: mockCore
};

// Mock Jenkins credentials (matching the JENKINS_CREDENTIALS.json format)
const mockCredentials = {
  "esp": {
    "name": "ESP",
    "url": "https://jenkins.esp.fyiblue.com",
    "username": "mockuser",
    "token": "mocktoken123"
  }
};

// Set up mock inputs for the action
mockCore.inputs = {
  wave_file: tempWaveFile,
  apply_changes: applyChanges.toString(),
  jenkins_credentials: JSON.stringify(mockCredentials)
};

// Set GITHUB_WORKSPACE for output file location
process.env.GITHUB_WORKSPACE = process.cwd();

console.log('=== Offline Test Mode (Using Mock Data) ===');
console.log('Test Case:', testCaseDescription);
console.log('Apply Changes:', applyChanges);
console.log('Wave File:', tempWaveFile);
console.log('============================================\n');

console.log('Original Config Sample:');
console.log(SAMPLE_CONFIG.substring(0, 400) + '...\n');

// Now require and run the actual action
require('./index.js');

// Cleanup temporary wave file after test completes
process.on('exit', () => {
  try {
    if (fs.existsSync(tempWaveFile)) {
      fs.unlinkSync(tempWaveFile);
      console.log(`\nCleaned up temporary wave file: ${tempWaveFile}`);
    }
  } catch (err) {
    // Ignore cleanup errors
  }
});

