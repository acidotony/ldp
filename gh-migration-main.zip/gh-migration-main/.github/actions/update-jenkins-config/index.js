const core = require('@actions/core');
const fs = require('fs');
const path = require('path');
const { parseJenkinsCredentials, getJenkinsInstanceKey } = require('./utils/jenkins');
const { fetchConfigXml, pushConfigXml } = require('./utils/http');
const { updateJenkinsConfig } = require('./utils/xml');

/**
 * Parse wave file containing jobs to update
 * Format: jenkins_job_url org repo credentials_id (space/tab delimited)
 * @param {string} waveFilePath - Path to wave file
 * @returns {Array<Object>} Array of job objects
 */
function parseWaveFile(waveFilePath) {
  const content = fs.readFileSync(waveFilePath, 'utf-8');
  const lines = content.split('\n').filter(line => line.trim() && !line.startsWith('#'));
  
  return lines.map((line, index) => {
    const parts = line.trim().split(/\s+/);
    
    if (parts.length < 3) {
      throw new Error(`Invalid line ${index + 1} in wave file: expected at least 3 fields (jenkins_job_url org repo), got ${parts.length}`);
    }
    
    return {
      jenkinsJobUrl: parts[0],
      org: parts[1],
      repo: parts[2],
      credentialsId: parts[3] || '' // Optional 4th column
    };
  });
}

/**
 * Main function to update Jenkins config.xml files
 */
async function run() {
  try {
    // Get inputs
    const waveFilePath = core.getInput('wave_file', { required: true });
    const applyChanges = core.getInput('apply_changes') === 'true';
    const jenkinsCredentialsJson = core.getInput('jenkins_credentials');

    core.info(`Reading wave file: ${waveFilePath}`);
    const jobs = parseWaveFile(waveFilePath);
    core.info(`Found ${jobs.length} jobs to process\n`);

    const results = {
      total: jobs.length,
      succeeded: 0,
      failed: 0,
      errors: []
    };

    // Process each job
    for (let i = 0; i < jobs.length; i++) {
      const job = jobs[i];
      const jobNum = i + 1;
      
      core.info(`\n${'='.repeat(80)}`);
      core.info(`Processing job ${jobNum}/${jobs.length}`);
      core.info(`URL: ${job.jenkinsJobUrl}`);
      core.info(`Org: ${job.org} | Repo: ${job.repo}`);
      core.info(`${'='.repeat(80)}\n`);

      try {
        // Parse Jenkins credentials for this job's instance
        const { username, token } = parseJenkinsCredentials(jenkinsCredentialsJson, job.jenkinsJobUrl);

        // Construct config.xml URL
        const configXmlUrl = `${job.jenkinsJobUrl.replace(/\/$/, '')}/config.xml`;

        // Fetch config.xml
        const configXml = await fetchConfigXml(configXmlUrl, username, token, core);

        // Save original config.xml
        const outputDir = process.env.GITHUB_WORKSPACE || '.';
        const sanitizedRepo = job.repo.replace(/[^a-zA-Z0-9-_]/g, '_');
        const originalPath = path.join(outputDir, `${jobNum}-original-${sanitizedRepo}.xml`);
        fs.writeFileSync(originalPath, configXml);
        core.info(`Saved original config to: ${originalPath}`);

        // Update config.xml
        const updatedXml = await updateJenkinsConfig(configXml, job.org, job.repo, core);

        // Save updated config.xml
        const outputPath = path.join(outputDir, `${jobNum}-updated-${sanitizedRepo}.xml`);
        fs.writeFileSync(outputPath, updatedXml);
        core.info(`Saved updated config to: ${outputPath}`);

        // Apply changes to Jenkins if requested
        if (applyChanges) {
          await pushConfigXml(configXmlUrl, updatedXml, username, token, core);
          core.info('✓ Changes applied to Jenkins successfully');
        }

        core.info(`✓ Job ${jobNum}/${jobs.length} completed successfully\n`);
        results.succeeded++;

      } catch (error) {
        core.error(`✗ Job ${jobNum}/${jobs.length} failed: ${error.message}\n`);
        results.failed++;
        results.errors.push({
          job: `${job.org}/${job.repo}`,
          url: job.jenkinsJobUrl,
          error: error.message
        });
      }
    }

    // Summary
    core.info(`\n${'='.repeat(80)}`);
    core.info('SUMMARY');
    core.info(`${'='.repeat(80)}`);
    core.info(`Total jobs: ${results.total}`);
    core.info(`✓ Succeeded: ${results.succeeded}`);
    core.info(`✗ Failed: ${results.failed}`);
    
    if (!applyChanges) {
      core.info('\nℹ Changes not applied. Set apply_changes=true to push to Jenkins.');
    }

    if (results.failed > 0) {
      core.info('\nFailed jobs:');
      results.errors.forEach(err => {
        core.error(`  - ${err.job}: ${err.error}`);
      });
      core.setFailed(`${results.failed} job(s) failed to update`);
    }

    core.setOutput('total_jobs', results.total);
    core.setOutput('succeeded_jobs', results.succeeded);
    core.setOutput('failed_jobs', results.failed);

  } catch (error) {
    core.setFailed(`Action failed: ${error.message}`);
    if (error.response) {
      core.error(`Response status: ${error.response.status}`);
      core.error(`Response data: ${JSON.stringify(error.response.data)}`);
    }
  }
}

run();

