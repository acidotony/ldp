# Local Testing Guide

This directory contains scripts to test the Jenkins config update action locally without needing to run it through GitHub Actions.

## Testing Options

### Option 1: Offline Test (Recommended for Quick Testing)

Uses mock XML data - doesn't require access to a real Jenkins instance.

**Basic test (no apply):**
```bash
node test-offline.js
```

**Test with apply changes (simulated):**
```bash
node test-offline.js true
```

This will:
- Create a temporary wave file with sample job data
- Use mock Jenkins config.xml with organization parameter
- Test updating organization, repository, credentials, and OSJ URL
- Generate output files: `updated-config-{org}-{repo}.xml`
- Display processing summary
- Clean up temporary files

**What it tests:**
- Parsing wave file format
- Updating existing parameters (organization, repository)
- Updating Git SCM credentials
- Updating OSJ URL to GitHub Enterprise Cloud
- Batch processing multiple jobs
- Error handling and summary reporting

### Option 2: Live Test

Tests against a real Jenkins instance using a wave file.

**Setup (one-time):**

1. Create a `JENKINS_CREDENTIALS.json` file in this directory with your credentials:

```json
{
  "esp": {
    "name": "ESP",
    "url": "https://jenkins.esp.fyiblue.com",
    "username": "your-username",
    "token": "your-api-token"
  },
  "digital": {
    "name": "Digital",
    "url": "https://jenkins.digital.fyiblue.com",
    "username": "your-username",
    "token": "your-api-token"
  }
}
```

2. Create a test wave file (e.g., `test-wave.txt`):

```
# Test wave file
https://jenkins.esp.fyiblue.com/job/MyTeam/job/MyApp/job/Build hcsc-core my-app-repo esp-git-creds-uuid-123
https://jenkins.esp.fyiblue.com/job/MyTeam/job/MyService/job/Deploy hcsc-core my-service-repo esp-git-creds-uuid-456
```

**Run the test:**

```bash
# Test without applying changes (safe mode)
node test-local.js test-wave.txt

# Test with applying changes to Jenkins
node test-local.js test-wave.txt true
```

```

This will:
- Automatically load credentials from `JENKINS_CREDENTIALS.json`
- Read jobs from the wave file
- Fetch actual config.xml from Jenkins for each job
- Update organization, repository, credentials, and OSJ URL
- Generate output files: `updated-config-{org}-{repo}.xml`
- If `apply_changes=true`, push updated configs back to Jenkins
- Display processing summary

## Wave File Format

Wave files use space or tab-delimited format:
```
<jenkins_job_url> <org> <repo> <credentials_id>
```

Example:
```
# ESP Jenkins jobs
https://jenkins.esp.fyiblue.com/job/Team1/job/App1/job/Build hcsc-core app1-repo esp-creds-123
https://jenkins.esp.fyiblue.com/job/Team1/job/App2/job/Deploy hcsc-core app2-repo esp-creds-456

# Digital Jenkins jobs
https://jenkins.digital.fyiblue.com/job/Team2/job/WebApp/job/CI hcsc-digital webapp-repo digital-creds-789
```

- Lines starting with `#` are ignored (comments)
- All 4 fields are required per line
- Fields separated by spaces or tabs

## What to Check

After running either test, check the generated files:

```powershell
# View all generated files
Get-ChildItem *-updated-*.xml

# View a specific file
Get-Content 1-updated-my-app-repo.xml

# Search for the updated projectUrl
Select-String -Pattern "projectUrl" -Path *-updated-*.xml

# Search for the updated organization parameter
Select-String -Pattern "<name>organization</name>" -Path *-updated-*.xml -Context 0,3

# Search for the updated credentials
Select-String -Pattern "credentialsId" -Path *-updated-*.xml
```

Expected changes in each file:
1. **projectUrl** should be: `https://github.com/{org}/{repo}`
2. **organization defaultValue** should be: `{org}`
3. **repository defaultValue** should be: `{repo}`
4. **credentialsId** should be: `{credentials_id}`
5. **OSJ URL** should be: `https://github.com/hcsc-core/Open_Source_Jenkins.git`

## Troubleshooting

### Missing Dependencies
If you get module errors, make sure dependencies are installed:
```bash
npm install
```

### Permission Issues
Make scripts executable:
```bash
chmod +x test-local.js test-offline.js
```

### Jenkins Connection Issues
If testing against a real Jenkins instance fails:
- Check if the Jenkins URL is accessible
- Create `JENKINS_CREDENTIALS.json` with your credentials (see README.md for format)
- Make sure the credentials key matches the Jenkins hostname (e.g., "esp" for jenkins.esp.fyiblue.com)
- Check if the job exists at that URL

## Example Workflow

### 1. Quick test with mock data (no Jenkins access):
```bash
node test-offline.js
```
Check the output files:
```powershell
Get-Content 1-updated-my-test-repo.xml | Select-String "projectUrl|organization|credentialsId"
```

### 2. Test with apply changes (simulated):
```bash
node test-offline.js true
```
This simulates the full workflow including pushing to Jenkins.

### 3. Test with real Jenkins (if accessible):

Create a test wave file (`my-test-wave.txt`):
```
https://jenkins.esp.fyiblue.com/job/TestTeam/job/TestApp/job/Build hcsc-core test-app-repo esp-git-creds-123
```

Run without applying (safe mode):
```bash
node test-local.js my-test-wave.txt
```

Review the generated XML files:
```powershell
Get-ChildItem *-updated-*.xml
Get-Content 1-updated-test-app-repo.xml
```

If everything looks good, run with apply:
```bash
node test-local.js my-test-wave.txt true
```

### 4. Verify changes in Jenkins:

After applying changes, check Jenkins:
- Navigate to the job in Jenkins web UI
- Click "Configure"
- Verify organization, repository, credentials, and SCM URL are correct
- Test running the job to ensure it works

## Best Practices

1. **Always test with apply_changes=false first** - Review the generated XML files before pushing to Jenkins
2. **Start with a small subset** - Test with 1-2 jobs before processing a large wave file
3. **Use comments in wave files** - Document each batch with `#` comments for clarity
4. **Backup Jenkins configs** - Download original configs before making changes
5. **Test in non-production first** - If possible, test with dev/test Jenkins instances

## Notes

- The test scripts mock the GitHub Actions environment
- Output files are created in the current directory with pattern: `{number}-updated-{repo}.xml`
- Both scripts show detailed logging of what they're doing
- **test-offline.js**: No changes are made to Jenkins - uses mock data only
- **test-local.js**: Only makes changes to Jenkins if `apply_changes=true` is specified
- Temporary wave files are automatically cleaned up after testing
- Both scripts support batch processing of multiple jobs

## Output Files

After running tests, you'll see files like:
- `1-updated-my-app-repo.xml`
- `2-updated-webapp-repo.xml`
- `3-updated-api-service.xml`
- `test-wave-offline.txt` (temporary, auto-deleted)

Each XML file contains the complete updated Jenkins job configuration ready to be applied.

