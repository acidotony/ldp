/**
 * Jenkins-related utility functions
 */

/**
 * Extract Jenkins instance key from URL
 * e.g., "https://jenkins.esp.fyiblue.com/..." -> "esp"
 * @param {string} url - Jenkins URL
 * @returns {string|null} Instance key or null if not found
 */
function getJenkinsInstanceKey(url) {
  const match = url.match(/jenkins\.([^.]+)\.fyiblue\.com/);
  return match ? match[1] : null;
}

/**
 * Parse Jenkins credentials and match them to a URL
 * @param {string} jenkinsCredentialsJson - JSON string of credentials
 * @param {string} jenkinsJobUrl - Jenkins job URL
 * @returns {Object} Object with username and token properties (may be null)
 */
function parseJenkinsCredentials(jenkinsCredentialsJson, jenkinsJobUrl) {
  let username = null;
  let token = null;

  if (!jenkinsCredentialsJson) {
    return { username, token };
  }

  try {
    const jenkinsCredentials = JSON.parse(jenkinsCredentialsJson);
    const instanceKey = getJenkinsInstanceKey(jenkinsJobUrl);

    if (instanceKey && jenkinsCredentials[instanceKey]) {
      username = jenkinsCredentials[instanceKey].username;
      token = jenkinsCredentials[instanceKey].token;
    }
  } catch (error) {
    // Silently fail - caller can handle logging
  }

  return { username, token };
}

module.exports = {
  getJenkinsInstanceKey,
  parseJenkinsCredentials
};

