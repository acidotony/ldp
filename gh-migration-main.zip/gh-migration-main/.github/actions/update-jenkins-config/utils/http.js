/**
 * HTTP utilities for fetching Jenkins config
 */

const axios = require('axios');
const { execSync } = require('child_process');

/**
 * Check if hostname should bypass proxy based on NO_PROXY settings
 * @param {string} hostname - Hostname to check
 * @param {string} noProxy - NO_PROXY environment variable value
 * @returns {boolean} True if should bypass proxy
 */
function shouldBypassProxy(hostname, noProxy) {
  if (hostname.includes('.fyiblue.com')) {
    return true;
  }

  if (!noProxy) {
    return false;
  }

  return noProxy.split(',').some(pattern => {
    const trimmed = pattern.trim();
    if (trimmed.startsWith('.')) {
      return hostname.endsWith(trimmed);
    }
    return hostname === trimmed || hostname.endsWith('.' + trimmed);
  });
}

/**
 * Build axios configuration with proxy settings
 * @param {string} url - Target URL
 * @param {string|null} username - Username for authentication
 * @param {string|null} token - Token for authentication
 * @returns {Object} Axios configuration object
 */
function buildAxiosConfig(url, username, token) {
  const axiosConfig = {
    headers: {
      'Accept': 'application/xml, text/xml, */*',
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    },
    validateStatus: function (status) {
      return status >= 200 && status < 500;
    }
  };

  // Configure proxy from environment variables
  const proxyUrl = process.env.https_proxy || process.env.HTTPS_PROXY ||
                   process.env.http_proxy || process.env.HTTP_PROXY;
  const noProxy = process.env.NO_PROXY || process.env.no_proxy || '';
  const hostname = new URL(url).hostname;

  if (shouldBypassProxy(hostname, noProxy)) {
    axiosConfig.proxy = false;
  } else if (proxyUrl) {
    const proxyUrlObj = new URL(proxyUrl);
    axiosConfig.proxy = {
      host: proxyUrlObj.hostname,
      port: parseInt(proxyUrlObj.port),
      protocol: proxyUrlObj.protocol.replace(':', '')
    };
  }

  // Add authentication if provided
  if (username && token) {
    const credentials = Buffer.from(`${username}:${token}`).toString('base64');
    axiosConfig.headers['Authorization'] = `Basic ${credentials}`;
  }

  return axiosConfig;
}

/**
 * Fetch XML using curl as fallback
 * @param {string} url - URL to fetch
 * @param {string} username - Username for authentication
 * @param {string} token - Token for authentication
 * @returns {string} XML content
 * @throws {Error} If curl fails or returns error page
 */
function fetchWithCurl(url, username, token) {
  const curlCommand = `curl -s -u "${username}:${token}" "${url}"`;
  const result = execSync(curlCommand, {
    encoding: 'utf-8',
    maxBuffer: 10 * 1024 * 1024
  });

  // Check if curl returned an error page
  if (result.includes('<TITLE>Request Error</TITLE>') || result.includes('HTTP/')) {
    throw new Error('Curl received error page from server');
  }

  return result;
}

/**
 * Fetch Jenkins config.xml with axios and curl fallback
 * @param {string} configXmlUrl - URL to config.xml
 * @param {string|null} username - Username for authentication
 * @param {string|null} token - Token for authentication
 * @param {Object} logger - Logger object with info, warning, and error methods
 * @returns {Promise<string>} XML content
 * @throws {Error} If both axios and curl fail
 */
async function fetchConfigXml(configXmlUrl, username, token, logger) {
  const axiosConfig = buildAxiosConfig(configXmlUrl, username, token);

  // Try axios first
  try {
    const response = await axios.get(configXmlUrl, axiosConfig);

    if (response.status !== 200) {
      throw new Error(`HTTP ${response.status}`);
    }

    return response.data;
  } catch (axiosError) {
    // Fallback to curl if axios fails
    if (username && token) {
      try {
        const result = fetchWithCurl(configXmlUrl, username, token);
        return result;
      } catch (curlError) {
        throw new Error(`Failed to fetch config.xml with both axios and curl: ${curlError.message}`);
      }
    } else {
      throw new Error(`Failed to fetch config.xml with axios and no credentials available for curl fallback: ${axiosError.message}`);
    }
  }
}

/**
 * Push updated XML back to Jenkins using curl
 * @param {string} configXmlUrl - URL to config.xml
 * @param {string} xmlContent - Updated XML content to push
 * @param {string} username - Username for authentication
 * @param {string} token - Token for authentication
 * @param {Object} logger - Logger object with info, warning, and error methods
 * @returns {Promise<void>}
 * @throws {Error} If push fails
 */
async function pushConfigXml(configXmlUrl, xmlContent, username, token, logger) {
  if (!username || !token) {
    throw new Error('Username and token are required to push config.xml to Jenkins');
  }

  // Save XML content to temporary file
  const fs = require('fs');
  const path = require('path');
  const tempFile = path.join(process.env.GITHUB_WORKSPACE || '.', 'temp-config.xml');
  
  try {
    fs.writeFileSync(tempFile, xmlContent, 'utf-8');
    
    // Use curl to POST the XML
    const curlCommand = `curl -s -X POST -u "${username}:${token}" -H "Content-Type: application/xml" --data-binary @"${tempFile}" "${configXmlUrl}"`;
    
    logger.info('Pushing updated config.xml to Jenkins...');
    const result = execSync(curlCommand, {
      encoding: 'utf-8',
      maxBuffer: 10 * 1024 * 1024
    });

    // Check if the response indicates success (empty or minimal response is typical for success)
    if (result && result.includes('error')) {
      throw new Error(`Jenkins returned an error: ${result}`);
    }

    logger.info('Successfully pushed config.xml to Jenkins');
  } catch (error) {
    throw new Error(`Failed to push config.xml to Jenkins: ${error.message}`);
  } finally {
    // Clean up temp file
    try {
      if (fs.existsSync(tempFile)) {
        fs.unlinkSync(tempFile);
      }
    } catch (cleanupError) {
      // Ignore cleanup errors
    }
  }
}

module.exports = {
  shouldBypassProxy,
  buildAxiosConfig,
  fetchWithCurl,
  fetchConfigXml,
  pushConfigXml
};


