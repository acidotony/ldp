/**
 * XML parsing and updating utilities
 */

const xml2js = require('xml2js');

/**
 * Parse XML string to JavaScript object
 * @param {string} xmlString - XML string to parse
 * @returns {Promise<Object>} Parsed XML object
 */
async function parseXml(xmlString) {
  const parser = new xml2js.Parser();
  return await parser.parseStringPromise(xmlString);
}

/**
 * Build XML string from JavaScript object
 * @param {Object} xmlObject - JavaScript object representing XML
 * @returns {string} XML string
 */
function buildXml(xmlObject) {
  const builder = new xml2js.Builder();
  return builder.buildObject(xmlObject);
}

/**
 * Get root element from parsed XML
 * @param {Object} parsedXml - Parsed XML object
 * @returns {Object} Object with rootElement and rootElementName
 * @throws {Error} If root element not found
 */
function getRootElement(parsedXml) {
  const rootElement = parsedXml.project || parsedXml['flow-definition'];
  const rootElementName = parsedXml.project ? 'project' : 'flow-definition';

  if (!rootElement) {
    throw new Error('Could not find root element (expected "project" or "flow-definition")');
  }

  return { rootElement, rootElementName };
}

/**
 * Update GitHub project URL in Jenkins config
 * @param {Object} rootElement - Root element of Jenkins config
 * @param {string} org - New organization name
 * @param {string} repo - New repository name
 * @param {Object} logger - Logger object
 * @returns {boolean} True if updated, false otherwise
 */
function updateProjectUrl(rootElement, org, repo, logger) {
  if (!rootElement.properties) {
    return false;
  }

  let updated = false;
  const properties = rootElement.properties;

  for (let i = 0; i < properties.length; i++) {
    const prop = properties[i];

    if (prop['com.coravy.hudson.plugins.github.GithubProjectProperty']) {
      const githubProp = prop['com.coravy.hudson.plugins.github.GithubProjectProperty'][0];

      if (githubProp.projectUrl) {
        const oldUrl = githubProp.projectUrl[0];
        const newUrl = `https://github.com/${org}/${repo}`;
        githubProp.projectUrl[0] = newUrl;
        logger.info(`Updated projectUrl from "${oldUrl}" to "${newUrl}"`);
        updated = true;
      }
    }
  }

  return updated;
}

/**
 * Update or add organization parameter in Jenkins config
 * @param {Object} rootElement - Root element of Jenkins config
 * @param {string} org - New organization name
 * @param {Object} logger - Logger object
 * @returns {boolean} True if found/updated, false otherwise
 */
function updateOrganizationParameter(rootElement, org, logger) {
  if (!rootElement.properties) {
    return false;
  }

  let orgParamFound = false;

  for (let i = 0; i < rootElement.properties.length; i++) {
    const prop = rootElement.properties[i];

    if (prop['hudson.model.ParametersDefinitionProperty']) {
      const paramsProp = prop['hudson.model.ParametersDefinitionProperty'][0];

      if (paramsProp.parameterDefinitions && paramsProp.parameterDefinitions[0]) {
        const paramDefs = paramsProp.parameterDefinitions[0];

        if (paramDefs['hudson.model.StringParameterDefinition']) {
          const stringParams = paramDefs['hudson.model.StringParameterDefinition'];

          // Look for existing organization parameter (check both lowercase and capitalized)
          for (let j = 0; j < stringParams.length; j++) {
            const param = stringParams[j];

            if (param.name && (param.name[0] === 'organization' || param.name[0] === 'Organization')) {
              if (param.defaultValue) {
                const oldValue = param.defaultValue[0];
                param.defaultValue[0] = org;
                logger.info(`Updated ${param.name[0]} parameter from "${oldValue}" to "${org}"`);
              } else {
                param.defaultValue = [org];
                logger.info(`Added defaultValue "${org}" to existing ${param.name[0]} parameter`);
              }
              orgParamFound = true;
              break;
            }
          }

          // If not found, add new organization parameter
          if (!orgParamFound) {
            stringParams.push({
              name: ['organization'],
              description: ['GitHub Organization'],
              defaultValue: [org]
            });
            logger.info(`Added new organization parameter with value "${org}"`);
            orgParamFound = true;
          }
        } else if (!orgParamFound) {
          // Create StringParameterDefinition array if it doesn't exist
          paramDefs['hudson.model.StringParameterDefinition'] = [{
            name: ['organization'],
            description: ['GitHub Organization'],
            defaultValue: [org]
          }];
          logger.info(`Created StringParameterDefinition and added organization parameter with value "${org}"`);
          orgParamFound = true;
        }
      }
    }
  }

  return orgParamFound;
}

/**
 * Update credentials ID in Jenkins config
 * Hardcoded to update to 'ghec-hcsc-core-app'
 * @param {Object} rootElement - Root element of Jenkins config
 * @param {Object} logger - Logger object
 * @returns {boolean} True if updated, false otherwise
 */
function updateCredentialsId(rootElement, logger) {
  // Hardcoded GHEC credentials ID
  const credentialsId = 'ghec-hcsc-core-app';
  
  // For pipeline jobs (flow-definition), SCM is in definition.scm
  // For freestyle jobs (project), SCM is in rootElement.scm
  let scm = null;
  
  if (rootElement.definition && rootElement.definition[0] && rootElement.definition[0].scm) {
    scm = rootElement.definition[0].scm;
  } else if (rootElement.scm) {
    scm = rootElement.scm;
  } else {
    return false;
  }

  let updated = false;

  for (let i = 0; i < scm.length; i++) {
    const scmElement = scm[i];

    // Check if this is a Git SCM
    if (scmElement.$ && scmElement.$.class === 'hudson.plugins.git.GitSCM') {
      // Navigate to userRemoteConfigs
      if (scmElement.userRemoteConfigs && scmElement.userRemoteConfigs[0]) {
        const userRemoteConfigs = scmElement.userRemoteConfigs[0];

        if (userRemoteConfigs['hudson.plugins.git.UserRemoteConfig']) {
          const remoteConfigs = userRemoteConfigs['hudson.plugins.git.UserRemoteConfig'];

          for (let j = 0; j < remoteConfigs.length; j++) {
            const remoteConfig = remoteConfigs[j];

            if (remoteConfig.credentialsId) {
              const oldCredentialsId = remoteConfig.credentialsId[0];
              remoteConfig.credentialsId[0] = credentialsId;
              logger.info(`Updated credentialsId from "${oldCredentialsId}" to "${credentialsId}"`);
              updated = true;
            } else {
              // Add credentialsId if it doesn't exist
              remoteConfig.credentialsId = [credentialsId];
              logger.info(`Added credentialsId with value "${credentialsId}"`);
              updated = true;
            }
          }
        }
      }
    }
  }

  return updated;
}

/**
 * Update OSJ (Open Source Jenkins) Git URL in Jenkins config
 * Hardcoded to update to the GHEC OSJ repository
 * @param {Object} rootElement - Root element of Jenkins config
 * @param {Object} logger - Logger object
 * @returns {boolean} True if updated, false otherwise
 */
function updateOsjUrl(rootElement, logger) {
  // Hardcoded GHEC OSJ URL
  const NEW_OSJ_URL = 'https://github.com/hcsc-core/Open_Source_Jenkins.git';
  
  // For pipeline jobs (flow-definition), SCM is in definition.scm
  // For freestyle jobs (project), SCM is in rootElement.scm
  let scm = null;
  
  if (rootElement.definition && rootElement.definition[0] && rootElement.definition[0].scm) {
    scm = rootElement.definition[0].scm;
  } else if (rootElement.scm) {
    scm = rootElement.scm;
  } else {
    return false;
  }

  let updated = false;

  for (let i = 0; i < scm.length; i++) {
    const scmElement = scm[i];

    // Check if this is a Git SCM
    if (scmElement.$ && scmElement.$.class === 'hudson.plugins.git.GitSCM') {
      // Navigate to userRemoteConfigs
      if (scmElement.userRemoteConfigs && scmElement.userRemoteConfigs[0]) {
        const userRemoteConfigs = scmElement.userRemoteConfigs[0];

        if (userRemoteConfigs['hudson.plugins.git.UserRemoteConfig']) {
          const remoteConfigs = userRemoteConfigs['hudson.plugins.git.UserRemoteConfig'];

          for (let j = 0; j < remoteConfigs.length; j++) {
            const remoteConfig = remoteConfigs[j];

            if (remoteConfig.url) {
              const oldUrl = remoteConfig.url[0];
              remoteConfig.url[0] = NEW_OSJ_URL;
              logger.info(`Updated OSJ Git URL from "${oldUrl}" to "${NEW_OSJ_URL}"`);
              updated = true;
            }
          }
        }
      }
    }
  }

  return updated;
}

/**
 * Update OSJ (Open Source Jenkins) Git branch in Jenkins config
 * Hardcoded to update to the GHEC testing branch
 * @param {Object} rootElement - Root element of Jenkins config
 * @param {Object} logger - Logger object
 * @returns {boolean} True if updated, false otherwise
 */
function updateOsjBranch(rootElement, logger) {
  // Hardcoded GHEC OSJ branch
  const NEW_OSJ_BRANCH = 'master';
  
  // For pipeline jobs (flow-definition), SCM is in definition.scm
  // For freestyle jobs (project), SCM is in rootElement.scm
  let scm = null;
  
  if (rootElement.definition && rootElement.definition[0] && rootElement.definition[0].scm) {
    scm = rootElement.definition[0].scm;
  } else if (rootElement.scm) {
    scm = rootElement.scm;
  } else {
    return false;
  }

  let updated = false;

  for (let i = 0; i < scm.length; i++) {
    const scmElement = scm[i];

    // Check if this is a Git SCM
    if (scmElement.$ && scmElement.$.class === 'hudson.plugins.git.GitSCM') {
      // Navigate to branches
      if (scmElement.branches && scmElement.branches[0]) {
        const branches = scmElement.branches[0];

        if (branches['hudson.plugins.git.BranchSpec']) {
          const branchSpecs = branches['hudson.plugins.git.BranchSpec'];

          for (let j = 0; j < branchSpecs.length; j++) {
            const branchSpec = branchSpecs[j];

            if (branchSpec.name) {
              const oldBranch = branchSpec.name[0];
              branchSpec.name[0] = NEW_OSJ_BRANCH;
              logger.info(`Updated OSJ Git branch from "${oldBranch}" to "${NEW_OSJ_BRANCH}"`);
              updated = true;
            }
          }
        }
      }
    }
  }

  return updated;
}

/**
 * Update Jenkins config XML with new org and repo
 * @param {string} configXml - Original XML string
 * @param {string} org - New organization name
 * @param {string} repo - New repository name
 * @param {Object} logger - Logger object
 * @returns {Promise<string>} Updated XML string
 */
async function updateJenkinsConfig(configXml, org, repo, logger) {
  // Parse XML
  const parsedXml = await parseXml(configXml);

  // Get root element
  const { rootElement, rootElementName } = getRootElement(parsedXml);
  logger.info(`Detected Jenkins job type: ${rootElementName}`);

  // Update projectUrl
  updateProjectUrl(rootElement, org, repo, logger);

  // Update or add organization parameter
  updateOrganizationParameter(rootElement, org, logger);

  // Update credentials ID (hardcoded to 'ghec-hcsc-core-app')
  updateCredentialsId(rootElement, logger);

  // Update OSJ Git URL (always updated to GHEC)
  updateOsjUrl(rootElement, logger);

  // Update OSJ Git branch
  updateOsjBranch(rootElement, logger);

  // Build updated XML
  const updatedXml = buildXml(parsedXml);
  logger.info('Successfully built updated XML');

  return updatedXml;
}

module.exports = {
  parseXml,
  buildXml,
  getRootElement,
  updateProjectUrl,
  updateOrganizationParameter,
  updateCredentialsId,
  updateOsjUrl,
  updateOsjBranch,
  updateJenkinsConfig
};

