# Update Jenkins Config Action

This GitHub Action updates Jenkins job configurations in batch using a wave file containing multiple jobs to migrate.

## Features

- **Batch Processing**: Process multiple Jenkins jobs from a single wave file
- **Automatic Updates**: Updates GitHub project URL, organization parameter, repository parameter, credentials, and OSJ URL
- **Auto-Apply**: Optionally push updated configurations directly to Jenkins
- **Safe Mode**: Test changes with `apply_changes=false` before applying them
- **Multi-Instance Support**: Works with multiple Jenkins instances (ESP, Digital, Claims, etc.)
- **Error Handling**: Continues processing even if individual jobs fail, provides summary report

## Inputs

| Input | Description | Required | Default |
|-------|-------------|----------|---------|
| `wave_file` | Path to wave file containing job details (see format below) | Yes | - |
| `apply_changes` | Whether to push updated configs back to Jenkins (`true` or `false`) | No | `false` |
| `jenkins_credentials` | JSON string containing Jenkins credentials for all instances | No | - |

## Wave File Format

The wave file is a space or tab-delimited text file with one job per line:

```
<jenkins_job_url> <org> <repo> <credentials_id>
```

Example (`example-wave.txt`):
```
https://jenkins.esp.fyiblue.com/job/MyTeam/job/MyApp/job/Build hcsc-core my-app-repo esp-git-creds-uuid-123
https://jenkins.digital.fyiblue.com/job/WebApp/job/CI hcsc-digital web-app-repo digital-git-creds-uuid-789
```

- Lines starting with `#` are ignored (comments)
- Fields are separated by spaces or tabs
- All 4 fields are required per line

## Outputs

| Output | Description |
|--------|-------------|
| `updated_config` | Comma-separated paths to all updated config XML files |

## Usage

### As a GitHub Actions Workflow

The easiest way to use this action is through the included workflow:

1. Create a wave file with the jobs you want to migrate (see format above)
2. Go to the Actions tab in your repository
3. Select "Update Jenkins Config" workflow
4. Click "Run workflow"
5. Fill in the required inputs:
   - **Wave File Path**: Path to your wave file (e.g., `migration-wave/wave1/wave-1.txt`)
   - **Apply Changes**: Check this box to automatically push changes to Jenkins (leave unchecked to test first)

**Recommended Workflow:**
1. First run with `apply_changes=false` to generate and review the updated XML files
2. Download and review the artifacts
3. Once verified, run again with `apply_changes=true` to apply changes to Jenkins

The workflow will:
- Process all jobs in the wave file
- Generate updated `config.xml` files (named `{number}-updated-{repo}.xml`)
- Make files available as downloadable artifacts
- If `apply_changes=true`, automatically push configs to Jenkins
- Display a summary of successes and failures

### As a Step in Your Own Workflow

```yaml
- name: Update Jenkins Configs
  uses: ./.github/actions/update-jenkins-config
  with:
    wave_file: 'migration-wave/wave1/wave-1.txt'
    apply_changes: 'false'  # Set to 'true' to auto-apply
    jenkins_credentials: ${{ secrets.JENKINS_CREDENTIALS }}
```

## What Gets Updated

### 1. Project URL

Updates the GitHub project URL in `com.coravy.hudson.plugins.github.GithubProjectProperty`:

```xml
<projectUrl>https://github.com/new-org/new-repo/</projectUrl>
```

### 2. Organization Parameter

Updates or adds the `organization` parameter in StringParameterDefinition:

```xml
<hudson.model.StringParameterDefinition>
  <name>organization</name>
  <description>GitHub Organization</description>
  <defaultValue>new-org</defaultValue>
</hudson.model.StringParameterDefinition>
```

### 3. Repository Parameter

Updates or adds the `repository` parameter in StringParameterDefinition:

```xml
<hudson.model.StringParameterDefinition>
  <name>repository</name>
  <description>GitHub Repository</description>
  <defaultValue>new-repo</defaultValue>
</hudson.model.StringParameterDefinition>
```

### 4. Git SCM Credentials

Updates the credentials ID in the Git SCM configuration:

```xml
<scm class="hudson.plugins.git.GitSCM">
  <userRemoteConfigs>
    <hudson.plugins.git.UserRemoteConfig>
      <credentialsId>new-credentials-id-uuid</credentialsId>
    </hudson.plugins.git.UserRemoteConfig>
  </userRemoteConfigs>
</scm>
```

### 5. OSJ URL (Open Source Jenkins)

Updates the OSJ repository URL to point to GitHub Enterprise Cloud:

```xml
<url>https://github.com/hcsc-core/Open_Source_Jenkins.git</url>
```

## Output Files

For each job processed, the action generates an output file named:
```
{job_number}-updated-{repo}.xml
```

Where:
- `{job_number}` is the sequential processing number (1, 2, 3, etc.)
- `{repo}` is the repository name from the wave file

For example, processing 3 jobs:
- `1-updated-my-app-repo.xml`
- `2-updated-web-app-repo.xml`
- `3-updated-api-service.xml`

All files are uploaded as workflow artifacts for download and review.

## Automatic Application to Jenkins

When `apply_changes=true`, the action automatically pushes updated configurations to Jenkins using the Jenkins REST API. This eliminates the need for manual upload.

**Safety Tips:**
- Always test with `apply_changes=false` first
- Review generated XML files before applying
- Consider running on a subset of jobs initially
- Monitor Jenkins after application for any issues

## Authentication

The action uses a single `JENKINS_CREDENTIALS` secret that contains credentials for all Jenkins instances in JSON format.

### Setting up the Secret

1. Create a repository secret named `JENKINS_CREDENTIALS`
2. The value should be a JSON object with this structure:

```json
{
  "esp": {
    "name": "ESP",
    "url": "https://jenkins.esp.fyiblue.com",
    "username": "your-username",
    "token": "your-api-token"
  },
  "digital": {
    "name": "Digital",
    "url": "https://jenkins.digital.fyiblue.com",
    "username": "your-username",
    "token": "your-api-token"
  }
}
```

The action will automatically match credentials based on the Jenkins URL. For example:
- `https://jenkins.esp.fyiblue.com/...` → uses the `esp` credentials
- `https://jenkins.digital.fyiblue.com/...` → uses the `digital` credentials

### Local Testing with Credentials

For local testing, create a file named `JENKINS_CREDENTIALS.json` in the action directory with the same JSON structure. This file is gitignored and will be automatically loaded by the test scripts.

## Example

Example wave file (`wave-1.txt`):
```
https://jenkins.esp.fyiblue.com/job/CICD/job/Build hcsc-core my-app-repo esp-git-creds-uuid-123
https://jenkins.esp.fyiblue.com/job/CICD/job/Deploy hcsc-core my-service-repo esp-git-creds-uuid-456
https://jenkins.digital.fyiblue.com/job/WebApp/job/CI hcsc-digital web-app-repo digital-git-creds-uuid-789
```

The action will:
1. Process each job in the wave file
2. Fetch each config.xml from Jenkins
3. Update projectUrl, organization, repository, credentials, and OSJ URL
4. Generate output files: `1-updated-my-app-repo.xml`, `2-updated-my-service-repo.xml`, etc.
5. If `apply_changes=true`, automatically push configs back to Jenkins
6. Display summary: "Processed 3 jobs - 3 succeeded, 0 failed"

## Development

### Building the Action

This action uses `@vercel/ncc` to bundle the code and dependencies into a single file. This is necessary because GitHub Actions doesn't install npm dependencies when running actions.

After making changes to `index.js` or any dependencies, you must rebuild:

```bash
npm run build
```

This will create/update the `dist/index.js` file, which must be committed to git.

### Testing Locally

See [TESTING.md](TESTING.md) for detailed testing instructions.

