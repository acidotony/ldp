#!/usr/bin/env node

/**
 * Local test script for the update-jenkins-config action
 *
 * Usage:
 *   node test-local.js <wave_file> [apply_changes]
 *
 * Example:
 *   node test-local.js wave-test
 *   node test-local.js wave-test true
 *
 * Wave file format (space/tab delimited, no header):
 *   jenkins_job_url org repo
 *
 * Note:
 *   - Wave files are loaded from ../../../jenkins-wave-files/ directory
 *   - If JENKINS_CREDENTIALS.json exists in this directory, it will be used automatically.
 */

const fs = require('fs');
const path = require('path');

// Mock the @actions/core module for local testing
const mockCore = {
  inputs: {},
  outputs: {},

  getInput(name, options) {
    const value = this.inputs[name];
    if (options?.required && !value) {
      throw new Error(`Input required and not supplied: ${name}`);
    }
    return value || '';
  },

  setOutput(name, value) {
    this.outputs[name] = value;
    console.log(`[OUTPUT] ${name}: ${value}`);
  },

  info(message) {
    console.log(`[INFO] ${message}`);
  },

  warning(message) {
    console.warn(`[WARNING] ${message}`);
  },

  error(message) {
    console.error(`[ERROR] ${message}`);
  },

  setFailed(message) {
    console.error(`[FAILED] ${message}`);
    process.exit(1);
  }
};

// Replace @actions/core with our mock
require.cache[require.resolve('@actions/core')] = {
  exports: mockCore
};

// Parse command line arguments
const args = process.argv.slice(2);

if (args.length < 1) {
  console.error('Usage: node test-local.js <wave_file> [apply_changes]');
  console.error('');
  console.error('Example:');
  console.error('  node test-local.js wave-test');
  console.error('  node test-local.js wave-test true');
  console.error('');
  console.error('Wave file format (space/tab delimited, no header):');
  console.error('  jenkins_job_url org repo');
  console.error('');
  console.error('Note:');
  console.error('  Wave files are loaded from ../../../jenkins-wave-files/ directory');
  console.error('  If JENKINS_CREDENTIALS.json exists in this directory, it will be used automatically.');
  process.exit(1);
}

// Resolve wave file path from jenkins-wave-files directory
const waveFileName = args[0];
const waveFilePath = path.join(__dirname, '../../../jenkins-wave-files', waveFileName);

// Check if wave file exists
if (!fs.existsSync(waveFilePath)) {
  console.error(`[ERROR] Wave file not found: ${waveFilePath}`);
  console.error('');
  console.error('Available wave files in jenkins-wave-files directory:');
  const waveDir = path.join(__dirname, '../../../jenkins-wave-files');
  if (fs.existsSync(waveDir)) {
    const files = fs.readdirSync(waveDir);
    files.forEach(file => console.error(`  - ${file}`));
  } else {
    console.error('  (directory does not exist)');
  }
  process.exit(1);
}

console.log(`[INFO] Using wave file: ${waveFilePath}\n`);

console.log(`[INFO] Using wave file: ${waveFilePath}\n`);

// Load Jenkins credentials from file if it exists
let jenkinsCredentials = null;
const credentialsPath = path.join(__dirname, 'JENKINS_CREDENTIALS.json');
if (fs.existsSync(credentialsPath)) {
  try {
    jenkinsCredentials = JSON.parse(fs.readFileSync(credentialsPath, 'utf8'));
    console.log('[INFO] Loaded Jenkins credentials from JENKINS_CREDENTIALS.json');
  } catch (error) {
    console.warn(`[WARNING] Failed to load JENKINS_CREDENTIALS.json: ${error.message}`);
  }
}

// Set up mock inputs
mockCore.inputs = {
  wave_file: waveFilePath,
  apply_changes: args[1] === 'true' ? 'true' : 'false',
  jenkins_credentials: jenkinsCredentials ? JSON.stringify(jenkinsCredentials) : ''
};

// Set GITHUB_WORKSPACE for output file location
process.env.GITHUB_WORKSPACE = process.cwd();

console.log('=== Local Test Mode ===');
console.log('Wave File:', path.basename(waveFilePath));
console.log('Full Path:', waveFilePath);
console.log('Apply Changes:', mockCore.inputs.apply_changes);
console.log('Credentials Loaded:', jenkinsCredentials ? 'Yes (from JENKINS_CREDENTIALS.json)' : 'No');
console.log('======================\n');

// Now require and run the actual action
require('./index.js');

