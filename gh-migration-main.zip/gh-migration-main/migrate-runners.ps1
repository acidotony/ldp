﻿<#
.SYNOPSIS
    Migrates self-hosted runner groups from HS (zilvertonz) to HCSC (zilvertonz-test-10).
    Migrates GitHub-hosted larger runners AND self-hosted runner groups.
    Generates re-registration commands for physical self-hosted runners.

.DESCRIPTION
    What this script handles:
      1. Runner groups (org-level) -- creates missing groups in destination
      2. GitHub-hosted larger runners (Larger Runners / Actions Compute) --
         creates equivalent hosted runners in destination via /actions/hosted-runners API
      3. Self-hosted runners -- generates re-registration token + config commands
         to run on each physical machine (cannot be done automatically via API)

    NOTE: Enterprise runners (Azure VNET, badge 'Enterprise') are inherited from
    the enterprise level and cannot be created via org API -- they must be
    provisioned by an enterprise admin.

    IMPORTANT: Self-hosted re-registration tokens expire after 1 hour.

.PARAMETER SourceToken
    PAT with admin:org scope for source org (zilvertonz / HS).
    Can also be set via env:SOURCE_TOKEN.

.PARAMETER DestToken
    PAT with admin:org scope for destination org (zilvertonz-test-10 / HCSC).
    Can also be set via env:DEST_TOKEN.

.PARAMETER SourceOrg
    Source organization name. Default: zilvertonz

.PARAMETER DestOrg
    Destination organization name. Default: zilvertonz-test-10

.PARAMETER DryRun
    If set, prints what would be done without making any changes.

.EXAMPLE
    # Dry run first (no changes made)
    .\migrate-runners.ps1 -SourceToken "ghp_..." -DestToken "ghp_..." -DryRun

    # Full run
    .\migrate-runners.ps1 -SourceToken "ghp_..." -DestToken "ghp_..."

    # Using env vars (recommended -- avoids tokens in shell history)
    $env:SOURCE_TOKEN = "ghp_..."
    $env:DEST_TOKEN   = "ghp_..."
    .\migrate-runners.ps1
#>
param(
    [string]$SourceToken = $env:SOURCE_TOKEN,
    [string]$DestToken   = $env:DEST_TOKEN,
    [string]$SourceOrg   = "zilvertonz",
    [string]$DestOrg     = "zilvertonz-test-10",
    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# --- Validate ---
if (-not $SourceToken) { Write-Error "SOURCE_TOKEN not set. Pass -SourceToken or set env:SOURCE_TOKEN"; exit 1 }
if (-not $DestToken)   { Write-Error "DEST_TOKEN not set. Pass -DestToken or set env:DEST_TOKEN"; exit 1 }

$hSrc = @{ Authorization = "Bearer $SourceToken"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
$hDst = @{ Authorization = "Bearer $DestToken";   Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }

function Invoke-GH($Method, $Uri, $Headers, $Body = $null) {
    $params = @{ Method = $Method; Uri = $Uri; Headers = $Headers }
    if ($Body) {
        $params.Body        = ($Body | ConvertTo-Json -Depth 10)
        $params.ContentType = "application/json"
    }
    try {
        return Invoke-RestMethod @params
    } catch {
        $status = $_.Exception.Response.StatusCode.value__
        Write-Warning "HTTP $status on $Method $Uri : $($_.Exception.Message)"
        return $null
    }
}

# --- Step 1: List source runner groups ---
Write-Host ""
Write-Host "[1/4] Reading runner groups from $SourceOrg ..." -ForegroundColor Cyan
$srcGroups = (Invoke-GH GET "https://api.github.com/orgs/$SourceOrg/actions/runner-groups?per_page=100" $hSrc).runner_groups
Write-Host "      Found $($srcGroups.Count) runner groups"

# --- Step 2: List existing destination runner groups ---
Write-Host "[2/4] Reading existing runner groups in $DestOrg ..." -ForegroundColor Cyan
$dstGroupNames = (Invoke-GH GET "https://api.github.com/orgs/$DestOrg/actions/runner-groups?per_page=100" $hDst).runner_groups | ForEach-Object { $_.name }
Write-Host "      Existing: $($dstGroupNames -join ', ')"

# --- Step 3: Create missing runner groups ---
Write-Host "[3/4] Creating runner groups in $DestOrg ..." -ForegroundColor Cyan
$createdGroups = 0
$skippedGroups = 0

foreach ($group in $srcGroups) {
    if ($group.inherited) {
        Write-Host "      SKIP (inherited from enterprise): $($group.name)"
        $skippedGroups++
        continue
    }
    if ($group.default -eq $true -and $group.name -eq "Default") {
        Write-Host "      SKIP (default group always exists): $($group.name)"
        $skippedGroups++
        continue
    }
    if ($group.name -in $dstGroupNames) {
        Write-Host "      SKIP (already exists): $($group.name)"
        $skippedGroups++
        continue
    }

    $payload = @{
        name                       = $group.name
        visibility                 = $group.visibility
        allows_public_repositories = $group.allows_public_repositories
    }
    if ($group.restricted_to_workflows -and $group.selected_workflows.Count -gt 0) {
        $payload.restricted_to_workflows = $true
        $payload.selected_workflows      = $group.selected_workflows
    }

    if ($DryRun) {
        Write-Host "      [DRY RUN] Would create: $($group.name) (visibility=$($group.visibility))" -ForegroundColor DarkYellow
        $createdGroups++
    } else {
        $result = Invoke-GH POST "https://api.github.com/orgs/$DestOrg/actions/runner-groups" $hDst $payload
        if ($result) {
            Write-Host "      CREATED: $($group.name) -> id=$($result.id)" -ForegroundColor Green
            $createdGroups++
        } else {
            Write-Warning "FAILED to create group: $($group.name)"
        }
    }
}
Write-Host "      Created: $createdGroups | Skipped: $skippedGroups"

# --- Step 4: Migrate GitHub-hosted larger runners ---
Write-Host "[4/5] Migrating GitHub-hosted larger runners to $DestOrg ..." -ForegroundColor Cyan

$srcHosted   = (Invoke-GH GET "https://api.github.com/orgs/$SourceOrg/actions/hosted-runners?per_page=100" $hSrc).runners
$dstHosted   = (Invoke-GH GET "https://api.github.com/orgs/$DestOrg/actions/hosted-runners?per_page=100" $hDst).runners
$dstHostedNames = $dstHosted | ForEach-Object { $_.name }

# Re-fetch dest runner groups now (we may have just created some)
$dstGroupsAll  = (Invoke-GH GET "https://api.github.com/orgs/$DestOrg/actions/runner-groups?per_page=100" $hDst).runner_groups
$srcGroupsAll  = (Invoke-GH GET "https://api.github.com/orgs/$SourceOrg/actions/runner-groups?per_page=100" $hSrc).runner_groups

$createdHosted = 0
$skippedHosted = 0

foreach ($hr in $srcHosted) {
    if ($hr.name -in $dstHostedNames) {
        Write-Host "      SKIP (already exists): $($hr.name)"
        $skippedHosted++
        continue
    }

    # Map source runner_group_id to group name, then find matching dest group id
    $srcGroupName = ($srcGroupsAll | Where-Object { $_.id -eq $hr.runner_group_id } | Select-Object -First 1).name
    $dstGroupMatch = $dstGroupsAll | Where-Object { $_.name -eq $srcGroupName } | Select-Object -First 1
    $dstGroupId    = if ($dstGroupMatch) { $dstGroupMatch.id } else { $null }
    if (-not $dstGroupId) {
        # Fall back to Default group (id=1)
        Write-Warning "      Group '$srcGroupName' not found in dest -- assigning to Default group"
        $dstGroupId = 1
    }

    $payload = @{
        name             = $hr.name
        runner_group_id  = $dstGroupId
        maximum_runners  = $hr.maximum_runners
        image            = @{ id = $hr.image_details.id; source = $hr.image_details.source }
        size             = $hr.machine_size_details.id
        enable_static_ip = $hr.public_ip_enabled
    }

    if ($DryRun) {
        Write-Host "      [DRY RUN] Would create hosted runner: $($hr.name)" -ForegroundColor DarkYellow
        Write-Host "                image=$($hr.image_details.display_name) size=$($hr.machine_size_details.id) max=$($hr.maximum_runners) group='$srcGroupName'"
        $createdHosted++
    } else {
        $result = Invoke-GH POST "https://api.github.com/orgs/$DestOrg/actions/hosted-runners" $hDst $payload
        if ($result) {
            Write-Host "      CREATED: $($hr.name) -> id=$($result.id)" -ForegroundColor Green
            $createdHosted++
        } else {
            Write-Warning "FAILED to create hosted runner: $($hr.name)"
        }
    }
}
Write-Host "      Created: $createdHosted | Skipped: $skippedHosted"

# --- Step 5: Generate re-registration commands for physical self-hosted runners ---
Write-Host "[5/5] Generating re-registration commands for self-hosted runners ..." -ForegroundColor Cyan
$srcRunners = (Invoke-GH GET "https://api.github.com/orgs/$SourceOrg/actions/runners?per_page=100" $hSrc).runners

if ($srcRunners.Count -eq 0) {
    Write-Host "      No self-hosted runners found in $SourceOrg"
} else {
    Write-Host "      Found $($srcRunners.Count) self-hosted runner(s) in source"

    if ($DryRun) {
        $regToken = "DRY_RUN_TOKEN_REPLACE_WITH_REAL"
    } else {
        $tokenResp = Invoke-GH POST "https://api.github.com/orgs/$DestOrg/actions/runners/registration-token" $hDst
        if (-not $tokenResp) {
            Write-Error "Failed to generate registration token for $DestOrg"
            exit 1
        }
        $regToken    = $tokenResp.token
        $tokenExpiry = $tokenResp.expires_at
        Write-Host ""
        Write-Host "      Registration token expires at: $tokenExpiry" -ForegroundColor Yellow
        Write-Host "      You must run the commands below within 1 hour." -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Host ("=" * 70) -ForegroundColor Yellow
    Write-Host "  RUNNER RE-REGISTRATION COMMANDS" -ForegroundColor Yellow
    Write-Host "  Log in to each machine and run the appropriate command." -ForegroundColor Yellow
    Write-Host ("=" * 70) -ForegroundColor Yellow

    foreach ($runner in $srcRunners) {
        $customLabels = ($runner.labels | Where-Object { $_.type -eq "custom" }).name
        $labelStr     = if ($customLabels) { $customLabels -join "," } else { "" }

        Write-Host ""
        Write-Host "  Runner : $($runner.name)" -ForegroundColor Cyan
        Write-Host "  OS     : $($runner.os)"
        Write-Host "  Status : $($runner.status) (busy=$($runner.busy))"
        if ($labelStr) { Write-Host "  Labels : $labelStr" }
        Write-Host ""

        $baseArgs = "--url https://github.com/$DestOrg --token $regToken --name `"$($runner.name)`""
        if ($labelStr) { $baseArgs += " --labels `"$labelStr`"" }
        $baseArgs += " --unattended --replace"

        Write-Host "  # Linux / macOS (run in the actions-runner directory):"
        Write-Host "  ./config.sh $baseArgs"
        Write-Host ""
        Write-Host "  # Windows (run in the actions-runner directory):"
        Write-Host "  .\config.cmd $baseArgs"
        Write-Host ""
        Write-Host "  # Windows -- reinstall as service after reconfiguring:"
        Write-Host "  .\svc.cmd stop; .\svc.cmd uninstall; .\svc.cmd install; .\svc.cmd start"
    }

    Write-Host ""
    Write-Host ("=" * 70) -ForegroundColor Yellow
}

# --- Summary ---
Write-Host ""
Write-Host "=== SUMMARY ===" -ForegroundColor Green
Write-Host "  Runner groups created in ${DestOrg}         : $createdGroups"
Write-Host "  Runner groups skipped                       : $skippedGroups"
Write-Host "  GitHub-hosted larger runners created        : $createdHosted"
Write-Host "  GitHub-hosted larger runners skipped        : $skippedHosted"
Write-Host "  Self-hosted runners to re-register manually : $($srcRunners.Count)"
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor Yellow
Write-Host "  1. GitHub-hosted runners are created automatically (no machine access needed)"
Write-Host "  2. For self-hosted runners: log in to each machine listed above"
Write-Host "  3. Stop the current runner service (.\.svc.cmd stop  OR  sudo ./svc.sh stop)"
Write-Host "  4. Run the config command printed above (token valid 1 hour)"
Write-Host "  5. Start the runner service"
Write-Host "  6. Verify at: https://github.com/organizations/$DestOrg/settings/actions/runners"
Write-Host "  NOTE: Enterprise (Azure VNET) runners are inherited -- request from enterprise admin."
if ($DryRun) {
    Write-Host ""
    Write-Host "  [DRY RUN -- no changes were made to either org]" -ForegroundColor Magenta
}