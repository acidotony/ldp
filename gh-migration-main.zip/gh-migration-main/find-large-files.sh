#!/bin/bash

# Check if repository URL is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <repository-url-or-directory>"
    echo ""
    echo "Examples:"
    echo "  $0 git@github.com:org/repo.git"
    echo "  $0 https://github.com/org/repo.git"
    echo "  $0 /path/to/existing/repo"
    exit 1
fi

REPO_INPUT="$1"
WORKING_DIR=""
IS_MIRROR=false
MIGRATION_BASE_DIR="$HOME/migration_fixes"

# Set git config for large repository operations globally
echo "Configuring Git for large repository operations..."
git config --global diff.renameLimit 999999
echo ""

# Check if input is a URL or local directory
if [[ "$REPO_INPUT" =~ ^(https?://|git@) ]]; then
    # It's a URL - extract repo name and create mirror in default directory
    REPO_NAME=$(basename "$REPO_INPUT" .git)

    # Create base directory if it doesn't exist
    mkdir -p "$MIGRATION_BASE_DIR"

    MIRROR_DIR="${MIGRATION_BASE_DIR}/${REPO_NAME}-mirror-$(date +%Y%m%d-%H%M%S)"

    echo "Creating mirror clone of repository..."
    echo "Repository: $REPO_INPUT"
    echo "Mirror directory: $MIRROR_DIR"
    echo ""

    git clone --mirror "$REPO_INPUT" "$MIRROR_DIR"
    if [ $? -ne 0 ]; then
        echo "Error: Failed to clone repository"
        exit 1
    fi

    WORKING_DIR="$MIRROR_DIR"
    IS_MIRROR=true
elif [ -d "$REPO_INPUT" ]; then
    # It's a local directory
    WORKING_DIR="$REPO_INPUT"
    echo "Working with existing repository: $WORKING_DIR"
    echo ""

    # Check if it's already a mirror
    cd "$WORKING_DIR" || exit 1
    if [ -f "config" ] && grep -q "mirror = true" config 2>/dev/null; then
        IS_MIRROR=true
        echo "✓ Detected existing mirror clone"
    else
        echo "⚠ WARNING: This is not a mirror clone!"
        echo "It's safer to work with a mirror clone to preserve the original."
        echo ""
        read -p "Continue anyway? (yes/no): " continue_response
        if [ "$continue_response" != "yes" ] && [ "$continue_response" != "y" ]; then
            echo "Operation cancelled."
            exit 0
        fi
    fi
    echo ""
else
    echo "Error: Invalid repository URL or directory: $REPO_INPUT"
    exit 1
fi

cd "$WORKING_DIR" || exit 1

echo "Finding large blobs (>= 100MB) with commit and path information..."
echo "=================================================="
echo ""

# Store paths of large files for potential removal
declare -a large_file_paths

# Get all large blobs with their SHA and size
while IFS= read -r line; do
    read -r sha size path <<< "$line"

    # Format size to human-readable
    human_size=$(echo "$size" | $(command -v gnumfmt || echo numfmt) --to=iec-i --suffix=B --padding=7 --round=nearest)

    echo "Blob SHA: $sha"
    echo "Size: $human_size"
    echo "Path: ${path:-<unknown>}"

    # Store path if available
    if [ -n "$path" ]; then
        large_file_paths+=("$path")
    fi

    # Find commits that introduced this blob
    echo "Commits:"
    git log --all --pretty=format:'  %H - %ai - %an - %s' --find-object="$sha" | head -5

    # If more than 5 commits, indicate there are more
    commit_count=$(git log --all --oneline --find-object="$sha" | wc -l)
    if [ "$commit_count" -gt 5 ]; then
        echo "  ... and $((commit_count - 5)) more commit(s)"
    fi

    echo ""
    echo "--------------------------------------------------"
    echo ""
done < <(git rev-list --objects --all --missing=print |
  git cat-file --batch-check='%(objecttype) %(objectname) %(objectsize) %(rest)' |
  sed -n 's/^blob //p' |
  sort --numeric-sort --key=2 |
  awk '$2 >= 100*1024*1024')

# Check if any large files were found
if [ ${#large_file_paths[@]} -eq 0 ]; then
    echo "No large files found."
    exit 0
fi

# Prompt user for removal
echo ""
echo "=================================================="
echo "Would you like to remove these large files from Git history?"
echo "WARNING: This will rewrite Git history and require force-push!"
echo "=================================================="
echo ""
read -p "Remove files from history? (yes/no): " response

if [ "$response" = "yes" ] || [ "$response" = "y" ]; then
    # Check if git-filter-repo is installed
    if ! command -v git-filter-repo &> /dev/null; then
        echo "Error: git-filter-repo is not installed."
        echo "Install it with: pip install git-filter-repo"
        exit 1
    fi

    echo ""
    echo "Creating backup of current repository state..."
    git tag "backup-before-filter-repo-$(date +%Y%m%d-%H%M%S)"

    echo "Configuring Git for large repository operations..."
    git config diff.renameLimit 999999
    git config merge.renameLimit 999999

    echo "Removing large files from Git history..."

    # Use git-filter-repo to remove each large file
    for file_path in "${large_file_paths[@]}"; do
        echo "  Removing: $file_path"
        git filter-repo --path "$file_path" --invert-paths --force
    done

    echo ""
    echo "=================================================="
    echo "Files removed from Git history!"
    echo ""

    if [ "$IS_MIRROR" = true ]; then
        echo "Next steps for mirror clone:"
        echo "1. Review the changes: git log --all --oneline"
        echo "2. Push to target remote:"
        echo "   git remote set-url origin <target-repo-url>"
        echo "   git push --mirror"
        echo "3. Or force-push to original remote:"
        echo "   git push --force --all"
        echo "   git push --force --tags"
        echo "4. Notify team members to re-clone the repository"
        echo "5. Delete this mirror directory after successful push"
        echo ""
        echo "Mirror location: $WORKING_DIR"
    else
        echo "Next steps:"
        echo "1. Review the changes: git log --all --oneline"
        echo "2. Force-push to remote: git push --force --all"
        echo "3. Notify team members to re-clone the repository"
        echo "4. If issues occur, restore backup tag"
    fi
    echo "=================================================="
else
    echo "Operation cancelled. No changes made to Git history."
fi

